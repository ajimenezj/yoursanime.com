<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
include('../include/config.php');


if(isset($_GET['type'])) {

	$type=$_GET['type'];

	switch($type) {
		
		case 'preroll':
		case 'postroll':
			if(isset($_GET['action']) && isset($_GET['id'])) {
				if($_GET['action']=='view') {
					$sql = "UPDATE nuevo__preroll SET views=views+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1";
					$conn->execute($sql);
				}
				if($_GET['action']=='click') {
					$sql = "UPDATE nuevo__preroll SET hits=hits+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1";
					$conn->execute($sql);
				}
			}
			break;
		case 'midroll':
			if(isset($_GET['action']) && isset($_GET['id'])) {
				if($_GET['action']=='view') {
					$conn->execute("UPDATE nuevo__midroll SET views=views+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1");
				}
				if($_GET['action']=='click') {
					$conn->execute("UPDATE nuevo__midroll SET hits=hits+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1");
				}
			}
			break;
		case 'overlay':
			if(isset($_GET['action']) && isset($_GET['id'])) {
				if($_GET['action']=='view') {
					$conn->execute("UPDATE nuevo__overlay SET views=views+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1");
				}
				if($_GET['action']=='click') {
					$conn->execute("UPDATE nuevo__overlay SET hits=hits+1 WHERE ID='".mysql_real_escape_string($_GET['id'])."' LIMIT 1");
				}
			}
			break;
		case 'email':
			if(isset($_GET['sender']) && isset($_GET['receiver']) && isset($_GET['message']) && isset($_GET['id'])) {
				$sql="SELECT title, VID from video WHERE vkey='".mysql_real_escape_string($_GET['id'])."'";
				$rs=$conn->execute($sql);
				$video_title 	= $rs->fields['title'];
				$VID = $rs->fields['VID'];
				$link = $config['BASE_URL']."/video/".$VID.clean_title($video_title);

				$sql="SELECT mailbody, mailsubject from nuevo__player WHERE ID='1'";
				$rs=$conn->execute($sql);
				$header = $rs->fields['mailsubject'];
				$body = $rs->fields['mailbody'];

				$body='<br>'.$rs->fields['mailbody']."<br><br>";
				$body.="<a href=".$link.">".$video_title."</a><br /><br>";
				$body.="----------------------<br>";
				$body.=stripslashes($_GET['message'])."<br><br>";
				$body.=$_GET['sender'];

				$to=$_GET['receiver'];
				$from = $config['admin_email'];
				mailing($to,$_GET['sender'],$from,$header,$body);
				
			}
		
	}


}


function clean_title( $text, $slash=true ) {
	$entities_match		= array(' ','--','&quot;','!','@','#','%','^','&','*','_','(',')','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=');
	$entities_replace   = array('-','-','','','','','','','','','','','','','','','','','','','','','','','','');
	$clean_text	 	    = str_replace($entities_match, $entities_replace, $text);
    if ( $clean_text != '' )
        $slash              = ( $slash ) ? '/' : NULL;
	return htmlspecialchars($clean_text, ENT_QUOTES, 'UTF-8');
}

?>

