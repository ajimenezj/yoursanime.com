<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
header("Content-Type: text/xml");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n";
print "<trackList>\n";  
include('nvconfig.php');

if ( isset($_GET['key']) ) {
	$key = trim($_GET['key']);
} else {
	die('Invalid video key');
}

  $sql="select * from nuevo__player WHERE ID = '1'";
  $player = mysql_query($sql);
  if($player) {
		$prow1=mysql_fetch_array($player);
  }
  $sql="select * from nuevo__player WHERE ID = '2'";
  $player = mysql_query($sql);
  if($player) {
		$prow2=mysql_fetch_array($player);
  }


  $sql="select * from video where vkey='".mysql_real_escape_string($key)."' limit 1";
  $video = mysql_query($sql);
  if($video) 
  {
	$row=mysql_fetch_array($video);
	$file = $config['FLVDO_URL']."/".$row['VID'].".flv";

	if(strlen($prow1['hdfolder'])>0) {
		$testfile = $config['BASE_DIR']."/".$prow1['hdfolder']."/".$row['VID'].".flv";
		if(file_exists($testfile)) {
			$filehd=$config['BASE_URL']."/".$prow1['hdfolder']."/".$row['VID'].".flv";
		}
		$testfile = $config['BASE_DIR']."/".$prow1['hdfolder']."/".$row['VID'].".mp4";
		if(file_exists($testfile)) {
			$filehd=$config['BASE_URL']."/".$prow1['hdfolder']."/".$row['VID'].".mp4";
		}
	}
	if(strlen($prow1['html5folder'])>0) {
		$testfile = $config['BASE_DIR']."/".$prow1['html5folder']."/".$row['VID'].".mp4";
		if(file_exists($testfile)) {
			$html5=$config['BASE_URL']."/".$prow1['html5folder']."/".$row['VID'].".mp4";
		}
		$testfile = $config['BASE_DIR']."/".$prow1['html5folder']."/".$row['VID'].".webm";
		if(file_exists($testfile)) {
			$html5=$config['BASE_URL']."/".$prow1['html5folder']."/".$row['VID'].".webm";
		}
		$testfile = $config['BASE_DIR']."/".$prow1['html5folder']."/".$row['VID'].".ogg";
		if(file_exists($testfile)) {
			$ogg=$config['BASE_URL']."/".$prow1['html5folder']."/".$row['VID'].".ogg";
		}
	}

	$youtu = get_youtube($row['embed_code']);
	if(strlen($youtu)>0) { $file = $youtu; $filehd='';$html5='';$webm='';$ogg=''; }		
		

	$vid = $row['VID'];
	$channel = $row['channel'];
	$duration = $row['duration'];

	$url =$config['BASE_URL']."/video/".$row['VID'].clean_seo_text($row['title']);

	// Uncomment line below if not using rewrite rules

	//$url =$config['BASE_URL']."/view_video.php?viewkey=".$key;

	$title = xml_utf8_encode($row['title']);
		
	$fullscreen = 'false'; if($prow2['fullscreen_button']) $fullscreen='true';
	
	$embed = '<![CDATA[<object width="'.$prow2['player_width'].'" height="'.$prow2['player_height'].'" data="'.$config['BASE_URL'].'/nuevo/player.swf" type="application/x-shockwave-flash"><param name="movie" value="'.$config['BASE_URL'].'/nuevo/player.swf"><param name="flashvars" value="config='.$config['BASE_URL'].'/nuevo/econfig.php?key='.$key.'"><param name="allowscriptaccess" value="always"><param value="transparent" name="wmode"><param name="allowfullscreen" value="'.$fullscreen.'"></object>]]>';

  } else {
	die('Invalid movie database');
  }


  $now = time();
  $preroll = 0;
  $postroll=0;
  
$chans = explode("|",$channel);
foreach($chans as $ch) {
	if(!$ch=='0') { $add.='channel = '.$ch.' OR '; }
}
$add =trim($add); $add=trim($add,'OR');$add=trim($add);

  
  //Preroll ad
  //================================================
  
  $sql = "SELECT * FROM nuevo__preroll WHERE active = '1' and type='preroll' and (".$add.") and expire > '$now' ORDER BY rand() LIMIT 1";
  $ad =  mysql_query($sql);
  if($ad) {
	  if(mysql_num_rows($ad)==1) {
	    $arow=mysql_fetch_array($ad);
		$runtime=intval($arow['runtime']);
		$extension = strrchr($source, '.');
		print "<track>\n";
		print "<mediaid>".$arow['ID']."</mediaid>\n";
		print "<file>".$arow['url']."</file>\n";
		if(strlen($arow['html5'])>0) {
			$ext=substr(strrchr($row['html5'],'.'),1);	
			if(strtolower($ext)=='mp4') 
				print "<html5>".$arow['html5']."</html5>\n";
			if(strtolower($ext)=='webm') 
				print "<webm>".$arow['html5']."</webm>\n";
			if(strtolower($ext)=='ogg') 
				print "<ogg>".$arow['html5']."</ogg>\n";
		}
		print "<category>preroll</category>\n";
		if(strlen($arow['link'])>0) { print "<url>".$arow['link']."</url>\n"; }
		if($runtime>0 && $extension !='.flv' && $extension !='.mp4') { print "<duration>".$runtime."</duration>\n"; }
		print "</track>\n";
		$preroll=1;
	  }
  }

  if($preroll != 1) {

	$sql = "SELECT * FROM nuevo__preroll WHERE active = '1' and type='preroll' and channel = '0' and expire > '$now' ORDER BY rand() LIMIT 1";
	$ad =  mysql_query($sql);
	if($ad) {
	  if(mysql_num_rows($ad)==1) {
			$arow=mysql_fetch_array($ad);
			$runtime=intval($arow['runtime']);
			$extension = strrchr($source, '.');
			print "<track>\n";
			print "<mediaid>".$arow['ID']."</mediaid>\n";
			print "<file>".$arow['url']."</file>\n";
			if(strlen($arow['html5'])>0) {
			$ext=substr(strrchr($row['html5'],'.'),1);	
				if(strtolower($ext)=='mp4') 
					print "<html5>".$arow['html5']."</html5>\n";
				if(strtolower($ext)=='webm') 
					print "<webm>".$arow['html5']."</webm>\n";
				if(strtolower($ext)=='ogg') 
					print "<ogg>".$arow['html5']."</ogg>\n";
			}
			print "<category>preroll</category>\n";
			if(strlen($arow['link'])>0) { print "<url>".$arow['link']."</url>\n"; }
			if($runtime>0 && $extension !='.flv' && $extension !='.mp4') { print "<duration>".$runtime."</duration>\n"; }
			print "</track>\n";
	   }
	}
 }

  // Main movie item here

  print "<track>\n";
  print "<file>".$file."</file>\n";
  print "<image>".$config['TMB_URL']."/".$row['thumb']."_".$row['VID'].".jpg</image>\n";
  if(isset($filehd)) { if(strlen($filehd)>0) print "<filehd>".$filehd."</filehd>\n"; }
  if(isset($html5)) { if(strlen($html5)>0) print "<html5>".$html5."</html5>\n"; }
  if(isset($webm)) { if(strlen($webm)>0) print "<webm>".$webm."</webm>\n"; }
  if(isset($ogg)) { if(strlen($ogg)>0) print "<ogg>".$ogg."</ogg>\n"; }
  if(strlen($duration)>0) { print "<duration>".$duration."</duration>\n"; }
  print "<url>".htmlentities($url)."</url>\n";
  print "<mediaid>".$key."</mediaid>\n";
  print "<title>".clr($title)."</title>\n";
  print "<embedcode>".$embed."</embedcode>\n";
  print "</track>\n";
  


  $sql = "SELECT * FROM nuevo__preroll WHERE active = '1' and type='postroll' and (".$add.") and expire > '$now' ORDER BY rand() LIMIT 1";

  $ad =  mysql_query($sql);
  if($ad) 
  {
	 if(mysql_num_rows($ad)==1) 
	 {
	    $arow=mysql_fetch_array($ad);
		$runtime=intval($arow['runtime']);
		$extension = strrchr($source, '.');
	
		print "<track>\n";
		print "<mediaid>".$arow['ID']."</mediaid>\n";
		print "<file>".$arow['url']."</file>\n";
		if(strlen($arow['html5'])>0) {
			$ext=substr(strrchr($row['html5'],'.'),1);	
			if(strtolower($ext)=='mp4') 
				print "<html5>".$arow['html5']."</html5>\n";
			if(strtolower($ext)=='webm') 
				print "<webm>".$arow['html5']."</webm>\n";
			if(strtolower($ext)=='ogg') 
				print "<ogg>".$arow['html5']."</ogg>\n";
		}
		print "<category>postroll</category>\n";
		if(strlen($arow['link'])>0) { print "<url>".$arow['link']."</url>\n"; }
		if($runtime>0 && $extension !='.flv' && $extension !='.mp4') { print "<duration>".$runtime."</duration>\n"; }
		print "</track>\n";
		$postroll=1;

	 }
  }


  if($postroll != 1) 
  {

	$sql = "SELECT * FROM nuevo__preroll WHERE active = '1' and type='postroll' and channel = '0' and expire > '$now' ORDER BY rand() LIMIT 1";

	$ad =  mysql_query($sql);
	if($ad) 
	{
		if(mysql_num_rows($ad)==1) 
		{
			$arow=mysql_fetch_array($ad);
			$runtime=intval($arow['runtime']);
			$extension = strrchr($source, '.');
		
			print "<track>\n";
			print "<mediaid>".$arow['ID']."</mediaid>\n";
			print "<file>".$arow['url']."</file>\n";
			if(strlen($arow['html5'])>0) {
			$ext=substr(strrchr($row['html5'],'.'),1);	
				if(strtolower($ext)=='mp4') 
					print "<html5>".$arow['html5']."</html5>\n";
				if(strtolower($ext)=='webm') 
					print "<webm>".$arow['html5']."</webm>\n";
				if(strtolower($ext)=='ogg') 
					print "<ogg>".$arow['html5']."</ogg>\n";
			}
			print "<category>postroll</category>\n";
			if(strlen($arow['link'])>0) { print "<url>".$arow['link']."</url>\n"; }
			if($runtime>0 && $extension !='.flv' && $extension !='.mp4') { print "<duration>".$runtime."</duration>\n"; }
			print "</track>\n";

		}
	}
  }
 

  print "</trackList>\n";
  print "</playlist>";


function clr($string) {
	return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
function flash_encode($string)
{
      $string = str_replace("?", "%3F", $string);
      $string = str_replace("=2", "%3D", $string);
      $string = str_replace("&", "%26", $string);
      return $string;
}
?>