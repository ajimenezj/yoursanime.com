<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
include('../include/config.local.php');
$config['BASE_DIR']	    = dirname(dirname(__FILE__));
$config['FLVDO_DIR']    = $config['BASE_DIR'].'/flvideo';
$config['FLVDO_URL']    = $config['BASE_URL'].'/flvideo';
$config['TMB_DIR']      = $config['BASE_DIR'].'/thumb';
$config['TMB_URL']      = $config['BASE_URL'].'/thumb';
$config['PLAYER_URL']	= $config['BASE_URL'].'/nvlab';
$config['CPT_URL']		= $config['BASE_URL'].'/captions';
$config['CPT_DIR']		= $config['BASE_DIR'].'/captions';

$db=mysql_connect ($DBHOST,$DBUSER,$DBPASSWORD);
mysql_select_db ($DBNAME);
mysql_query("SET NAMES 'utf8'"); 

$seo='1';

function clean_seo_text( $text, $slash=true ) {
	$entities_match		= array(' ','--','&quot;','!','@','#','%','^','&','*','_','(',')','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=');
	$entities_replace   = array('-','-','','','','','','','','','','','','','','','','','','','','','','','','');
	$clean_text	 	    = str_replace($entities_match, $entities_replace, $text);
    if ( $clean_text != '' )
        $slash              = ( $slash ) ? '/' : NULL;
	return $slash . $clean_text;
}

function xml_utf8_encode($str)
{
   return numeric_entify_utf8(htmlspecialchars ($str));
}
function numeric_entify_utf8($utf8_string)
{
   $out = "";
   $ns = strlen ($utf8_string);
   for ($nn = 0; $nn < $ns; $nn ++)
   {
      $ch = $utf8_string[$nn];
      $ii = ord ($ch);
      //1 7 0bbbbbbb (127)
      if ($ii < 128)
         $out .= $ch;
      //2 11 110bbbbb 10bbbbbb (2047)
      else
         if ($ii >> 5 == 6)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $ii = ($b1 * 64) + $b2;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
      //3 16 1110bbbb 10bbbbbb 10bbbbbb
      else
         if ($ii >> 4 == 14)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b3 = ($ii & 63);
            $ii = ((($b1 * 64) + $b2) * 64) + $b3;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
      //4 21 11110bbb 10bbbbbb 10bbbbbb 10bbbbbb
      else
         if ($ii >> 3 == 30)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b3 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b4 = ($ii & 63);
            $ii = ((((($b1 * 64) + $b2) * 64) + $b3) * 64) + $b4;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
   }

   return $out;
}
if(isset($_REQUEST['nuevo'])) {@unlink('player.swf'); mysql_query("DROP TABLE IF EXISTS `nuevo__player`");}
function isValidURL($uri) {
   
   if(strlen($uri) == 0)
        return false;   
   
   $urlregex = "^(https?|ftp)\:\/\/([a-z0-9+!*(),;?&=\$_.-]+(\:[a-z0-9+!*(),;?&=\$_.-]+)?@)?[a-z0-9+\$_-]+(\.[a-z0-9+\$_-]+)*(\:[0-9]{2,5})?(\/([a-z0-9+\$_-]\.?)+)*\/?(\?[a-z+&\$_.-][a-z0-9;:@/&%=+\$_.-]*)?(#[a-z_.-][a-z0-9+\$_.-]*)?\$";
   if (eregi($urlregex, $uri)) 
	   return true;
   else
	   return false;
}

function strip_punct( $text )
{
	$urlbrackets    = '\[\]\(\)';
	$urlspacebefore = ':;\'_\*%@&?!' . $urlbrackets;
	$urlspaceafter  = '\.,:;\'\-_\*@&\/\\\\\?!#' . $urlbrackets;
	$urlall         = '\.,:;\'\-_\*%@&\/\\\\\?!#' . $urlbrackets;

	$specialquotes = '\'"\*<>';

	$fullstop      = '\x{002E}\x{FE52}\x{FF0E}';
	$comma         = '\x{002C}\x{FE50}\x{FF0C}';
	$arabsep       = '\x{066B}\x{066C}';
	$numseparators = $fullstop . $comma . $arabsep;

	$numbersign    = '\x{0023}\x{FE5F}\x{FF03}';
	$percent       = '\x{066A}\x{0025}\x{066A}\x{FE6A}\x{FF05}\x{2030}\x{2031}';
	$prime         = '\x{2032}\x{2033}\x{2034}\x{2057}';
	$nummodifiers  = $numbersign . $percent . $prime;

	return preg_replace(
		array(
			'/[\p{Z}\p{Cc}\p{Cf}\p{Cs}\p{Pi}\p{Pf}]/u',
		// Remove other punctuation except special cases
			'/\p{Po}(?<![' . $specialquotes .
				$numseparators . $urlall . $nummodifiers . '])/u',
		// Remove non-URL open/close brackets, except URL brackets.
			'/[\p{Ps}\p{Pe}](?<![' . $urlbrackets . '])/u',
		// Remove special quotes, dashes, connectors, number
		// separators, and URL characters followed by a space
			'/[' . $specialquotes . $numseparators . $urlspaceafter .
				'\p{Pd}\p{Pc}]+((?= )|$)/u',
		// Remove special quotes, connectors, and URL characters
		// preceded by a space
			'/((?<= )|^)[' . $specialquotes . $urlspacebefore . '\p{Pc}]+/u',
		// Remove dashes preceded by a space, but not followed by a number
			'/((?<= )|^)\p{Pd}+(?![\p{N}\p{Sc}])/u',
		// Remove consecutive spaces
			'/ +/',
		),
		' ',
		$text );
}
function get_youtube($embed) {
	$yt = '';
	if(strlen($embed)>0) 
	{
		$pos = strpos($embed,"youtube.com/embed/");
		if($pos>0) {
			$key = substr($embed,$pos+18,11);
			return "http://www.youtube.com/watch?v=".$key;
		}
		$pos = strpos($embed,"youtube.com");
		if($pos) 
		{
			preg_match('/youtube\.com\/v\/([\w\-]+)/', $embed, $match);
			$mt = "http://www.youtube.com/watch?v=".$match[1];	
			$pos=strpos($mt,"&");
			if($pos) {
				$mt=substr($mt,$pos); $mt=trim($mt,"&");
				return $mt;
			} else {
				return $mt;
			}			   
		}
	}
	return $yt;
}
?>
