<?php
define('_VALID', true);
require('../include/config.php');
    

$family_friendly = 'yes';
$nuevoplayer = false;
if(file_exists($config['BASE_DIR'].'/nuevo/player.swf')) $nuevoplayer=true;

//Here you can set number of videos indexed for single sitemap file

$split=4500;


$where = " WHERE type='public' AND embed_code = ''";
if($config['approve']=='1') $where.= " AND active = 1";



$sql="select count(*) as total from video".$where;

echo $sql; die();

$rs=$conn->execute($sql);
$total = $rs->fields['total'];

$limit="";

if($total>$split) {
  if(isset($_REQUEST['start'])) {
	  $start=$_REQUEST['start'];
	  $limit=" limit ".$start.", ".$split; 
  } else {
	  $start=$split;
	  $limit=" limit ".$split;
  }
}

$ttl = array();
$dsc = array();

$sql_vids = "select * FROM video".$where." ORDER BY VID DESC".$limit;
$rs=$conn->execute($sql_vids);
$result=$rs->getrows();

if($result) {

	$map='<?xml version="1.0" encoding="UTF-8"?>'."\n";
	$map.='<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
	xmlns:video="http://www.google.com/schemas/sitemap-video/1.0">'."\n";

	foreach($result as $vid)
	{

		if($vid['embed_code']=='') 
		{

			$vid_url=$config['BASE_URL']."/video/".$vid['VID']."/".url_clean($vid['title']);
			$vid_url = xml_utf8_encode($vid_url);
			//$file_url=$config['FLVDO_URL']. '/' .$vid['VID']. '.flv';
			//$file_dir=$config['FLVDO_DIR']. '/' .$vid['VID']. '.flv';
			
			
			$player = $config['BASE_URL'].'/player/vPlayer.swf?f='.$config['BASE_URL'].'/player/vConfig_embed.php?vkey='.$vid['vkey'];

			if($nuevoplayer) {
			$player = $config['BASE_URL'].'/nuevo/player.swf?config='.$config['BASE_URL'].'/nuevo/econfig.php?key='.$vid['vkey'];
			}

			if(strlen($vid['title'])>0) {
				$title = strip($vid['title']);
				$title=truncate(strip_tags($title,80));
				$title=htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
				$title=xml_utf8_encode($title);
			}
			$desc='';
			if(strlen($vid['description'])>0) {
				$desc = strip($vid['description']);
				$desc = strip_tags($desc);
				$desc = truncate($desc,200);
				$desc=htmlspecialchars($desc, ENT_QUOTES, 'UTF-8');
				$desc = xml_utf8_encode($desc);
			}
			$thumb_url = $config['TMB_URL'].'/'.$vid['thumb'].'_'.$vid['VID'].'.jpg';
			$thumb_url=xml_utf8_encode($thumb_url);
			if(strlen($vid['duration'])>0)
				$dur = xml_utf8_encode($vid['duration']);
			
			 $added = date("Y-m-d",$vid['addtime']);
			if(strlen($title)>0 && strlen($dur)>0 && strlen($thumb_url)>0  ) 
			{
				if(!in_array($title,$ttl)) 
				{

					$ttl[] = $title;

					$map.="\t<url>\n";
					$map.="\t\t<loc>".$vid_url."</loc>\n";
					$map.="\t\t<video:video>\n";
					$map.="\t\t\t<video:player_loc allow_embed=\"yes\">".$player."</video:player_loc>\n";
					//$map.="\t\t\t<video:content_loc>".$file_url."</video:content_loc>\n";
					$map.="\t\t\t<video:title>".$title."</video:title>\n";
					if(strlen($desc)>0) {
						if(!in_array($desc,$dsc)) {
							$dsc[] = $desc;
							$map.="\t\t\t<video:description>".$desc."</video:description>\n";
						}
					}
					$map.="\t\t\t<video:thumbnail_loc>".$thumb_url."</video:thumbnail_loc>\n";
					$map.="\t\t\t<video:duration>".$dur."</video:duration>\n";
					$map.="\t\t\t<video:view_count>".$vid['viewnumber']."</video:view_count>\n";
					$map.="\t\t\t<video:publication_date>".$added."</video:publication_date>\n";
					$map.="\t\t\t<video:live>no</video:live>\n";
					$map.="\t\t\t<video:family_friendly>".$family_friendly."</video:family_friendly>\n";
					$map.="\t\t</video:video>\n";
					$map.="\t</url>\n";
				}

			}
		}
	}
	$map.="</urlset>\n";

	$filename = 'videositemap.xml';

	if($total>$split) {
	
		if(isset($_REQUEST['start'])) $old_start=$_REQUEST['start']; else $old_start=0;
		$start = $old_start+$split;
		$count=intval($start/$split);
		$ret = write_to_file('videositemap_'.$count.'.xml', $map);
		if($total>($old_start+$split)) {
			header("Location: ".$config['BASE_URL']."/sitemaps/sitemap.php?start=".$start);
			die();
		} else {
		
			$map = '<?xml version="1.0" encoding="UTF-8"?>'."\n";
			$map.='<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
			$maps = array();
			for ($i=1;$i<1000;$i++) {
				if(file_exists($config['BASE_DIR']."/sitemaps/videositemap_".$i.".xml")) {
				
					$map.="<sitemap>\n";
					$map.="<loc>".$config['BASE_URL']."/sitemaps/videositemap_".$i.".xml</loc>\n";
					$now=date("Y-m-d",time());
					$map.="<lastmod>".$now."</lastmod>\n";
					$map.="</sitemap>\n";
					$maps[] = $config['BASE_URL']."/sitemaps/videositemap_".$i.".xml";
				} else {
					break;
				}
			}
			$map.= "</sitemapindex>";
			$ret = write_to_file('videositemap.xml', $map);

			echo "<center><h1>Video sitemap created correctly</h1><br />Submit file '/sitemaps/videositemap.xml' as your video sitemap<br />in Google Webmaster Tools.<br />";
			echo "You can review your sitemap index: <a href=\"".$config['BASE_URL']."/sitemaps/videositemap.xml\">videositemap.xml</a>";
			$num=1;
			if(count($maps)>0) {
				echo '<div style="margin-top:15px;display:table;text-align:left;line-height:22px;">';
				echo '<b>Index of sitemap files:</b><br />';
				foreach($maps as $mp) {
					echo $num.'. <a href="'.$mp.'">'.$mp.'</a><br />';
					$num++;
				}
				echo '</div>';
			}
			echo "</center>";
			die();

		}
	} else {
		$ret = write_to_file('videositemap.xml', $map);
	}


	if(!$ret==true)
		echo "<center><h1>Sitemap could not be created</h1><br />".$ret."</center>";
	else {
		echo "<center><h1>Video sitemap created correctly</h1><br />";
		echo "You can review your sitemap: <a href=\"".$config['BASE_URL']."/sitemaps/videositemap.xml\">videositemap.xml</a><br />";
		   echo '<br /><br />Fresh sitemap file has been pinged to Google Webmaster Tools.<br />';
		   echo "Please check it, and if something is wrong, submit file<br />";
		   echo "'sitemaps/videositemap.xml'<br />";
		   echo "as your video sitemap<br />in Google Webmaster Tools manually";		}
		echo "</center>";
		
		//$result = ping($config['BASE_URL']."/sitemaps/videositemap.xml");

	}



function write_to_file($filename, $string='')
{

   if (!$f = @fopen ($filename, 'w'))
      return "File not opened";

   if (!is_writable ($filename))
      @chmod ($filename, 0777); // Try to give writing permissions

   if (!is_writable ($filename))
      return "File not writeable";

   if (@fwrite ($f, $string) === false)
      return "File not saved";

   if (!@fclose ($f))
      return "File not closed";

   clearstatcache();

   return true;
}
function ping( $xml )
{
   $status = 0;
   $google = 'www.google.com';
   if( $fp=@fsockopen($google, 80) )
   {
      $req =  'GET /webmasters/sitemaps/ping?sitemap=' .
              urlencode( $url_xml ) . " HTTP/1.1\r\n" .
              "Host: $google\r\n" .
              "User-Agent: Mozilla/5.0 (compatible; " .
              PHP_OS . ") PHP/" . PHP_VERSION . "\r\n" .
              "Connection: Close\r\n\r\n";
      fwrite( $fp, $req );
      while( !feof($fp) )
      {
         if( @preg_match('~^HTTP/\d\.\d (\d+)~i', fgets($fp, 128), $m) )
         {
            $status = intval( $m[1] );
            break;
         }
      }
      fclose( $fp );
   }
   return( $status );
}
function xml_utf8_encode($str)
{
   return numeric_entify_utf8(htmlspecialchars ($str));
}
function numeric_entify_utf8($utf8_string)
{
   $out = "";
   $ns = strlen ($utf8_string);
   for ($nn = 0; $nn < $ns; $nn ++)
   {
      $ch = $utf8_string[$nn];
      $ii = ord ($ch);
      //1 7 0bbbbbbb (127)
      if ($ii < 128)
         $out .= $ch;
      //2 11 110bbbbb 10bbbbbb (2047)
      else
         if ($ii >> 5 == 6)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $ii = ($b1 * 64) + $b2;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
      //3 16 1110bbbb 10bbbbbb 10bbbbbb
      else
         if ($ii >> 4 == 14)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b3 = ($ii & 63);
            $ii = ((($b1 * 64) + $b2) * 64) + $b3;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
      //4 21 11110bbb 10bbbbbb 10bbbbbb 10bbbbbb
      else
         if ($ii >> 3 == 30)
         {
            $b1 = ($ii & 31);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b2 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b3 = ($ii & 63);
            $nn ++;
            $ch = $utf8_string[$nn];
            $ii = ord ($ch);
            $b4 = ($ii & 63);
            $ii = ((((($b1 * 64) + $b2) * 64) + $b3) * 64) + $b4;
            $ent = sprintf ("&#%d;", $ii);
            $out .= $ent;
         }
   }

   return $out;
}
function truncate($string, $length = 80, $etc = '...',$break_words = false)
{
    if ($length == 0)
        return '';
    if (strlen($string) > $length) {
        $length -= strlen($etc);
        if (!$break_words)
            $string = preg_replace('/\s+?(\S+)?$/', '', substr($string, 0, $length+1));
      
        return substr($string, 0, $length).$etc;
    } else
        return $string;
}

function strip($text, $replace = ' ')
{
    return preg_replace('!\s+!', $replace, $text);
}

function url_clean( $text, $slash=true ) {
	$entities_match		= array(' ','--','&quot;','!','@','#','%','^','&','*','_','(',')','+','{','}','|',':','"','<','>','?','[',']','\\',';',"'",',','.','/','*','+','~','`','=');
	$entities_replace   = array('-','-','','','','','','','','','','','','','','','','','','','','','','','','');
	$clean_text	 	    = str_replace($entities_match, $entities_replace, $text);
//    $clean_text         = preg_replace('/[^a-zA-Z0-9\-]/', '', $clean_text);
    if ( $clean_text != '' )
        $slash              = ( $slash ) ? '/' : NULL;
	
	return $slash . $clean_text;
}


?>

