<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
include('../include/config.php');
header("Content-Type: text/xml");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<config>\n"; 

$config['PLAYER_URL']	= $config['BASE_URL'].'/nuevo';

if ( isset($_GET['id'])) {
	$key = trim($_GET['id']);
} else {
	die('Invalid video key');
}

$sql="select VID, thumb, channel, embed_code from video where VID='".mysql_real_escape_string($key)."' LIMIT 1";
$video = mysql_query($sql);
if($video) {
	$row=mysql_fetch_array($video);
	$vid = $row['VID'];
	$image=$config['TMB_URL']."/".$row['thumb']."_".$row['VID'].".jpg";
	$channel = $row['channel'];
} else {
	die('Invalid video');
}

$sql="select * from nuevo__player where ID='3'";
$result = mysql_query($sql);
if($result) {
	$set=mysql_fetch_array($result);
} else {
	die('Invalid player inerface');
}

$bool = array(0=>'false',1=>'true');
$plugins = '';

// License key
print "<regkey>".$set['regkey']."</regkey>\n";

// Skin file if other than default
if(strlen($set['skin'])>0) { print "<skin>".$set['skin']."</skin>\n"; }

// Playlist
print "<playlist>".$config['PLAYER_URL']."/cstlist.php?key=".$key."</playlist>\n";


// Image
if(strlen($image)>0)	{ print "<image>".$image."</image>\n"; }

if($set['guide_show']==1) {
if($set['guide']!='') {
	print "<custom_guide>".$set['guide']."</custom_guide>\n";
	print "<guide>".$config['PLAYER_URL']."/guide.php</guide>\n";
} else {
	print "<guide>".$config['PLAYER_URL']."/guide.php</guide>\n";
}
}

if(strlen($set['statscript'])>0)	{ print "<statscript>".$set['statscript']."</statscript>\n"; }


//autostart (true/false)
print "<autostart>".$bool[$set['autostart']]."</autostart>\n"; 


// Stretching (aspect/fit)
if(strlen($set['stretching'])>0)	{ print "<stretching>".$set['stretching']."</stretching>\n"; }

//default volume (0-100)
if(strlen($set['volume'])>0)		{ print "<volume>".$set['volume']."</volume>\n"; }


//show playlist (true/false)
print "<playlist_show>false</playlist_show>\n"; 


// Controlbar position (bottom/over)
if(isset($set['playbar']))		{ print "<playbar>".$set['playbar']."</playbar>\n";  }

// Offset X for controlbar with "over" position
if(isset($set['playbaroffsetx']))		{ print "<playbaroffsetx>".$set['playbaroffsetx']."</playbaroffsetx>\n";  }

// Offset X for controlbar with "over" position
if(isset($set['playbaroffsety']))		{ print "<playbaroffsety>".$set['playbaroffsety']."</playbaroffsety>\n";  }

// Controlbar opacity for "over" position
if(isset($set['playbaralpha']))		{ print "<playbaralpha>".$set['playbaralpha']."</playbaralpha>\n";  }

// Force video window to fullheight
if(isset($set['fullheight']))		{ print "<fullheight>".$bool[$set['fullheight']]."</fullheight>\n";  }

// Video quality (true/false)
if(isset($set['videoquality']))		{ print "<videoquality>".$bool[$set['videoquality']]."</videoquality>\n";  }

// Buffer length
if(isset($set['bufferlength']))		{ print "<bufferlength>".$set['bufferlength']."</bufferlength>\n"; }

// Show tooltips
if(isset($set['usetooltips'])>0)	{ print "<usetooltips>".$bool[$set['usetooltips']]."</usetooltips>\n"; }

// Show viral icons
if(isset($set['viral_show'])>0)		{ print "<viral_show>".$bool[$set['viral_show']]."</viral_show>\n"; }


// Viral icons Y Offset
if(isset($set['viral_offset'])>0)	{ print "<viral_offset>".$set['viral_offset']."</viral_offset>\n"; }

// Viral icons align (left/right)
if(isset($set['viral_align'])>0)	{ print "<viral_align>".$set['viral_align']."</viral_align>\n"; }

// Viral icons back color on mouse over
if(strlen($set['viral_backhover'])==6)	{ print "<viral_backhover>".$set['viral_backhover']."</viral_backhover>\n"; }

// Viral icons text color on mouse over
if(strlen($set['viral_texthover'])>0)	{ print "<viral_texthover>".$set['viral_texthover']."</viral_texthover>\n"; }

// Logo
if(strlen($set['logo'])>0 && $set['show_logo']=='1') { 
	
	//Image URL
	print "<logo>".$set['logo']."</logo>\n";

	//URL to go when logo clicked
	if(strlen($set['logourl'])>0) { print "<logourl>".$set['logourl']."</logourl>\n"; }

	//Logo position
	if(strlen($set['logoalign'])==2)	{ print "<logoalign>".$set['logoalign']."</logoalign>\n"; }

	//logo position offset (X and Y)
	if(isset($set['logooffsetx'])>0)		{ print "<logooffsetx>".$set['logooffsetx']."</logooffsetx>\n"; }
	if(isset($set['logooffsety'])>0)		{ print "<logooffsety>".$set['logooffsety']."</logooffsety>\n"; }

}

// Show hd icon
if(isset($set['hdicon'])>0)			{ print "<hdicon>".$bool[$set['hdicon']]."</hdicon>\n"; }

// HD icon align (left/right)
if(isset($set['hdalign'])>0)		{ print "<hdalign>".$set['hdalign']."</hdalign>\n"; }

// Play HD content first (false/true)
if(isset($set['hdfirst'])>0)		{ print "<hdfirst>".$bool[$set['hdfirst']]."</hdfirst>\n"; }

// Slomo interval
if(strlen($set['slomointerval'])>0)		{ print "<slomointerval>".$set['slomointerval']."</slomointerval>\n"; }

//show ID3 info for audio files
//if(isset($set['showId3'])>0)			{ print "<showId3>".$bool[$set['showId3']]."</showId3>\n"; }

//ID3 background opacity (0-100)
//if(isset($set['id3opacity'])>0)		{ print "<id3opacity>".$set['id3opacity']."</id3opacity>\n"; }


//default provider
if(strlen($set['provider'])>0) {
	
	//Provider
	print "<provider>".$set['provider']."</provider>\n";

	//Streamer script or RTMP server URL
	if(strlen($set['streamer'])>0)		{ print "<streamer>".$set['streamer']."</streamer>\n"; }

	//Request param for HTTP streaming
	if(strlen($set['httpparam'])>0)		{ print "<httpparam>".$set['httpparam']."</httpparam>\n"; }
}


//show embed code
if(isset($set['embed_show']))		{ print "<embed_show>".$bool[$set['embed_show']]."</embed_show>\n"; }

//show guide window
if(isset($set['guide_show']))		{ print "<guide_show>".$bool[$set['guide_show']]."</guide_show>\n"; }

//show email window
if(isset($set['email_show']))		{ print "<email_show>".$bool[$set['email_show']]."</email_show>\n"; }

//show share window
if(isset($set['share_show']))		{ print "<share_show>".$bool[$set['share_show']]."</share_show>\n"; }

//playlist button
print "<playlist_button>false</playlist_button>\n";

//replay button
if(isset($set['replay_button']))		{ print "<replay_button>".$bool[$set['replay_button']]."</replay_button>\n"; }

//slomo button
if(isset($set['slomo_button']))			{ print "<slomo_button>".$bool[$set['slomo_button']]."</slomo_button>\n"; }

//zoom button
if(isset($set['zoom_button']))			{ print "<zoom_button>".$bool[$set['zoom_button']]."</zoom_button>\n"; }

//video settings button
if(isset($set['settings_button']))		{ print "<settings_button>".$bool[$set['settings_button']]."</settings_button>\n"; }

//volume button
if(isset($set['volume_button']))		{ print "<volume_button>".$bool[$set['volume_button']]."</volume_button>\n"; }

//size window button
if(isset($set['size_button']))			{ print "<size_button>".$bool[$set['size_button']]."</size_button>\n"; }

//fullscreen button
if(isset($set['fullscreen_button']))	{ print "<fullscreen_button>".$bool[$set['fullscreen_button']]."</fullscreen_button>\n"; }

//menu button
if(isset($set['menu_button']))			{ print "<menu_button>".$bool[$set['menu_button']]."</menu_button>\n"; }

//resize button
if(isset($set['resize_button']))		{ print "<resize_button>".$bool[$set['resize_button']]."</resize_button>\n"; }

//Flash context menu on right click
if($set['menuitem']==1)  {
	print "<menuitem>true</menuitem>\n";
	if(strlen($set['menutext'])>0)
		print "<menutext>".$set['menutext']."</menutext>\n";
	if(strlen($set['menulink'])>0)	
		print "<menulink>".$set['menulink']."</menulink>\n";
} else {
	print "<menuitem>false</menuitem>\n>";
}

// RSS URL
if(strlen($set['rss_url'])>0) print "<rss_url>".$set['rss_url']."</rss_url>\n";


//Video window on click action
print "<onclick>play</onclick>\n";


//Colors
if(strlen($set['screencolor'])>0)		{ print "<screencolor>".$set['screencolor']."</screencolor>\n"; }
if(strlen($set['hovercolor'])>0)		{ print "<hovercolor>".$set['hovercolor']."</hovercolor>\n"; }


if(strlen($plugins)>0) { print "<plugins>".trim($plugins,",")."</plugins>\n"; }


$lng=array();
if(file_exists($config['BASE_DIR']. '/language/' .$_SESSION['language']. '.nuevo.lang.php')) 
{
  include $config['BASE_DIR']. '/language/' .$_SESSION['language']. '.nuevo.lang.php'; $nuevo_lang=true;

	// Tooltips
	set_lang('nuevo_tip_replay','tip_replay');
	set_lang('nuevo_tip_slomo','tip_slomo');
	set_lang('nuevo_tip_zoom','tip_zoom');
	set_lang('nuevo_tip_fullscreen','tip_fullscreen');
	set_lang('nuevo_tip_fullscreen_back','tip_fullscreen_back'); 
	set_lang('nuevo_tip_menu','tip_menu');
	set_lang('nuevo_tip_size','tip_size');
	set_lang('nuevo_tip_playlist','tip_playlist');
	set_lang('nuevo_tip_settings','tip_settings');


	//Video Controls Window
	set_lang('nuevo_Brightness','langBrightness');
	set_lang('nuevo_Saturation','langSaturation');
	set_lang('nuevo_Contrast','langContrast');
	set_lang('nuevo_Smoothing','langSmoothing');
	set_lang('nuevo_Defaults','langDefaults');
	set_lang('nuevo_SettingsOk','langSettingsOk');
	
	//Embed Window
	set_lang('nuevo_NA','langNA');
	set_lang('nuevo_URL','langURL');
	set_lang('nuevo_EmbedCode','langEmbedCode');
	set_lang('nuevo_CopyLink','langCopyLink');
	set_lang('nuevo_CopyEmbed','langCopyEmbed');

	//Email Window
	set_lang('nuevo_YourName','langYourName');
	set_lang('nuevo_FriendEmail','langFriendEmail');
	set_lang('nuevo_Message','langMessage');
	set_lang('nuevo_Send','langSend');
	set_lang('nuevo_ThankYou','langThankYou');
	set_lang('nuevo_EmailMessage','langEmailMessage');
	set_lang('nuevo_EmailSendMore','langEmailSendMore');
	set_lang('nuevo_Error','langError');
	set_lang('nuevo_ErrorClose','langErrorClose');
	set_lang('nuevo_Invalid','langInvalid');
	set_lang('nuevo_NoMessage','langNoMessage');
	set_lang('nuevo_NoName','langNoName');
	set_lang('nuevo_SendError','langSendError');

	//Menu Window
	set_lang('nuevo_MenuGuide','langMenuGuide');
	set_lang('nuevo_MenuEmail','langMenuEmail');
	set_lang('nuevo_MenuShare','langMenuShare');
	set_lang('nuevo_MenuEmbed','langMenuEmbed');
	set_lang('nuevo_MenuResume','langMenuResume');
	set_lang('nuevo_MenuReplay','langMenuReplay');


	//Guide Window
	set_lang('nuevo_GuideNoMovies','langNoMovies');
	set_lang('nuevo_GuideRuntime','langRuntime');

	//Share Window
	set_lang('nuevo_ShareTitle','langShare');

	//Video Size Window
	set_lang('nuevo_VideoSize','langSize');
	set_lang('nuevo_VideoFit','langSize_fit');
	set_lang('nuevo_VideoAspect','langSize_aspect');
	set_lang('nuevo_VideoOriginal','langSize_original');
	set_lang('nuevo_VideoHalf','langSize_half');

    set_lang('nuevo_ZoomInfo','langZoomInfo');
	set_lang('nuevo_advertisement','langAdvertisement');

	
}

print "</config>";

function set_lang($value,$flashvar) {
	global $lng;
	if(isset($lng[$value])) {
		print "<".$flashvar.">".htmlspecialchars($lng[$value], ENT_QUOTES, 'UTF-8')."</".$flashvar.">\n";
	}
}


function check_member_limit()
{
	$uid    = ( isset($_SESSION['uid']) && is_numeric($_SESSION['uid']) ) ? $_SESSION['uid']: NULL;
	$email  = ( isset($_SESSION['email']) && strlen($_SESSION['email'])>0 ) ? $_SESSION['email'] : NULL;
	
	if($uid && $email) {
		return true;
	}
	return false;
}

?>