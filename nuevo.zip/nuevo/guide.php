<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
header("Content-Type: text/xml");
header("Expires: 0");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<guide>\n";
include('nvconfig.php');

if ( isset($_GET['key']) ) { $key = trim($_GET['key']); }


//related videos
$related=0; $count=0;

if($key) {

	$sql    = "SELECT VID, title, keyword FROM video WHERE vkey = '" .mysql_real_escape_string($key). "' LIMIT 1";
	$rs     = mysql_query($sql);

	$video = mysql_fetch_array($rs);
	
	$video['keyword']   = explode(' ', $video['keyword']);
	$sql_add        = NULL;
	if ( $video['keyword'] ) {
		$sql_add   .= " OR (";
		$sql_or     = NULL;    
		foreach ( $video['keyword'] as $keyword ) {
			$sql_add .= $sql_or. " keyword LIKE '%" .mysql_real_escape_string($keyword). "%'";
			$sql_or   = " OR ";
		}
		$sql_add   .= ")";
	}


	$sql  = "SELECT VID, title, duration, thumb FROM video WHERE active = '1' AND VID != " .$video['VID']. " AND ( title LIKE '%" .mysql_real_escape_string($video['title']). "%' " .$sql_add. ") ORDER BY title LIMIT 16";			
	$result     = mysql_query($sql);

	

	if($rs) {
		while ($row = mysql_fetch_array($result))	
		{
			$title = clr($row['title']);
			$title = php_truncate($title,50);
			$title=str_replace("/","",$title);
			$link=$config['BASE_URL']."/video/".$row['VID'].clean_seo_text($row['title']);
			$thumb=$config['TMB_URL']."/".$row['thumb']."_".$row['VID'].".jpg";
			$duration = date("i:s",$row['duration']);
			print "<item title=\"".$title."\" link=\"".$link."\" thumb=\"".$thumb."\" runtime=\"".$duration."\"/>\n";
			$related=1; $count=$count+1;
		}
	}
}


if($related==0 || $count<2) {

	$query = "select * from video WHERE active='1' order by VID desc limit 16"; 
	$result = mysql_query($query);
    if($result) {
		while ($row = mysql_fetch_array($result))	
		{
			$title = clr($row['title']);
			$title = php_truncate($title,50);
			$title=str_replace("/","",$title);
			$link=$config['BASE_URL']."/video/".$row['VID'].clean_seo_text($row['title']);
			$thumb=$config['TMB_URL']."/".$row['thumb']."_".$row['VID'].".jpg";
			$duration = date("i:s",$row['duration']);
			print "<item title=\"".$title."\" link=\"".$link."\" thumb=\"".$thumb."\" runtime=\"".$duration."\"/>\n";
		}

	}
}
print "</guide>";

function clr($string) {
	return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
function php_truncate($string, $length = 80, $etc = '...',$break_words = false)
{
    if ($length == 0)
        return '';
    if (strlen($string) > $length) {
        $length -= strlen($etc);
        if (!$break_words)
            $string = preg_replace('/\s+?(\S+)?$/', '', substr($string, 0, $length+1));
      
        return substr($string, 0, $length).$etc;
    } else
        return $string;
}
?>