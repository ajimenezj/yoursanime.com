<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*		Peel Effect	Plugin						*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************

//include('nvconfig.php');

$sql="SELECT * FROM nuevo__peel WHERE active = '1' ORDER BY rand() LIMIT 1";
$peel = mysql_query($sql);

if($peel) {
	
   if(mysql_num_rows($peel)==1) {
	    
		$peelrow=mysql_fetch_array($peel);
		if(strlen($peelrow['image'])>0 ) {
			print "<peel.image>".htmlentities($peelrow['image'])."</peel.image>\n";
			print "<peel.url>".htmlentities($peelrow['url'])."</peel.url>\n";
			print "<peel.target>".$peelrow['target']."</peel.target>\n";
			print "<peel.title><![CDATA[".$peelrow['title']."]]></peel.title>\n";
			print "<peel.subtitle><![CDATA[".$peelrow['subtitle']."]]></peel.subtitle>\n";
			$plugins.='peel,';
		}
   }
} 
?>