<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
header("Content-Type: text/xml");
header("Expires: 0");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
include('nvconfig.php');

print "<midroll>\n";

$channel='';
if ( isset($_GET['ch']) ) {
	$channel = trim($_GET['ch']);
}

$bool = array(0=>'false',1=>'true');
$mids=array();
$now=time();

if($channel != '') {
	
	$chans = explode("|",$channel);
	foreach($chans as $ch) {
		if(!$ch=='0') { $add.='channel = '.$ch.' OR '; }
	}
	$add =trim($add); $add=trim($add,'OR');$add=trim($add);


	$sql = "select * from nuevo__midroll where active = 1 and (".$add.") and expire>'".mysql_real_escape_string($now)."' order by RAND() limit 5";
	$result = mysql_query($sql);
	if($result) 
	{
		while ($row = mysql_fetch_array($result))
		{
			if(intval($row['duration'])>=3) $duration = intval($row['duration']); else $duration=intval($set['ad_duration']) ;
			$mids[] = array('ID' => $row['ID'], 'title' => $row['title'], 'description' => $row['description'], 'link' => $row['link'], 'url' => $row['url'], 'image' => $row['image'], 'duration' => $duration, 'count_url' => $config['PLAYER_URL']."/count_hit.php?tb=nuevo_midroll&amp;fl=hits&amp;id=".$row['ID'], 'views_url' => $config['PLAYER_URL']."/count_hit.php?tb=nuevo_midroll&amp;fl=views&amp;id=".$row['ID']);
		}
	}
}

if(count($mids)==0) {
	$sql = "select * from nuevo__midroll where active = 1 and channel = '0' and expire>'".mysql_real_escape_string($now)."' order by RAND() limit 5";
	$result = mysql_query($sql);
	if($result) 
	{
		while ($row = mysql_fetch_array($result))
		{
			if(intval($row['duration'])>=3) $duration = intval($row['duration']); else $duration=intval($set['ad_duration']) ;
			$mids[] = array('ID' => $row['ID'], 'title' => $row['title'], 'description' => $row['description'], 'link' => $row['link'], 'url' => $row['url'], 'image' => $row['image'], 'duration' => $duration);
		}
	}
}

if(count($mids)>0) {

	foreach($mids as $mid) {
		print "<ad>\n";
		print "<id>".$mid['ID']."</id>\n";
		print "<duration>".$mid['duration']."</duration>\n";
		print "<url>".flash_encode($mid['url'])."</url>\n";
		print "<title>".clr($mid['title'])."</title>\n";
		print "<description>".clr($mid['description'])."</description>\n";
		print "<display_url>".clr($mid['link'])."</display_url>\n";
		if(strlen($mid['image'])>0) {
			print "<image>".flash_encode($mid['image'])."</image>\n";
		}
		print "</ad>";
	}

	
}
print "</midroll>";
function clr($string) {
	return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
function flash_encode($string)
{
      $string = str_replace("?", "%3F", $string);
      $string = str_replace("=2", "%3D", $string);
      $string = str_replace("&", "%26", $string);
      return $string;
}
?>