<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
header("Content-Type: text/xml");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n";
print "<trackList>\n";  
include('nvconfig.php');

if ( isset($_GET['key']) ) {
	$VID = trim($_GET['key']);
} else {
	die('Invalid video key');
}

  $sql="select * from nuevo_player where ID='3'";
  $player = mysql_query($sql);
  if($player) {
		$prow=mysql_fetch_array($player);
  }

  $sql="select * from video where VID='".mysql_real_escape_string($VID)."' limit 1";
  $video = mysql_query($sql);
  if($video) 
  {
	$row=mysql_fetch_array($video);
	$file = $config['FLVDO_URL']."/".$row['VID'].".flv";

	
	$youtu = get_youtube($row['embed_code']);
	if(strlen($youtu)>0) { $file = $youtu; $filehd=''; }		
		
	//************************ HD file example *************************************

	//  Here you can assign HD video alternative. Use full URL for the video file.
	//  Let's say you keep HD alternatives in 'hdvideo' folder and has same name.
		
	//	Examlpe:
	//  if(file_exists($config['BASE_DIR']."/hdvideo/".$row['VID'].".flv") )
	//	{
	//		$filehd = $config['BASE_URL']."/hdvideo/".$row['VID'].".flv";
	//	}

	
	//************************ HD file example *************************************

	$vid = $row['VID'];
	$key = $row['vkey'];
	$channel = $row['channel'];
	$duration = $row['duration'];

	$url =$config['BASE_URL']."/video/".$row['VID'].clean_seo_text($row['title']);
	
	//$url =$config['BASE_URL']."/view_video.php?viewkey=".$key;
	
	$title = xml_utf8_encode($row['title']);
    
	$fullscreen = 'false'; if($prow['fullscreen_button']) $fullscreen='true';
	$embed =  '<![CDATA[<object width="'.$prow['player_width'].'" height="'.$prow['player_height'].'" data="'.$config['BASE_URL'].'nuevo/player.swf" type="application/x-shockwave-flash"><param name="movie" value="'.$config['BASE_URL'].'/nuevo/player.swf"><param name="flashvars" value="config='.$config['BASE_URL'].'/nuevo/cst.php?id=1"><param name="allowscriptaccess" value="always"><param name="allowfullscreen" value="'.$fullscreen.'"><param value="transparent" name="wmode"></object>]]>';
  
  } else {
	die('Invalid movie database');
  }

  // Main movie item here

  print "<track>\n";
  print "<file>".$file."</file>\n";
  if(isset($filehd)) { if(strlen($filehd)>0) print "<filehd>".$filehd."</filehd>\n"; }
  if(strlen($duration)>0) { print "<duration>".$duration."</duration>\n"; }
  print "<url>".$url."</url>\n";
  print "<id>".$key."</id>\n";
  print "<title>".$title."</title>\n";
  print "<embedcode>".$embed."</embedcode>\n";
  print "</track>\n";
  
  print "</trackList>\n";
  print "</playlist>";

?>