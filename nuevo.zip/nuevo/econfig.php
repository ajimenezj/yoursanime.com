<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
include('../include/config.php');
header("Content-Type: text/xml");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<config>\n"; 

$config['PLAYER_URL']	= $config['BASE_URL'].'/nuevo';

if ( isset($_GET['key'])) {
	$key = trim($_GET['key']);
} else {
	die('Invalid video key');
}

$sql="select VID, thumb, channel, embed_code from video where vkey='".mysql_real_escape_string($key)."' limit 1";
$video = mysql_query($sql);
if($video) {
	$row=mysql_fetch_array($video);
	$image=$config['TMB_URL']."/".$row['thumb']."_".$row['VID'].".jpg";
	$vid = $row['VID'];
	$channel = $row['channel'];
} else {
	die('Invalid video');
}

$sql="select * from nuevo__player where ID='1'";
$result = mysql_query($sql);
if($result) {
	$set1=mysql_fetch_array($result);
} else {
	die('Invalid player inerface');
}
$sql="select * from nuevo__player where ID='2'";
$result = mysql_query($sql);
if($result) {
	$set2=mysql_fetch_array($result);
} else {
	die('Invalid player inerface');
}


$bool = array(0=>'false',1=>'true');
$plugins = '';

// License key
print "<regkey>".$set1['regkey']."</regkey>\n";

// Skin file if other than default
if(strlen($set2['skin'])>0) { print "<skin>".$set2['skin']."</skin>\n"; }

// Playlist
print "<playlist>".$config['PLAYER_URL']."/playlist.php?key=".$key."</playlist>\n";


// Image
if(strlen($image)>0)	{ print "<image>".$image."</image>\n"; }

if($set2['guide_show']==1) {
if($set2['guide']!='') {
	print "<custom_guide>".$set2['guide']."</custom_guide>\n";
	print "<guide>".$config['PLAYER_URL']."/guide.php?key=".$key."</guide>\n";
} else {
	print "<related>".$config['PLAYER_URL']."/guide.php?key=".$key."</related>\n";
}
}

if(strlen($set1['statscript'])>0)	{ print "<statscript>".$set1['statscript']."</statscript>\n"; }


// Autostart
print "<autostart>".$bool[$set2['autostart']]."</autostart>\n"; 


// Stretching (aspect/fit)
if(strlen($set2['stretching'])>0)	{ print "<stretching>".$set2['stretching']."</stretching>\n"; }

//default volume (0-100)
if(strlen($set1['volume'])>0)		{ print "<volume>".$set1['volume']."</volume>\n"; }

//show tooltips (true/false)
if(strlen($set2['usetooltips'])>0)	{ print "<usetooltips>".$bool[$set2['usetooltips']]."</usetooltips>\n"; }

//show playlist (true/false)
print "<playlist_show>false</playlist_show>\n"; 


// Controlbar position (bottom/over)
if(isset($set2['playbar']))		{ print "<playbar>".$set2['playbar']."</playbar>\n";  }

// Offset X for controlbar with "over" position
if(isset($set2['playbaroffsetx']))		{ print "<playbaroffsetx>".$set2['playbaroffsetx']."</playbaroffsetx>\n";  }

// Offset X for controlbar with "over" position
if(isset($set2['playbaroffsety']))		{ print "<playbaroffsety>".$set2['playbaroffsety']."</playbaroffsety>\n";  }

// Controlbar opacity for "over" position
if(isset($set2['playbaralpha']))		{ print "<playbaralpha>".$set2['playbaralpha']."</playbaralpha>\n";  }

// Force video window to fullheight
if(isset($set2['fullheight']))		{ print "<fullheight>".$bool[$set2['fullheight']]."</fullheight>\n";  }

// Video quality (true/false)
if(isset($set1['videoquality']))		{ print "<videoquality>".$bool[$set1['videoquality']]."</videoquality>\n";  }

// Buffer length
if(isset($set1['bufferlength']))		{ print "<bufferlength>".$set1['bufferlength']."</bufferlength>\n"; }

// Show tooltips
if(isset($set2['usetooltips'])>0)	{ print "<usetooltips>".$bool[$set2['usetooltips']]."</usetooltips>\n"; }

// Show viral icons
if(isset($set2['viral_show'])>0)		{ print "<viral_show>".$bool[$set2['viral_show']]."</viral_show>\n"; }


// Viral icons Y Offset
if(isset($set2['viral_offset'])>0)	{ print "<viral_offset>".$set2['viral_offset']."</viral_offset>\n"; }

// Viral icons align (left/right)
if(isset($set2['viral_align'])>0)	{ print "<viral_align>".$set2['viral_align']."</viral_align>\n"; }

// Viral icons back color on mouse over
if(strlen($set2['viral_backhover'])==6)	{ print "<viral_backhover>".$set2['viral_backhover']."</viral_backhover>\n"; }

// Viral icons text color on mouse over
if(strlen($set2['viral_texthover'])>0)	{ print "<viral_texthover>".$set2['viral_texthover']."</viral_texthover>\n"; }

// Logo
if(strlen($set1['logo'])>0 && $set2['show_logo']=='1') { 
	
	//Image URL
	print "<logo>".$set1['logo']."</logo>\n";

	//URL to go when logo clicked
	if(strlen($set1['logourl'])>0) { print "<logourl>".$set1['logourl']."</logourl>\n"; }

	//Logo position
	if(strlen($set1['logoalign'])==2)	{ print "<logoalign>".$set1['logoalign']."</logoalign>\n"; }

	//logo position offset (X and Y)
	if(isset($set1['logooffsetx'])>0)		{ print "<logooffsetx>".$set1['logooffsetx']."</logooffsetx>\n"; }
	if(isset($set1['logooffsety'])>0)		{ print "<logooffsety>".$set1['logooffsety']."</logooffsety>\n"; }

}

// Show hd icon
if(isset($set1['hdicon'])>0)			{ print "<hdicon>".$bool[$set1['hdicon']]."</hdicon>\n"; }

// HD icon align (left/right)
if(isset($set1['hdalign'])>0)		{ print "<hdalign>".$set1['hdalign']."</hdalign>\n"; }

// Play HD content first (false/true)
if(isset($set1['hdfirst'])>0)		{ print "<hdfirst>".$set1['hdfirst']."</hdfirst>\n"; }

// Slomo interval
if(strlen($set1['slomointerval'])>0)		{ print "<slomointerval>".$set1['slomointerval']."</slomointerval>\n"; }

//show ID3 info for audio files
//if(isset($set['showId3'])>0)			{ print "<showId3>".$bool[$set['showId3']]."</showId3>\n"; }

//ID3 background opacity (0-100)
//if(isset($set['id3opacity'])>0)		{ print "<id3opacity>".$set['id3opacity']."</id3opacity>\n"; }


//default provider
if(strlen($set1['provider'])>0) {
	
	//Provider
	print "<provider>".$set1['provider']."</provider>\n";

	//Streamer script or RTMP server URL
	if(strlen($set1['streamer'])>0)		{ print "<streamer>".$set1['streamer']."</streamer>\n"; }

	//Request param for HTTP streaming
	if(strlen($set1['httpparam'])>0)		{ print "<httpparam>".$set1['httpparam']."</httpparam>\n"; }
}

//show email window
if(isset($set2['email_show']))		{ print "<email_show>".$bool[$set2['email_show']]."</email_show>\n"; }

//show share window
if(isset($set2['share_show']))		{ print "<share_show>".$bool[$set2['share_show']]."</share_show>\n"; }


//show embed code
if(isset($set2['embed_show']))		{ print "<embed_show>".$bool[$set2['embed_show']]."</embed_show>\n"; }

//show guide window
if(isset($set2['guide_show']))		{ print "<guide_show>".$bool[$set2['guide_show']]."</guide_show>\n"; }

//playlist button
print "<playlist_button>false</playlist_button>\n";

//replay button
if(isset($set2['replay_button']))		{ print "<replay_button>".$bool[$set2['replay_button']]."</replay_button>\n"; }

//slomo button
if(isset($set2['slomo_button']))			{ print "<slomo_button>".$bool[$set2['slomo_button']]."</slomo_button>\n"; }

//zoom button
if(isset($set2['zoom_button']))			{ print "<zoom_button>".$bool[$set2['zoom_button']]."</zoom_button>\n"; }

//video settings button
if(isset($set2['settings_button']))		{ print "<settings_button>".$bool[$set2['settings_button']]."</settings_button>\n"; }

//volume button
if(isset($set2['volume_button']))		{ print "<volume_button>".$bool[$set2['volume_button']]."</volume_button>\n"; }

//size window button
if(isset($set2['size_button']))			{ print "<size_button>".$bool[$set2['size_button']]."</size_button>\n"; }

//fullscreen button
if(isset($set2['fullscreen_button']))	{ print "<fullscreen_button>".$bool[$set2['fullscreen_button']]."</fullscreen_button>\n"; }

//menu button
if(isset($set2['menu_button']))			{ print "<menu_button>".$bool[$set2['menu_button']]."</menu_button>\n"; }

//resize button
print "<resize_button>false</resize_button>\n"; 

//Flash context menu on right click
if($set1['menuitem']==1)  {
	print "<menuitem>true</menuitem>\n";
	if(strlen($set1['menutext'])>0)
		print "<menutext>".$set1['menutext']."</menutext>\n";
	if(strlen($set1['menulink'])>0)	
		print "<menulink>".$set1['menulink']."</menulink>\n";
} else {
	print "<menuitem>false</menuitem>\n>";
}

// RSS URL
if(strlen($set1['rss_url'])>0) print "<rss_url>".$set1['rss_url']."</rss_url>\n";


//Video window on click action
print "<onclick>".$set2['onclick']."</onclick>\n";

print "<linktarget>_blank</linktarget>\n";

//Colors
if(strlen($set2['screencolor'])>0)		{ print "<screencolor>".$set2['screencolor']."</screencolor>\n"; }
if(strlen($set2['hovercolor'])>0)		{ print "<hovercolor>".$set2['hovercolor']."</hovercolor>\n"; }



// Midroll Plugin

if($set2['plugin_midroll']==1) {

	$plugins='midroll,';
	print "<midroll.xml>".$config['PLAYER_URL']."/midroll.php?ch=".$channel."</midroll.xml>\n";
	
	$sql="SELECT * FROM nuevo__midroll_settings";
	$result=mysql_query($sql);
	if($result) {
	
	$rows = mysql_fetch_array($result);
	print "<midroll.background>".$rows['background']."</midroll.background>\n";
	print "<midroll.opacity>".$rows['opacity']."</midroll.opacity>\n";
	print "<midroll.outline>".$bool[$rows['outline']]."</midroll.outline>\n";
	print "<midroll.titlecolor>".$rows['titlecolor']."</midroll.titlecolor>\n";
	print "<midroll.desccolor>".$rows['desccolor']."</midroll.desccolor>\n";
	print "<midroll.linkcolor>".$rows['linkcolor']."</midroll.linkcolor>\n";
	print "<midroll.hovercolor>".$rows['hovercolor']."</midroll.hovercolor>\n";
	print "<midroll.aboutcolor>".$rows['aboutcolor']."</midroll.aboutcolor>\n";
	if(strlen($rows['abouttext'])>0 && strlen($rows['midroll.abouturl'])>0) {
		print "<midroll.abouttext>".$rows['abouttext']."</amidroll.bouttext>\n";
		print "<midroll.abouturl>".$rows['abouturl']."</midroll.abouturl>\n";
	}
	print "<midroll.canclose>".$bool[$rows['canclose']]."</midroll.canclose>\n";
	print "<midroll.defstart>".$rows['defstart']."</midroll.defstart>\n";
	print "<midroll.defruntime>".$rows['defruntime']."</midroll.defruntime>\n";
	
	}
}

// Overlay Ads

if($set2['plugin_overlay']==1) {

$overlay=0;$add='';

$add =trim($add); $add=trim($add,'OR');$add=trim($add);
$sql = "select * from nuevo__overlay where active = 1 and channel='".$channel."' and expire>'".mysql_real_escape_string(time())."' order by RAND() limit 1";
$result=mysql_query($sql);
if($result) {
	if(mysql_num_rows($result)>0) {
		$overlay=1;
		$plugins.='overlay,';
		$ov=mysql_fetch_array($result);
		print "<overlay.id>".$ov['ID']."</overlay.id>\n";
		print "<overlay.media>".flash_encode($ov['media'])."</overlay.media>\n";
		print "<overlay.url>".flash_encode($ov['url'])."</overlay.url>";
		print "<overlay.target>".$ov['target']."</overlay.target>\n";
		print "<overlay.start>".$ov['start']."</overlay.start>\n";
		print "<overlay.runtime>".$ov['runtime']."</overlay.runtime>\n";
	}
}
}

if($overlay != 1) {
$sql="select * from nuevo__overlay where channel='0' AND active='1' ORDER BY RAND() LIMIT 1";
$result=mysql_query($sql);
if($result) {
  if(mysql_num_rows($result)>0) {
	$plugins.=',overlay';
	$ov=mysql_fetch_array($result);
	print "<overlay.id>".$ov['ID']."</overlay.id>\n";
	print "<overlay.media>".flash_encode($ov['media'])."</overlay.media>\n";
	print "<overlay.url>".flash_encode($ov['url'])."</overlay.url>";
	print "<overlay.target>".$ov['target']."</overlay.target>\n";
	print "<overlay.start>".$ov['start']."</overlay.start>\n";
  }
}
}

// Ticker news
if($set2['plugin_ticker']==1) {
$sql="select * from nuevo__ticker where active='1' ORDER BY RAND() LIMIT 1";
$result=mysql_query($sql);
if($result) {
  if(mysql_num_rows($result)>0) {
	$tck=mysql_fetch_array($result);
	$plugins.='ticker,';
	print "<ticker.text><![CDATA[".$tck['text']."]]></ticker.text>\n";
	print "<ticker.start>".$tck['start']."</ticker.start>\n";
	print "<ticker.runtime>".$tck['runtime']."</ticker.runtime>\n";
	print "<ticker.scrollspeed>".$tck['scrollspeed']."</ticker.scrollspeed>\n";
	print "<ticker.opacity>".$tck['opacity']."</ticker.opacity>\n";
	print "<ticker.position>".$tck['position']."</ticker.position>\n";
	if(strlen($tck['url'])>0) {
		print "<ticker.url>".flash_encode($tck['url'])."</ticker.url>\n";
		print "<ticker.target>".$tck['urltarget']."</ticker.target>\n";
	}
  }
}
}

include('peel.php');

if(strlen($plugins)>0) { print "<plugins>".trim($plugins,",")."</plugins>\n"; }


if(file_exists($config['BASE_DIR']. '/language/' .$_SESSION['language']. '/nuevo.lang.php')) 
{
  include $config['BASE_DIR']. '/language/' .$_SESSION['language']. '/nuevo.lang.php'; $nuevo_lang=true;

	if($lng) {
		foreach ( $lng as $key => $value )
		{
			$key = str_replace('nuevo_','',$key);
			print "<".$key.">".clr($value)."</".$key.">\n";
		}	
	}
}

print "</config>";



function check_member_limit()
{
	$uid    = ( isset($_SESSION['UID']) && is_numeric($_SESSION['UID']) ) ? $_SESSION['UID']: NULL;
	$email  = ( isset($_SESSION['EMAIL']) && strlen($_SESSION['EMAIL'])>0 ) ? $_SESSION['EMAIL'] : NULL;
	
	if($uid && $email) {
		return true;
	}
	return false;
}

function clr($string) {
	return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}
function flash_encode($string)
{
      $string = str_replace("?", "%3F", $string);
      $string = str_replace("=2", "%3D", $string);
      $string = str_replace("&", "%26", $string);
      return $string;
}

?>