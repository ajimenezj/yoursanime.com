<?php
//***********************************************
//*		NuevoLab FLASH PLAYER ver. 5.0			*
//*												*
//*		http://www.nuevolab.com					*
//*		email: support@nuevolab.com				*
//*												*
//***********************************************
header("Content-Type: text/xml");
print "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n";
print "<playlist version=\"1\" xmlns=\"http://xspf.org/ns/0/\">\n";
print "<trackList>\n";  
include('nvconfig.php');

if ( isset($_GET['type']) ) {
	$type = trim($_GET['type']);
} else {
	die('Invalid playlist type');
}
if ( isset($_GET['itm'])) {
	$items = trim($_GET['itm']);
} else {
	$items = 10;
}
if ( isset($_GET['us'])) {
	$user= intval($_GET['us']);
}

$sql="select * from nuevo__player where ID='4'";
$player = mysql_query($sql);
if($player) {
	$prow=mysql_fetch_array($player);
}

if($type=='user' && $user<1) {
	die('Invalid playlist user');
}

switch ( $type) {

	case 'recent':
		$sql = "select * from video WHERE type='public' and active='1' ORDER BY addtime DESC LIMIT ".$items;
		break;
	case 'most':
		$sql = "select * from video WHERE type='public' and active='1' ORDER BY viewnumber DESC LIMIT ".$items;
		break;
    case 'rate':
		$sql = "select * from video WHERE type='public' and active='1' ORDER BY (v.ratedby*v.rate) DESC LIMIT ".$items;
		break;
	case 'user':
		$sql = "select * from video WHERE type='public' and active='1' and UID = '".mysql_real_escape_string($user)."' ORDER BY addtime DESC LIMIT ".$items;
		break;
}

echo $sql;

$rs = mysql_query($sql);

if ( mysql_num_rows($rs)>0 ) 
{   
  while ($row = mysql_fetch_array($rs))	
  {
	 if($row['embed_code']=='' || strstr($row['embed_code'],'youtube.com') ) 
	 {
		 
		$file = $config['FLVDO_URL']."/".$row['VID'].".flv";
	
		//************************ HD file example *************************************

		//  Here you can assign HD video alternative. Use full URL for the video file.
		//  Let's say you keep HD alternatives in 'hdvideo' folder and has same name.
		
		//	Examlpe:
		//  if(file_exists($config['BASE_DIR']."/hdvideo/".$row['VID'].".flv") )
		//	{
		//		$filehd = $config['BASE_URL']."/hdvideo/".$row['VID'].".flv";
		//	}
		//************************ HD file example *************************************

		$youtu = get_youtube($row['embed_code']);
		if(strlen($youtu)>0) { $file = $youtu; $filehd=''; }		
		
		$vid = $row['VID'];
		$duration = $row['duration'];
		$id = $row['vkey'];
		$thumb = $config['BASE_URL'].'/thumb/'.$row['thumb'].'_'.$vid.'.jpg';

		$url =$config['BASE_URL']."/video/".$row['VID'].clean_seo_text($row['title']);

		//$url =$config['BASE_URL']."/view_video.php?viewkey=".$key;

		$title = xml_utf8_encode($row['title']);
    
		$fullscreen = 'false'; if($prow['fullscreen_button']) $fullscreen='true';
		$embed = '<![CDATA[<object width="'.$prow['player_width'].'" height="'.$prow['player_height'].'" data="'.$config['BASE_URL'].'nuevo/player.swf" type="application/x-shockwave-flash"><param name="movie" value="'.$config['BASE_URL'].'/nuevo/player.swf"><param name="flashvars" value="config='.$config['BASE_URL'].'/nuevo/cst.php?id='.$vid.'"><param name="allowscriptaccess" value="always"><param value="transparent" name="wmode"><param name="allowfullscreen" value="'.$fullscreen.'"></object>]]>';


		// Assign video item here

		print "<track>\n";
		print "<file>".$file."</file>\n";
		if(isset($filehd)) { if(strlen($filehd)>0) print "<filehd>".$filehd."</filehd>\n"; }
		if(strlen($duration)>0) { print "<duration>".$duration."</duration>\n"; }
		print "<url>".$url."</url>\n";
		print "<id>".$id."</id>\n";
		print "<title>".$title."</title>\n";
		print "<thumb>".$thumb."</thumb>\n";
		print "<image>".$thumb."</image>\n";
		print "<embedcode>".$embed."</embedcode>\n";
		print "</track>\n";
	 }
  }
}


print "</trackList>\n";
print "</playlist>";

?>