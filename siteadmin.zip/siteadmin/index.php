<?php
define('_VALID', true);
require('../include/config.php');
require('../include/function.php');
require('../include/function_admin.php');

chk_admin_login();

$module             = ( isset($_GET['m']) && $_GET['m'] != '' ) ? trim($_GET['m']) : 'main';
$module_template    = 'index.tpl';
$modules_allowed    = array('main','mobile','seo','check', 'mail', 'modules', 'static', 'media', 'miscellaneous', 'permissions', 'sessions', 'bandwidth',
                            'bans', 'emails', 'emailadd', 'emailedit', 'packages', 'packageadd', 'packageedit', 'packageview', 
                            'advertise', 'advertiseedit', 'polls', 'polladd', 'polledit', 'pollview', 'player', 'playeradd', 'playeredit');
if ( in_array($module, $modules_allowed) ) {
    $module_template = ( $module == 'main' ) ? 'index.tpl' : 'index_' .$module. '.tpl';
    require 'modules/index/' .$module. '.php';
} else {
    $err = 'Invalid Settings Module!';
}

STemplate::assign('err', $err);
STemplate::assign('msg', $msg);
STemplate::assign('active_menu', 'index');
STemplate::display('siteadmin/header.tpl');
STemplate::display('siteadmin/leftmenu/index.tpl');
STemplate::display('siteadmin/' .$module_template);
STemplate::display('siteadmin/footer.tpl');
?>