<div align="center" id="dialogLoadMessage" style="display:block;">
	<table width="100%" height="90%">
		<tr>
			<td align="center" valign="middle"><div id="loadMessage"><?php echo $lang['please_wait']; ?></div></td>
		</tr>
	</table>
</div>
<?php ob_start(); ?>