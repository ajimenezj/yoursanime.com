<?php
define('_VALID', true);
require('../include/config.php');


require('../include/function.php');
require('../include/function_admin.php');
chk_admin_login();

$err='';$msg='';$errors=array();$messages=array();
$errors=array();
$messages=array();

if ( isset($_GET['err']) ) {
    $errors[]   = trim($_GET['err']);
}

if ( isset($_GET['msg']) ) {
    $messages[] = trim($_GET['msg']);
}

$module             = ( isset($_GET['m']) && $_GET['m'] != '' ) ? trim($_GET['m']) : 'player';
$module_template    = 'nuevo_player.tpl';
$module_keep        = NULL;
$module_template    = 'nuevo_player.tpl';
$modules_allowed    = array('player',  'vimeo', 'embed', 'analytics', 'anyad', 'custom', 'peel', 'peelnew', 'peeledit', 'limit', 'stats', 'midrollsettings', 'midroll', 'midrollnew', 'midrolledit', 'overlay', 'overlaynew', 'overlayedit', 'preroll', 'prerollnew', 'prerolledit', 'labels', 'labelnew', 'labeledit');

if ( in_array($module, $modules_allowed) ) {
    $module_template =  'nuevo_' .$module. '.tpl';
    require 'modules/nuevo/' .$module. '.php';
} else {
	if(file_exists('modules/nuevo/'.$module.'.php')) {
		$module_template =  'nuevo_' .$module. '.tpl';
		require 'modules/nuevo/' .$module. '.php';
	} else {
		$err = 'Invalid Settings Module!';
	}
}

STemplate::assign('errors', $errors);
STemplate::assign('messages', $messages);
STemplate::assign('err', $err);
STemplate::assign('msg', $msg);
STemplate::assign('module', $module_keep);
STemplate::assign('active_menu', 'nuevo');
STemplate::display('siteadmin/header.tpl');
STemplate::display('siteadmin/leftmenu/nuevo.tpl');
STemplate::display('siteadmin/' .$module_template);
STemplate::display('siteadmin/footer.tpl');