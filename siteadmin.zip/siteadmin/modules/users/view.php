<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$user  = array();
$UID   = ( isset($_GET['UID']) && is_numeric($_GET['UID']) ) ? trim($_GET['UID']) : NULL;
settype($UID, 'integer');
if ( !$UID ) 
    $err = 'Invalid user ID!';

if ( $err == '' ) {
    if ( isset($_GET['a']) && $_GET['a'] != '' ) {
        $action = trim($_GET['a']);
        if ( $action == 'activate' ) {
            $sql = "UPDATE signup SET account_status = 'Active' WHERE UID = '" .mysql_real_escape_string($UID). "' LIMIT 1";
            $conn->execute($sql);
            if ( mysql_affected_rows() == 1 )
                $msg = 'User activated successfuly!';
            else
                $err = 'Failed to activate user!';
        }
        
        if ( $action == 'suspend' ) {
            $sql = "UPDATE signup SET account_status = 'Inactive' WHERE UID = '" .mysql_real_escape_string($UID). "' LIMIT 1";
            $conn->execute($sql);
            if ( mysql_affected_rows() == 1 )
                $msg = 'User suspended successfuly!';
            else
                $err = 'Failed to suspend user!';
        }
    }

    $sql    = "SELECT * FROM signup WHERE UID = '" .$UID. "' LIMIT 1";
    $rs     = $conn->execute($sql);
    if ( mysql_affected_rows() == 1 )
        $user = $rs->getrows();
    else
        $err = 'This user does not exist! Invalid user ID?';
}

STemplate::assign('user', $user);

?>
