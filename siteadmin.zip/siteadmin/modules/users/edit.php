<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require '../include/country.class.php';
$country            = new I18N_ISO_3166();
$countries_twocode  = $country->twocountry;
$countries          = array();
foreach ( $countries_twocode as $code => $value )
    $countries[] = $value;

$user  = array();
$UID   = ( isset($_GET['UID']) && is_numeric($_GET['UID']) ) ? trim($_GET['UID']) : NULL;
settype($UID, 'integer');
if ( !$UID ) 
    $err = 'Invalid user ID!';

if ( $err == '' ) {
    if ( isset($_POST['edit_user']) ) {
        $email              = $filterObj->process(trim($_POST['email']));
        $fname              = $filterObj->process(trim($_POST['fname']));
        $lname              = $filterObj->process(trim($_POST['lname']));
        $town               = $filterObj->process(trim($_POST['town']));
        $city               = $filterObj->process(trim($_POST['city']));
        $zip                = $filterObj->process(trim($_POST['zip']));
        $aboutme            = $filterObj->process(trim($_POST['aboutme']));
        $fav_movies         = $filterObj->process(trim($_POST['fav_movie_show']));
        $fav_music          = $filterObj->process(trim($_POST['fav_music']));
        $fav_books          = $filterObj->process(trim($_POST['fav_book']));
        $occupation         = $filterObj->process(trim($_POST['occupation']));
        $interests          = $filterObj->process(trim($_POST['interest_hobby']));
        $company            = $filterObj->process(trim($_POST['company']));
        $school             = $filterObj->process(trim($_POST['school']));
        $website            = trim($_POST['website']);
        $country            = trim($_POST['country']);
        $gender             = trim($_POST['gender']);
        $relation           = trim($_POST['relation']);
        $website            = trim($_POST['website']);
        $password           = trim($_POST['password']);
        $password_confirm   = trim($_POST['password_confirm']);
        $video_viewed       = trim($_POST['video_viewed']);
        $profile_viewed     = trim($_POST['profile_viewed']);
        $watched_video      = trim($_POST['watched_video']);
        $account_status     = trim($_POST['account_status']);
        $emailverified      = trim($_POST['emailverified']);
        
        if ( $email == '' )
            $err = 'Email field cannot be blank!';
        elseif ( !check_email($email) )
            $err = 'Email is not a valid email address!';
        else {
            $sql = "SELECT email FROM signup WHERE email = '" .mysql_real_escape_string($email). "' AND UID != '" .mysql_real_escape_string($UID). "' LIMIT 1";
            $conn->execute($sql);
            if ( mysql_affected_rows() > 0 )
                $err = 'Email is already used by another user!';
        }
        
        if ( $password != '' && $password != $password_confirm )
            $err = 'Password and confirmation password are not the same!';
        
        if ( $_FILES['avatar']['tmp_name'] != '' && $err == '' ) {
            $photo      = $UID;
            $imagesize  = getimagesize($_FILES['avatar']['tmp_name']);
            if ( $imagesize['2'] == 1 )
                $photo .= '.gif';
            elseif ( $imagesize['2'] == 2 )
                $photo .= '.jpg';
            elseif ( $imagesize['2'] == 3 )
                $photo .= '.png';
            
            if ( $photo == $UID. '.gif' or $photo == $UID. '.jpg' or $photo == $UID. '.png' ) {                
                $sql        = "SELECT photo FROM signup WHERE UID = '" .mysql_real_escape_string($UID). "' LIMIT 1";
                $rs         = $conn->execute($sql);
                $photo_cur  = $rs->fields['photo'];
                if ( $photo_cur != '' ) {
                    @unlink($config['PHO_DIR']. '/' .$photo_cur);
                }
                
                if ( move_uploaded_file($_FILES['avatar']['tmp_name'], $config['PHO_DIR']. '/' .$photo) ) {
                    @chmod($config['PHO_DIR']. '/' .$photo, 0644);
                    if ( $imagesize['0'] > $config['photowidth'] ) {
                        $src    = $config['PHO_DIR']. '/' .$photo;
                        $dst    = $config['PHO_DIR']. '/' .$photo;
                        create_picture($src, $dst, $config['photowidth']);
                    }
                    
                    $photo_new = true;
                } else
                    $err = 'Failed to upload user avatar image (invalid permissions)!';
        
            } else
                $err = 'Invalid avatar image format!';
        }
        
        if ( $err == '' ) {
            settype($video_viewed, 'integer');
            settype($profile_viewed, 'integer');
            settype($watched_video, 'integer');
            
            $sql_add = NULL;  
            if ( $password != '' )
                $sql_add = " ,pwd = '" .md5($password). "'";
            
            if ( isset($_POST['delete_avatar']) && $_POST['delete_avatar'] == 'on' ) {
                $sql_add .= " ,photo = ''";
            }
            
            if ( isset($photo_new) ) {
                $sql_add .= " ,photo = '" .mysql_real_escape_string($photo). "'";
            }
            
            $sql = "UPDATE signup SET email = '" .mysql_real_escape_string($email). "', fname = '" .mysql_real_escape_string($fname). "',
                                      lname = '" .mysql_real_escape_string($lname). "', gender = '" .mysql_real_escape_string($gender). "',
                                      relation = '" .mysql_real_escape_string($relation). "', aboutme = '" .mysql_real_escape_string($aboutme). "',
                                      town = '" .mysql_real_escape_string($town). "', city = '" .mysql_real_escape_string($city). "',
                                      zip = '" .mysql_real_escape_string($zip) ."', country = '" .mysql_real_escape_string($country). "',
                                      occupation = '" .mysql_real_escape_string($occupation). "', company = '" .mysql_real_escape_string($company). "',
                                      school = '" .mysql_real_escape_string($school). "', interest_hobby = '" .mysql_real_escape_string($interests). "',
                                      fav_movie_show = '" .mysql_real_escape_string($fav_movies). "', fav_music = '" .mysql_real_escape_string($fav_music). "',
                                      fav_book = '" .mysql_real_escape_string($fav_books). "', website = '" .mysql_real_escape_string($website). "',
                                      video_viewed = '" .mysql_real_escape_string($video_viewed). "', profile_viewed = '" .mysql_real_escape_string($profile_viewed). "',
                                      watched_video = '" .mysql_real_escape_string($watched_video). "', emailverified = '" .mysql_real_escape_string($emailverified). "',
                                      account_status = '" .mysql_real_escape_string($account_status). "'" .$sql_add. " WHERE UID = '" .mysql_real_escape_string($UID). "' LIMIT 1";
            $conn->execute($sql); 
            if ( mysql_affected_rows() == 1 )
                $msg = 'User information updated successfuly!';
            else
                $err = 'Failed to update user or nothing changed!';
        }
    }

    $sql    = "SELECT * FROM signup WHERE UID = '" .$UID. "' LIMIT 1";
    $rs     = $conn->execute($sql);
    if ( mysql_affected_rows() == 1 )
        $user = $rs->getrows();
    else
        $err = 'This user does not exist! Invalid user ID?';
}

STemplate::assign('user', $user);
STemplate::assign('countries', $countries);
?>
