<?php
defined('_VALID') or die('Restricted Access!');
chk_admin_login();

if ( isset($_POST['update_comments']) ) {

	if($_POST['photo'] == '1') $photo=1; else $photo=0;
	if($_POST['allow_url'] == '1') $allow_url=1; else $allow_url=0;
	$min_length = intval($_POST['min_length']);
	$max_length = intval($_POST['max_length']);
	$banlist = $_POST['banlist'];
	$ban_replace = trim($_POST['ban_replace']);
	$moderator = trim($_POST['moderator']);
	$per_page = intval($_POST['per_page']);
	if($_POST['notify'] == '1') $notify=1; else $notify=0;
	$email_body = trim($_POST['email_body']);
	$email_subject = trim($_POST['email_subject']);
	if($_POST['allow_smileys'] == '1') $allow_smileys=1; else $allow_smileys=0;
	if($_POST['allow_edit'] == '1') $allow_edit=1; else $allow_edit=0;
	$max_smileys = intval($_POST['max_smileys']);

	$sql = "UPDATE comments_settings SET 
		photo = '".mysql_real_escape_string($photo)."', 
		min_length = '".mysql_real_escape_string($min_length)."',
		max_length = '".mysql_real_escape_string($max_length)."',	
		banlist = '".mysql_real_escape_string($banlist)."',
		ban_replace = '".mysql_real_escape_string($ban_replace)."',
		moderator = '".mysql_real_escape_string($moderator)."',
		per_page = '".mysql_real_escape_string($per_page)."',
		allow_smileys = '".mysql_real_escape_string($allow_smileys)."',
		allow_edit = '".mysql_real_escape_string($allow_edit)."',
		max_smileys = '".mysql_real_escape_string($max_smileys)."',
		notify = '".mysql_real_escape_string($notify)."',
		email_body = '".mysql_real_escape_string($email_body)."',
		email_subject = '".mysql_real_escape_string($email_subject)."',
		allow_url = '".mysql_real_escape_string($allow_url)."' 
		WHERE ID = '1'";
	$conn->execute($sql);

    $msg = 'Comments settings updated!';
}


$sql = "select * from comments_settings WHERE ID = '1' LIMIT 1";
$rs = $conn->execute($sql);
$res = $rs->getrows($rs);
STemplate::assign('comment', $res['0']);
?>
