<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require $config['BASE_DIR']. '/classes/pagination.class.php';

$remove         = NULL;

if ( isset($_GET['a']) && $_GET['a'] == 'delete' ) {
    $COMID = ( isset($_GET['COMID']) && is_numeric($_GET['COMID']) ) ? $_GET['COMID'] : NULL;
    if ( $COMID ) {
        $sql = "DELETE FROM comments WHERE COMID = '" .mysql_real_escape_string($COMID). "' LIMIT 1";
        $conn->execute($sql);
        if ( $conn->Affected_Rows() == 1 ) {
            $msg = 'Comment deleted successfully!';
			if ( isset($_GET['VID']) && $_GET['VID'] > 0 ) {
			  $vid  = ( isset($_GET['VID']) && is_numeric($_GET['VID']) ) ? $_GET['VID'] : NULL;
			  $sql= "UPDATE video SET com_num = com_num-1 WHERE VID = '".mysql_real_escape_string($vid)."'";
			  $conn->execute($sql);
			}
        } else {
            $err = 'Failed to delete comment! Invalid comment id!?';
        }
    } else {
        $err = 'Invalid comment id or not set!';
    }
    $remove = '&a=delete&COMID=' .$COMID;
}

$query          = constructQuery('comments');
$sql            = $query['count'];
$rs             = $conn->execute($sql);
$total_comments	= $rs->fields['total'];
$pagination     = new Pagination($query['page_items']);
$limit          = $pagination->getLimit($total_comments);
$paging         = $pagination->getAdminPagination($remove);
$sql            = $query['select']. " LIMIT " .$limit;
$rs             = $conn->execute($sql);
$comments       = $rs->getrows();


function constructQuery($module)
{
    $query_module = '';
    $query              = array();
    $query_select	 = "SELECT * FROM comments";
	$query_count		 = "SELECT count(*) AS total FROM comments";
    $query_add          = ( $query_module != '' ) ? " AND" : " WHERE";
    $query_option       = array();
    $option             = array('VID' => '', 'commen' => '','COMID' => '', 'UID' => '', 'sort' => 'COMID', 'order' => 'DESC', 'display' => 20);
	$option             = ( isset($_SESSION['search_comments']) ) ? $_SESSION['search_comments'] : $option;
    if ( isset($_POST['search_comments']) ) {
        $option['COMID']			= trim($_POST['COMID']);
		$option['VID']			= trim($_POST['VID']);
        $option['commen']		= trim($_POST['commen']);
		$option['UID']			= trim($_POST['UID']);
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
        $_SESSION['search_comments'] = $option;
    }  

	

    if ( $option['VID'] != '') {
        $query_option[] = $query_add. " VID = '" .mysql_real_escape_string($option['VID']). "'";
        $query_add      = " AND";
    }

    if ( $option['COMID'] != '' ) {
        $query_option[] = $query_add. " COMID = '" .mysql_real_escape_string($option['ID']). "'";
        $query_add      = " AND";
    }

    if ( $option['UID'] != '' ) {
        $query_option[] = $query_add. " UID = '" .mysql_real_escape_string($option['UID']). "'";
        $query_add      = " AND";
    }

    if ( $option['commen'] != '' ) {
        $query_option[] = $query_add. " commen LIKE '%" .mysql_real_escape_string($option['commen']). "%'";
        $query_add      = " AND";
    }



    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    
    STemplate::assign('option', $option);
	return $query;
}


//STemplate::assign('page', $page);
STemplate::assign('comments', $comments);
STemplate::assign('total', $total_comments);
STemplate::assign('paging', $paging);
?>
