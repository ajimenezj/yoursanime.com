<?php

chk_admin_login();


$config['temp_video_folder'] = $config['BASE_DIR']."/tmp/ftp";
$config['default_user'] = "";
$config['use_user_list'] = true;

$chn=array();
$video = array();
$video['channel'] = array();

if(isset($_REQUEST['create_video']))
{
                
		$_REQUEST['title'] = stripslashes($_REQUEST['title']);
		$_REQUEST['description'] = stripslashes($_REQUEST['description']);
		$_REQUEST['keyword'] = stripslashes($_REQUEST['keyword']);
		$count_channels = count($_REQUEST['channel']);
        
		$keyword = $_REQUEST['keyword'];
		$ltitle = strlen($_REQUEST['title']);
		$ldesc = strlen($_REQUEST['description']);
		$lkey = strlen($_REQUEST['keyword']);
		$new_vid = $_REQUEST['new_vid'];
		

		if($_REQUEST['def_user']=="" && $_REQUEST['user'] == "")
            $err = "Owner of the video not defined.<br />Please define it in configuration file or set user list feature enabled."; 
		else if($ltitle < 3) 
			$err = "Please provide a video title with minimum 3 characters."; 
		else if($ldesc< 3) 
			$err = "Please provide a description with min of 3 characters."; 
		else if($lkey < 3) 
			$err = "Please provide tag(s)."; 
		else if($new_vid=="")
			$err="Please select video file";
		else if($count_channels<1)
            $err = "Please check at least 1 channel";
		else if($count_channels>3)
			$err = "Check no more than 3 channel/s.";

		
		$v_title=mysql_real_escape_string(stripslashes($_REQUEST['title']));
		$v_descr=mysql_real_escape_string(stripslashes($_REQUEST['description']));
		$v_keyword = mysql_real_escape_string(stripslashes($_REQUEST['keyword']));
		
		$active = $_REQUEST['active']  == '1' ? '1' : '0';
		$be_comment = $_REQUEST['be_comment'];
		$be_rated = $_REQUEST['be_rated'];
		$embed = $_REQUEST['embed'];
		
		$channels = implode("|",$_REQUEST['channel']);
		$chn = explode("|",$channels);

			if(!empty($_REQUEST['user'])) 
			{
				$video['uid'] =  $_REQUEST['user'];
				$uid = $video['uid'];
			}
			elseif(!empty($_REQUEST['def_user'])) 
			{
				$sql="select * from signup where username = '".$_REQUEST['def_user']."'";
				$def=$conn->execute($sql);
				if($def->recordcount()>0) 
				{
					$us=$def->getrows();
					$uid = $us[0]['UID'];
				}
			}
			else 
			{
					$err = "Username for Video owner not valid!";
			}
			

		if($uid=="")   $err = "Video owner not defined!";

		if($err=="") 
		{
			$command=$config['mplayer']. ' -vo null -ao null -frames 0 -identify "' .$config['temp_video_folder']. '/' .$_REQUEST['new_vid']. '"';
            @exec($config['mplayer']. ' -vo null -ao null -frames 0 -identify "' .$config['temp_video_folder']. '/' .$_REQUEST['new_vid']. '"', $p);
            while ( list($k,$v) = each($p) ) 
			{
                  if ( $length = strstr($v, 'ID_LENGTH=') )
                     break;
            }
    		$lx = explode('=', $length);
    		$duration = $lx['1']; 

			$movie=$config['temp_video_folder']. '/' .$_REQUEST['new_vid'];
			
			$key=substr(md5($_REQUEST['new_vid']),11,20);
			$sql = "insert into video set UID=".$uid.", title='".$v_title."', description='".$v_descr."', keyword='".$v_keyword."', addtime='".time()."', adddate='".date("Y-m-d")."', duration='".$duration."', vkey='".$key."', channel='0|".$channels."|0', type='".$_REQUEST['type']."', active='".$active."', be_comment='".$be_comment."', be_rated='".$be_rated."', embed='".$embed."'";
			

            $result = $conn->execute($sql);
			
			if($result==true) 
			{
				
				$vid=mysql_insert_id();
				$dest = $config['FLVDO_DIR']."/".$vid.".flv";
				$dest_copy = $config['FLVDO_DIR']."/".$vid."_x.flv";
				$from = $config['temp_video_folder']."/".$_REQUEST['new_vid'];
				$flvname = $vid.".flv";
				$sql="update video set vdoname='$flvname',flvdoname='$flvname',duration='$duration',vkey='$key', thumb='1' WHERE VID=$vid";
				$conn->execute($sql);
				@copy($from,$dest);
				$ext = get_file_extension($_REQUEST['new_vid']);
				if(strtolower($ext) == "flv") {
					 @exec( $config['metainject']." -Uv ".$dest." ".$dest_copy );
					 if(filesize($dest_copy)>100) {
						@unlink($dest);
						@rename($dest_copy,$dest);
					 }
				}

				$cmd  = $config['phppath']. ' ' .$config['BASE_DIR']. '/classes/gen_thumbs.php ' .$from. ' ' . $vid. ' '.$_POST['remove'];
				//exec($config['GLOBAL_ENV'].' '.$cmd.' >/dev/null &');

				$regen = regenVideoThumbs($vid);

				$msg="New video created succesfully. Create more videos!";

				if($_POST['remove']=='yes') {
					@unlink($from);
				}

			}
			else {
				$video['title'] = stripslashes($_REQUEST['title']);
				$video['description'] = stripslashes($_REQUEST['description']);
				$video['keyword'] = stripslashes($_REQUEST['keyword']);
				$video['active'] = $_REQUEST['active'];
				$video['type'] = $_REQUEST['type'];
				$video['be_comment'] = $_REQUEST['be_comment'];
				$video['be_rated'] = $_REQUEST['be_rated'];
				$video['embed'] = $_REQUEST['embed'];
				$video['channel'] = $_REQUEST['channel']	;
			}

        }
		else {

		   $video['title'] = stripslashes($_REQUEST['title']);
		   $video['description'] = stripslashes($_REQUEST['description']);
		   $video['keyword'] = stripslashes($_REQUEST['keyword']);
		   $video['active'] = $_REQUEST['active']  == '1' ? '1' : '0';
		   $video['type'] = $_REQUEST['type'];
		   $video['be_comment'] = $_REQUEST['be_comment'];
		   $video['be_rated'] = $_REQUEST['be_rated'];
		   $video['embed'] = $_REQUEST['embed'];
		   $video['channel'] = $_REQUEST['channel']	;
		}


}

		   $ch = insert_list_channel();
			
		   for($i=0; $ch[$i]['ch']!=""; $i++)
		   {
			 if(in_array($ch[$i]['id'],$chn ))
                $checked = "checked";
             else
                $checked = "";
			 $ch_checkbox .= "<input type=checkbox name=channel[] value=".$ch[$i]['id']." $checked>".$ch[$i]['ch']."</input><br>";
		   }

		   STemplate::assign('ch_checkbox',$ch_checkbox);


	$dir = $config['temp_video_folder'];
	if($config['default_user']<>"") {
	   Stemplate::assign('def_user',$config['default_user']);
	}

    $vids=array();

	if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) 
		{
            $filename = $file;
			if (strtolower(substr($filename, -4))=='.flv' || strtolower(substr($filename, -4))=='.mp4')
			$vids[] = $filename;
        }
        closedir($dh);
    }
	Stemplate::assign('vids',$vids);

    $folders=array();
	$dir = $config['BASE_DIR'];

	if ($dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false) 
		{
			if(is_dir($config['BASE_DIR']."/".$file) && $file <>"." && $file<>"..")
			$folders[] = $file;
        }
        closedir($dh);
    }
	Stemplate::assign('folders',$folders);


	if($config['use_user_list']) {
	   $sql="select UID,username from signup";
	   $rs=$conn->execute($sql);
	   $users=$rs->getrows();
	   Stemplate::assign('users',$users);
	   Stemplate::assign('count_users',count($users));
	}


    Stemplate::assign('video',$video);

function get_file_extension($file_name)
{
	return substr(strrchr($file_name,'.'),1);
}

?>
