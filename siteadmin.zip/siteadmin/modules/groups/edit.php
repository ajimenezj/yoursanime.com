<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$group  = array();
$GID    = ( isset($_GET['GID']) && is_numeric($_GET['GID']) ) ? trim($_GET['GID']) : NULL;
if ( !$GID ) {
    $err = 'Group id not set or not numeric!';
}

if ( $err == '' ) {
    if ( isset($_POST['edit_group']) ) {
        $gname      = $filterObj->process(trim($_POST['gname']));
        $gdescn     = $filterObj->process(trim($_POST['gdescn']));
        $keyword    = $filterObj->process(trim($_POST['keyword']));
        $gurl       = $filterObj->process(trim($_POST['gurl']));
        $channel    = $_POST['channel'];
        $type       = trim($_POST['type']);
        $gupload    = trim($_POST['gupload']);
        $gposting   = trim($_POST['gposting']);
        $gimage     = trim($_POST['gimage']);
        $featured   = trim($_POST['featured']);
        
        if ( $gname == '' )
            $err = 'Group Name field cannot be blank!';
        elseif ( $gdescn == '' )
            $err = 'Group Description field cannot be blank!';
        elseif ( $keyword == '' )
            $err = 'Tags field cannot be blank!';
        elseif ( $gurl == '' )
            $err = 'Group URL (key) field cannot be blank!';
        elseif ( count($channel)<1 or count($channel)>3 )
            $err = 'Please select at least 1 channel and no more then 3!';
        else {
            $sql = "SELECT GID FROM group_own WHERE gurl = '" .mysql_real_escape_string($gurl). "' AND GID != '" .mysql_real_escape_string($GID). "' LIMIT 1";
            $conn->execute($sql);
            if ( $conn->Affected_Rows() ) {
                $err = 'Group URL (key) is already used by another group!';
            }
        }
        
        if ( $err == '' ) {
            $sql = "UPDATE group_own SET gname = '" .mysql_real_escape_string($gname). "', gdescn = '" .mysql_real_escape_string($gdescn). "',
                                         keyword = '" .mysql_real_escape_string($keyword). "', gurl = '" .mysql_real_escape_string($gurl). "',
                                         channel = '0|" .mysql_real_escape_string(implode('|', $channel)). "|0', type = '" .mysql_real_escape_string($type). "',
                                         gupload = '" .mysql_real_escape_string($gupload). "', gposting = '" .mysql_real_escape_string($gposting). "',
                                         gimage = '" .mysql_real_escape_string($gimage). "', featured = '" .mysql_real_escape_string($featured). "'
                    WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
            $conn->execute($sql);
            if ( $conn->Affected_Rows() == 1 )
                $msg = 'Group successfuly updated!';
            else
                $err = 'Failed to update group (or no information changed)!';            
        }
    }

    $sql = "SELECT * FROM group_own WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
    $rs  = $conn->execute($sql);
    if ( $conn->Affected_Rows() ) {
        $group = $rs->getrows();
        $group['0']['channel']  = explode('|', $group['0']['channel']);
    } else
        $err = 'Group does not exist! Invalid group id!?';
}

STemplate::assign('group', $group);
?>
