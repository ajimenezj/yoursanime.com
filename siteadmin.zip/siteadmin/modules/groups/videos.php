<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require $config['BASE_DIR']. '/classes/pagination.class.php';

$remove         = NULL;
$videos         = array();
$GID            = ( isset($_GET['GID']) && is_numeric($_GET['GID']) && groupExists($_GET['GID']) ) ? trim($_GET['GID']) : NULL;
if ( $GID ) {
    if ( isset($_GET['a']) && $_GET['a'] == 'remove' ) {
        $VID = ( isset($_GET['VID']) && is_numeric($_GET['VID']) ) ? trim($_GET['VID']) : NULL;
        if ( $VID ) {
            $sql = "DELETE FROM group_vdo WHERE GID = '" .mysql_real_escape_string($GID). "' AND VID = '" .mysql_real_escape_string($VID). "'";
            $conn->execute($sql);
            $msg = 'Video successfuly removed from group!';
        } else {
            $err = 'Video id not set or not numeric!';
        }
        $remove = '&a=delete&VID=' .$VID;
    }
    
    $query          = constructQuery($GID);
    $sql            = $query['count'];
    $rs             = $conn->execute($sql);
    $total_videos   = $rs->fields['total_videos'];
    $pagination     = new Pagination($query['page_items']);
    $limit          = $pagination->getLimit($total_videos);
    $paging         = $pagination->getAdminPagination($remove);
    $sql            = $query['select']. " LIMIT " .$limit;
    $rs             = $conn->execute($sql);
    $videos         = $rs->getrows();
} else
    $err = 'Group does not exist! Invalid group id!?';

function constructQuery($gid)
{
    global $conn;

    $sql                = "SELECT gname FROM group_own WHERE GID = '" .mysql_real_escape_string($gid). "' LIMIT 1";
    $rs                 = $conn->execute($sql);
    $group_name         = $rs->fields['gname'];
    
    $group_videos       = array();
    $sql                = "SELECT VID FROM group_vdo WHERE GID = '" .mysql_real_escape_string($gid). "'";
    $rs                 = $conn->execute($sql);
    if ( $conn->Affected_Rows() ) {
        while ( !$rs->EOF ) {
            $group_videos[] = $rs->fields['VID'];
            $rs->movenext();
        }
    }
    $group_videos       = implode(',', $group_videos);

    $query              = array();
    $query_select       = "SELECT * FROM video WHERE VID in (" .$group_videos. ")";
    $query_count        = "SELECT count(*) AS total_videos FROM video WHERE VID in (" .$group_videos. ")";
    $query_add          = " AND";
    $query_option       = array();
    $channel            = ( isset($_GET['CID']) && is_numeric($_GET['CID']) && channelExists($_GET['CID']) ) ? trim($_GET['CID']) : NULL;
    $option             = array('username' => '', 'title' => '', 'description' => '', 'keyword' => '', 'channel' => $channel, 'featured' => '',
                                'sort' => 'VID', 'order' => 'DESC', 'display' => 10);                                    
    if ( isset($_POST['search_videos']) ) {
        $option['username']     = trim($_POST['username']);
        $option['title']        = trim($_POST['title']);
        $option['description']  = trim($_POST['description']);
        $option['keyword']      = trim($_POST['keyword']);
        $option['channel']      = trim($_POST['channel']);
        $option['featured']     = trim($_POST['featured']);
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
    }    
    
    if ( $option['username'] != '' ) {
        $UID            = getUserID($option['username']);
        if ( $UID ) {
            $query_option[] = $query_add. " UID = '" .mysql_real_escape_string($UID). "'";
            $query_add      = " AND";
        }
    }

    if ( $option['title'] != '' ) {
        $query_option[] = $query_add. " title LIKE '%" .mysql_real_escape_string($option['title']). "%'";
        $query_add      = " AND";
    }

    if ( $option['description'] != '' ) {
        $query_option[] = $query_add. " description LIKE '%" .mysql_real_escape_string($option['description']). "%'";
        $query_add      = " AND";
    }
        
    if ( $option['keyword'] != '' ) {
        $query_option[] = $query_add. " keyword LIKE '%" .mysql_real_escape_string($option['keyword']). "%'";
        $query_add      = " AND";
    }

    if ( $option['channel'] != '' ) {
        $query_option[] = $query_add. " channel LIKE '0|%" .mysql_real_escape_string($option['channel']). "%|0'";
        $query_add      = " AND";
    }

    if ( $option['featured'] != '' ) {
        $query_option[] = $query_add. " featured = '" .mysql_real_escape_string($option['featured']). "'";
        $query_add      = " AND";
    }

    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    
    STemplate::assign('gid', $gid);
    STemplate::assign('group_name', $group_name);
    STemplate::assign('option', $option);
    
    return $query;
}

function getUserID( $username )
{
    global $conn;
    
    $sql = "SELECT UID FROM signup WHERE username = '" .mysql_real_escape_string($username). "' LIMIT 1";
    $rs  = $conn->execute($sql);
    if ( mysql_affected_rows() == 1 )
        return $rs->fields['username'];
    
    return false;
}

STemplate::assign('videos', $videos);
STemplate::assign('total_videos', $total_videos);
STemplate::assign('paging', $paging);
?>
