<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$group  = array();
$GID    = ( isset($_GET['GID']) && is_numeric($_GET['GID']) ) ? trim($_GET['GID']) : NULL;
if ( !$GID ) {
    $err = 'Group id not set or not numeric!';
}

if ( $err == '' ) {
    if ( isset($_GET['a']) && ( $_GET['a'] == 'feature' or $_GET['a'] == 'unfeature' ) ) {
        $action     = trim($_GET['a']);
        $featured   = ( $action == 'feature' ) ? 'yes' : 'no';
        $sql        = "UPDATE group_own SET featured = '" .$featured. "' WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
        $conn->execute($sql);
        if ( $conn->Affected_Rows() ) {
            $msg = 'Successfuly ' .$action. 'd group!';
        }
    }

    $sql = "SELECT * FROM group_own WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
    $rs  = $conn->execute($sql);
    if ( $conn->Affected_Rows() ) {
        $group = $rs->getrows();
    } else
        $err = 'Group does not exist! Invalid group id!?';
}

STemplate::assign('group', $group);
?>
