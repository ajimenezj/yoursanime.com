<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require_once ('editor_files/editor_functions.php');
require_once ('editor_files/config.php');
require_once ('editor_files/editor_class.php');

$editor = new wysiwygPro();

if ( isset($_SESSION['email_errors']) ) {
    $err = $_SESSION['email_errors'];
    unset($_SESSION['email_errors']);
}

$group      = ( isset($_GET['GID']) && is_numeric($_GET['GID']) && groupExists($_GET['GID']) ) ? $_GET['GID'] : NULL;
$subject    = NULL;
$message    = NULL;
if ( isset($_POST['email_group']) ) {
    $group      = trim($_POST['group']);
    $subject    = trim($_POST['subject']);
    $message    = trim($_POST['htmlCode']);
    
    if ( $group == '' )
        $err = 'Please select a group!';
    elseif ( !groupExists($group) )
        $err = 'Group does not exist!';
    elseif ( $subject == '' )
        $err = 'Subject field cannot be empty!';
    elseif ( $message == '' )
        $err = 'Email message cannot be empty!';
    
    if ( $err == '' ) {
        $errors     = array();
        $members    = array();
        $sql        = "SELECT MID FROM group_mem WHERE GID = '" .mysql_real_escape_string($group). "'";
        echo var_dump($sql). '<br>';
        $rs         = $conn->execute($sql);
        if ( $conn->Affected_Rows() ) {
            $members[] = $rs->fields['MID'];
            $rs->movenext();
        } else {
            $err = 'Group has no members!';
        }
        
        if ( $err == '' ) {
            $sql    = "SELECT email FROM signup WHERE UID IN (" .implode(',', $members). ")";
            $rs     = $conn->execute($sql);
            if ( $conn->Affected_Rows() ) {
                while ( !$rs->EOF ) {
                    if ( !mailing($rs->fields['email'], $config['site_name'], $config['admin_email'], $subject, $message) )
                        $errors[] = $rs->fields['email'];
                    
                    $rs->movenext();
                }
            } else
                $err = 'Could not fetch user information!';
        }
        
        if ( $err == '' ) {
            if ( $errors )
                $_SESSION['email_errors'] = 'Could not send email to the following addresses: ' .implode(', ', $errors). '!';
            else
                $msg = 'Email was sent successfuly!';
        }
    }
}

$htmlCode   = ( isset($_POST['htmlCode']) ) ? trim($_POST['htmlCode']) : NULL;
$editor->set_code($htmlCode);

STemplate::assign('group', $group);
STemplate::assign('subject', $subject);
STemplate::assign('message', $message);
STemplate::assign('editor', $editor->return_editor('100%', 350));
?>
