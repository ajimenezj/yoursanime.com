<?php
defined('_VALID') or die('Restricted Access!');
require $config['BASE_DIR']. '/classes/pagination.class.php';

chk_admin_login();

$page = ( isset($_GET['page']) && is_numeric($_GET['page']) ) ? intval($_GET['page']) : 1;

if (isset($_POST['delete_selected_groups'])) {
    $index = 0;
    foreach ( $_POST as $key => $value ) {
        if ( $key != 'check_all_groups' && substr($key, 0, 18) == 'group_id_checkbox_') {
            if ( $value == 'on' ) {
                $GID    = intval(str_replace('group_id_checkbox_', '', $key));
                $topics = array();
                $sql    = "SELECT TID FROM group_tps WHERE GID = " .$GID. " LIMIT 1";
                $rs     = $conn->execute($sql);
                if ( $conn->Affected_Rows() ) {
                    while ( !$rs->EOF ) {
                        $topics[] = $rs->fields['TID'];
                        $rs->movenext();
                    }
                }
                if ( $topics ) {
                    $topics = explode(',', $topics);
                    $sql    = "DELETE FROM group_tps_post WHERE TID IN (" .$topics. ")";
                    $conn->execute($sql);
                }
                
                $tables = array('group_own', 'group_vdo', 'group_mem', 'group_tps');
                foreach ( $tables as $table ) {
                    $sql = "DELETE FROM " .$table. " WHERE GID = " .$GID;
                    $conn->execute($sql);
                }
                ++$index;
            }
        }
    }

    if ( $index === 0 ) {
        $err = 'Please select groups to be deleted!';
    } else {
        $msg = 'Successfully deleted ' .$index. ' (selected) groups!';
    }
}

if (isset($_POST['feature_selected_groups']) || isset($_POST['unfeature_selected_groups']) ) {
    $index      = 0;
    $act        = 'yes';
    $act_name   = 'featured';
    if ( isset($_POST['unfeature_selected_groups']) ) {
        $act        = 'no';
        $act_name   = 'unfeatured';
    }
    
    foreach ( $_POST as $key => $value ) {
        if ( $key != 'check_all_groups' && substr($key, 0, 18) == 'group_id_checkbox_') {
            if ( $value == 'on' ) {
                $GID = intval(str_replace('group_id_checkbox_', '', $key));
                $sql = "UPDATE group_own SET featured = '" .$act. "' WHERE GID = " .$GID. " LIMIT 1";
                $conn->execute($sql);
                ++$index;
            }
        }
    }
    
    if ( $index === 0 ) {
        $err = 'Please select groups to be ' .$act_name. '!';
    } else {
        $msg = 'Successfully ' .$act_name. ' ' .$index. ' (selected) groups!';
    }
}


$GID    = NULL;
$remove = NULL;
if ( isset($_GET['a']) && $_GET['a'] != '' ) {
    $action = trim($_GET['a']);
    $GID    = ( isset($_GET['GID']) && is_numeric($_GET['GID']) ) ? trim($_GET['GID']) : NULL;
    if ( $GID ) {
        switch ( $action ) {
            case 'feature':
            case 'unfeature':
                $feature    = ( $action == 'feature' ) ? 'yes' : 'no';
                $sql        = "UPDATE group_own SET featured = '" .$feature. "' WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
                $conn->execute($sql);
                if ( $conn->Affected_Rows() )
                    $msg = 'Group ' .$action. 'd successfuly!';
                else
                    $err = 'Failed to ' .$action. ' group. Invalid group id!?';
                $remove = '&a=' .$action. '&GID=' .$GID;
                break;
            case 'delete':
                $GID = ( groupExists($GID) ) ? $GID : NULL;
                if ( $GID ) {
                    $topics = array();
                    $sql    = "SELECT TID FROM group_tps WHERE GID = '" .mysql_real_escape_string($GID). "' LIMIT 1";
                    $rs     = $conn->execute($sql);
                    if ( $conn->Affected_Rows() ) {
                        while ( !$rs->EOF ) {
                            $topics[] = $rs->fields['TID'];
                            $rs->movenext();
                        }
                    }
                    if ( $topics ) {
                        $topics = explode(',', $topics);
                        $sql    = "DELETE FROM group_tps_post WHERE TID IN (" .$topics. ")";
                        $conn->execute($sql);
                    }
                
                    $tables = array('group_own', 'group_vdo', 'group_mem', 'group_tps');
                    foreach ( $tables as $table ) {
                        $sql = "DELETE FROM " .$table. " WHERE GID = '" .mysql_real_escape_string($GID). "'";
                        $conn->execute($sql);
                    }
                    $msg = 'Group successfuly deleted!';
                } else
                    $err = 'Failed to delete group. Group does not exist!?';
                $remove = '&a=delete&GID=' .$GID;
                break;
            default:
                $err = htmlspecialchars($action). ' is not a valid action!';
                break;
        }
    } else
        $err = 'Group id not set or not numeric!';
}

$query  = constructQuery($module_keep);
$sql            = $query['count'];
$rs             = $conn->execute($sql);
$total_groups   = $rs->fields['total_groups'];
$pagination     = new Pagination($query['page_items']);
$limit          = $pagination->getLimit($total_groups);
$paging         = $pagination->getAdminPagination($remove);
$sql            = $query['select']. " LIMIT " .$limit;
$rs             = $conn->execute($sql);
$groups         = $rs->getrows();

function constructQuery($module)
{
    $query_module = '';
    if ( $module == 'private' or $module == 'public' or $module == 'protected' )
            $query_module = " WHERE type = '" .$module. "'";

    $query              = array();
    $query_select       = "SELECT * FROM group_own" .$query_module;
    $query_count        = "SELECT count(*) AS total_groups FROM group_own" .$query_module;
    $query_add          = ( $query_module != '' ) ? " AND" : " WHERE";
    $query_option       = array();
    $option_orig        = array('name' => '', 'username' => '', 'description' => '', 'keyword' => '', 'channel' => '', 'featured' => '',
                                'sort' => 'GID', 'order' => 'DESC', 'display' => 10);
    $option             = ( isset($_SESSION['search_groups_option']) ) ? $_SESSION['search_groups_option'] : $option_orig;
    $option['channel']  = ( isset($_GET['CID']) && is_numeric($_GET['CID']) ) ? $_GET['CID'] : $option['channel'];
    
	if (isset($_POST['reset_search'])) {
		$option = $option_orig;
	}
	
    if ( isset($_POST['search_groups']) ) {
        $option['username']     = trim($_POST['username']);
        $option['title']        = trim($_POST['title']);
        $option['description']  = trim($_POST['description']);
        $option['keyword']      = trim($_POST['keyword']);
        $option['channel']      = trim($_POST['channel']);
        $option['featured']     = trim($_POST['featured']);
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
    }    
    
    if ( $option['username'] != '' ) {
        $UID            = getUserID($option['username']);
        if ( $UID ) {
            $query_option[] = $query_add. " OID = '" .mysql_real_escape_string($UID). "'";
            $query_add      = " AND";
        }
    }

    if ( $option['title'] != '' ) {
        $query_option[] = $query_add. " gname LIKE '%" .mysql_real_escape_string($option['title']). "%'";
        $query_add      = " AND";
    }

    if ( $option['description'] != '' ) {
        $query_option[] = $query_add. " gdescn LIKE '%" .mysql_real_escape_string($option['description']). "%'";
        $query_add      = " AND";
    }
        
    if ( $option['keyword'] != '' ) {
        $query_option[] = $query_add. " keyword LIKE '%" .mysql_real_escape_string($option['keyword']). "%'";
        $query_add      = " AND";
    }

    if ( $option['channel'] != '' ) {
        $query_option[] = $query_add. " channel LIKE '0|%" .mysql_real_escape_string($option['channel']). "%|0'";
        $query_add      = " AND";
    }

    if ( $option['featured'] != '' ) {
        $query_option[] = $query_add. " featured = '" .mysql_real_escape_string($option['featured']). "'";
        $query_add      = " AND";
    }

    $_SESSION['search_groups_option'] = $option;
    
    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    
    STemplate::assign('option', $option);
    
    return $query;
}

function getUserID( $username )
{
    global $conn;
    
    $sql = "SELECT UID FROM signup WHERE username = '" .mysql_real_escape_string($username). "' LIMIT 1";
    $rs  = $conn->execute($sql);
    if ( mysql_affected_rows() == 1 )
        return $rs->fields['username'];
    
    return false;
}

STemplate::assign('page', $page);
STemplate::assign('groups', $groups);
STemplate::assign('total_groups', $total_groups);
STemplate::assign('paging', $paging);
?>
