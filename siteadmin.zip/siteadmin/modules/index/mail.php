<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

if ( isset($_POST['submit_mail']) ) {
	$mailer			= trim($_POST['mailer']);
	$sendmail		= $filterObj->process(trim($_POST['sendmail']));
	$smtp			= $filterObj->process(trim($_POST['smtp']));
	$smtp_auth		= trim($_POST['smtp_auth']);
	$smtp_username	= $filterObj->process(trim($_POST['smtp_username']));
	$smtp_password	= $filterObj->process(trim($_POST['smtp_password']));
	$smtp_port		= $filterObj->process(trim($_POST['smtp_port']));
	$smtp_prefix	= $filterObj->process(trim($_POST['smtp_prefix']));

	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mailer). "' WHERE soption = 'mailer' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($sendmail). "' WHERE soption = 'sendmail' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp). "' WHERE soption = 'smtp' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp_auth). "' WHERE soption = 'smtp_auth' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp_username). "' WHERE soption = 'smtp_username' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp_password). "' WHERE soption = 'smtp_password' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp_port). "' WHERE soption = 'smtp_port' LIMIT 1";
	$conn->execute($sql);
	$sql = "UPDATE sconfig SET svalue = '" .mysql_real_escape_string($smtp_prefix). "' WHERE soption = 'smtp_prefix' LIMIT 1";
	$conn->execute($sql);
	update_config_and_smarty();
	$msg = 'Mail Settings Updated Successfuly!';
}

STemplate::display('siteadmin/mailsettings.tpl');
?>
