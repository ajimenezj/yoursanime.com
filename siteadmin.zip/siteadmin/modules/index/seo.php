<?php
defined('_VALID') or die('Restricted Access!');
chk_admin_login();
$current='video';

if ( isset($_POST['submit_seo']) ) {
	$explain			= trim($_POST['explain']);
	$page		    = trim($_POST['page']);
	$title		    = trim($_POST['title']);
	$desc			= trim($_POST['desc']);
	$keywords		= trim($_POST['keywords']);
	$id				= trim($_POST['id']);
	$sql = "UPDATE seo SET title = '" .mysql_real_escape_string($title). "',  description = '" .mysql_real_escape_string($desc). "',  keywords = '" .mysql_real_escape_string($keywords). "' WHERE id = '" .mysql_real_escape_string($id). "'";
	$conn->execute($sql);
	$current=$page;

    if ( mysql_affected_rows()==1) {
        $msg = $explain.' seo settings updated successfuly!';
    }
}

$sql = "SELECT * from seo";
$rs=$conn->execute($sql);
$seo = $rs->getrows();
STemplate::assign('seo', $seo);
STemplate::assign('current', $current);

?>
