<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

if ( isset($_POST['submit_mobile']) ) {
	$mobile_meta_title			= trim($_POST['mobile_meta_title']);
	$mobile_meta_desc			= trim($_POST['mobile_meta_desc']);
	$mobile_meta_keywords		= trim($_POST['mobile_meta_keywords']);
	
	$mobile_default_type		= trim($_POST['mobile_default_type']);
	$mobile_view_limit			= trim($_POST['mobile_view_limit']);
	$mobile_force_redirect		= trim($_POST['mobile_force_redirect']);
	$mobile_convert			    = trim($_POST['mobile_convert']);
	$mobile_appmode			    = trim($_POST['mobile_appmode']);
	
	
	$iphone_vbitrate			= trim($_POST['iphone_vbitrate']);
	$iphone_sbitrate			= trim($_POST['iphone_sbitrate']);
	$iphone_srate			    = trim($_POST['iphone_srate']);
	$iphone_resize_x			= trim($_POST['iphone_resize_x']);
	$iphone_resize_y			= trim($_POST['iphone_resize_y']);
	
	$iphone_encode_passes		= trim($_POST['iphone_encode_passes']);
	$iphone_ref_type			= trim($_POST['iphone_ref_type']);
	$iphone_blackbars			= trim($_POST['iphone_blackbars']);
	$iphone_resize_base			= trim($_POST['iphone_resize_base']);
    

	if ( $iphone_vbitrate == '' )
		$err = 'Videos Bit-rate cannot be left blank!';
	elseif( !is_numeric($iphone_vbitrate) )
		$err = 'Video Bit-rate must have a numeric value!';
		
	if ( $iphone_sbitrate == '' )
		$err = 'Audio Bit-rate cannot be left blank!';
	elseif( !is_numeric($iphone_sbitrate) )
		$err = 'Audio Bit-rate must have a numeric value!';

	if ( $iphone_srate == '' )
		$err = 'Audio Sampling Rate cannot be left blank!';
	elseif( !is_numeric($iphone_srate) )
		$err = 'Audio Sampling Rate must have a numeric value!';		
		

	if ( $iphone_resize_x ==  '' )
		$err = 'Video Width (in pixels) cannot be left blank!';
	elseif ( !is_numeric($iphone_resize_x) )
		$err = 'Video Width (in pixels) must have a numeric value!';
	if ( $iphone_resize_y ==  '' )
		$err = 'Video Height (in pixels) cannot be left blank!';
	elseif ( !is_numeric($iphone_resize_y) )
		$err = 'Video Height (in pixels) must have a numeric value!';		


    	
	if ( $err == '' ) {
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_meta_title). "' WHERE soption = 'mobile_meta_title' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_meta_desc). "' WHERE soption = 'mobile_meta_desc' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_meta_keywords). "' WHERE soption = 'mobile_meta_keywords' LIMIT 1;");
		
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_default_type). "' WHERE soption = 'mobile_default_type' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_view_limit). "' WHERE soption = 'mobile_view_limit' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_force_redirect). "' WHERE soption = 'mobile_force_redirect' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_convert). "' WHERE soption = 'mobile_convert' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($mobile_appmode). "' WHERE soption = 'mobile_appmode' LIMIT 1;");
		
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_vbitrate). "' WHERE soption = 'iphone_vbitrate' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_sbitrate). "' WHERE soption = 'iphone_sbitrate' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_srate). "' WHERE soption = 'iphone_srate' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_resize_x). "' WHERE soption = 'iphone_resize_x' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_resize_y). "' WHERE soption = 'iphone_resize_y' LIMIT 1;");
		
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_encode_passes). "' WHERE soption = 'iphone_encode_passes' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_ref_type). "' WHERE soption = 'iphone_ref_type' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_blackbars). "' WHERE soption = 'iphone_blackbars' LIMIT 1;");
		$conn->execute("UPDATE sconfig SET svalue = '" .mysql_real_escape_string($iphone_resize_base). "' WHERE soption = 'iphone_resize_base' LIMIT 1;");
	
		
		
		update_config_and_smarty();
		$msg = 'Mobile Conversion settings updated successfully!';
	}
}
	
?>
