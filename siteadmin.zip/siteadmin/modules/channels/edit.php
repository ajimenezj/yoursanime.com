<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$chimg  = $config['BASE_DIR']. '/chimg';
if ( !file_exists($chimg) or !is_dir($chimg) or !is_writable($chimg) ) {
    $err = 'Channel image directory \'' .$chimg. '\' is not writable!';
}

$channel    = array();
$CID        = ( isset($_GET['CID']) && is_numeric($_GET['CID']) ) ? trim($_GET['CID']) : NULL;
$CID        = ( $CID && channelExists($CID) ) ? $CID : NULL;
if ( !$CID )
    $err = 'Channel does not exist! Invalid channel id!?';

if ( isset($_POST['edit_channel']) && $err == '' ) {
    $name   = trim($_POST['name']);
    $desc   = trim($_POST['desc']);
    
    if ( $name == '' )
        $err = 'Channel name field cannot be blank!';
    elseif ( $desc == '' )
        $err = 'Channel description field cannot be blank!';
    
    if ( $err == '' ) {
        $sql = "UPDATE channel SET name = '" .mysql_real_escape_string($name). "', descrip = '" .mysql_real_escape_string($desc). "'
                WHERE CHID = '" .mysql_real_escape_string($CID). "' LIMIT 1";
        $conn->execute($sql);
        if ( $_FILES['picture']['tmp_name'] != '' )
            $err = upload_jpg($_FILES, 'picture', $CID. '.jpg', 120, $config['BASE_DIR']. '/chimg/');
    }
    
    if ( $err == '' )
        $msg = 'Channel updated successfuly!';
}

$sql        = "SELECT * FROM channel WHERE CHID = '" .mysql_real_escape_string($CID). "' LIMIT 1";
$rs         = $conn->execute($sql);
$channel    = $rs->getrows();

STemplate::assign('channel', $channel);
?>
