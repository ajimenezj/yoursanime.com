<?php
define('_VALID', true);
require('../../../include/config.php');
require 'json.php';

$skin=$_REQUEST['skin'];
$sql="select * from nuevo__pallete WHERE skin='".$skin."'";
$rs=$conn->execute($sql);
$palette = $rs->getrows();

$data = array('screencolor'=>'','hovercolor'=>'','viral_backhover'=>'','viral_texthover'=>'','playlisttextcolor'=>'', 'playlisthovercolor'=>'', 'playlisttextshadow'=>'', 'playlisthovershadow'=>'', 'advertcolor'=>'');

$data['screencolor']=$palette['0']['screencolor'];
$data['hovercolor']=$palette['0']['hovercolor'];
$data['viral_backhover']=$palette['0']['viral_backhover'];
$data['viral_texthover']=$palette['0']['viral_texthover'];

$data['playlisttextcolor']=$palette['0']['playlisttextcolor'];
$data['playlisthovercolor']=$palette['0']['playlisthovercolor'];
$data['playlisttextshadow']=$palette['0']['playlisttextshadow'];
$data['playlisthovershadow']=$palette['0']['playlisthovershadow'];
$data['advertcolor']=$palette['0']['advertcolor'];

echo json_encode($data);
die();
?>
