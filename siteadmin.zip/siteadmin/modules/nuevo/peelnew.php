<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$data = array();

if(isset($_POST['submit']))
{

	$data['active'] = $_POST['active'];
	$data['image'] = trim($_POST['image']);
    if (strlen (trim ($data['image'])) > 0 && !preg_match ('#^http[s]?:\/\/#i', $data['image']))
      $data['image'] = "http://".$data['image'];
	$data['url'] = trim($_POST['url']);
	$data['target'] = trim($_POST['target']);
	$data['title'] = trim($_POST['title']);
	$data['subtitle'] = trim($_POST['subtitle']);

	$sql = "INSERT INTO nuevo__peel SET active = '".mysql_real_escape_string($data['active'])."', image = '".mysql_real_escape_string($data['image'])."', url = '".mysql_real_escape_string($data['url'])."', target = '".mysql_real_escape_string($data['target'])."', title = '".mysql_real_escape_string($data['title'])."', subtitle = '".mysql_real_escape_string($data['subtitle'])."'";

	$conn->execute($sql);
	if (mysql_affected_rows() == 1) 
		header ("Location: adverts.php?m=peel");
    else
	   $err = "Peel effect could not be created";
}

STemplate::assign('ad', $data);
?>
