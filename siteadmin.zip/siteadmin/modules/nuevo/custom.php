<?php
defined('_VALID') or die('Restricted Access!');
chk_admin_login();

$hex_pattern = '~^[a-f0-9]{6,6}$~i';
$player_data = array();

$sql="SELECT * from nuevo__player where ID = 3 limit 1";
	$rs = $conn->Execute($sql);
    $player_data = $rs->getrows();
	$data = $player_data[0];
$sql="SELECT * from nuevo__player where ID = 4 limit 1";
	$rs = $conn->Execute($sql);
    $player_data = $rs->getrows();
	$data2 = $player_data[0];
$sql="SELECT * from nuevo__player where ID = 1 limit 1";
	$rs = $conn->Execute($sql);
	$player_data = $rs->getrows();
	$def_data = $player_data[0];

$data2['playlist_items']=10;

Stemplate::assign('div','single');

if(isset($_POST['submit']))
{

	$data['VID'] = intval($_POST['VID']);
	$data['skin'] = trim($_POST['skin']);
	if($data['skin']=='default') $data['skin']='';
	$data['stretching'] = trim($_POST['stretching']);
	$data['autostart'] = $_POST['autostart'];
	$data['player_width'] = intval($_POST['player_width']);
	$data['player_height'] = intval($_POST['player_height']);
	$data['playbar'] = $_POST['playbar'];
	$data['playbarhide'] = intval($_POST['playbarhide']);

	$data['viral_show'] = $_POST['viral_show'];
	$data['viral_offset'] = intval($_POST['viral_offset']);
	$data['viral_align'] = $_POST['viral_align'];
	$data['embed_show'] = $_POST['embed_show'];
	
	$data['guide'] = $_POST['guide'];
	$data['guide_show'] = $_POST['guide_show'];
	$data['email_show'] = $_POST['email_show'];
	$data['share_show'] = $_POST['share_show'];

	$data['show_logo'] = $_POST['show_logo'];
    
	$data['slomo_button'] = $_POST['slomo_button'];
	$data['replay_button'] = $_POST['replay_button'];
	$data['zoom_button'] = $_POST['zoom_button'];
	$data['settings_button'] = $_POST['settings_button'];
	$data['volume_button'] = $_POST['volume_button'];
	$data['size_button'] = $_POST['size_button'];
	$data['fullscreen_button'] = $_POST['fullscreen_button'];
	$data['menu_button'] = $_POST['menu_button'];
	
	$data['hovercolor'] = strtoupper(trim($_POST['hovercolor']));
	$data['viral_backhover'] = strtoupper(trim($_POST['viral_backhover']));
	$data['viral_texthover'] = strtoupper(trim($_POST['viral_texthover']));


   if($data['VID']<1) 
      $errors[] = "Set video ID";
   if(!is_numeric(trim($data['player_width'])))
	  $errors[] = "Invalid value for player width";
   if(!is_numeric(trim($data['player_height'])))
	  $errors[] = "Invalid value for player height";
   if(!is_numeric(trim($data['viral_offset'])))
	  $errors[] = "Invalid value for viral icons offset";


   if(!@preg_match($hex_pattern, $data['hovercolor']) || strlen($data['hovercolor'])!=6)
		$errors[] = "Invalid value for Buttons mouseover color";
   if(!@preg_match($hex_pattern, $data['viral_backhover']) || strlen($data['viral_backhover'])!=6)
		$errors[] = "Invalid value for advertisement text color";
   if(!@preg_match($hex_pattern, $data['viral_texthover']) || strlen($data['viral_texthover'])!=6)
		$errors[] = "Invalid value for advertisement text color";

   if( !$errors ) 
   {

		$sql = mysql_update_array('nuevo__player',$def_data,'ID','3');
		$result = $conn->execute($sql);

		$sql = update_player($data)." where ID = 3";

		$result = $conn->execute($sql);
			$messages[]="Player Code to Paste";
			$flashvars='config='.$config['BASE_URL'].'/nuevo/cst.php?id='.$data['VID'];
			$code='<br /><center><pre>';
			$code.="&lt;object width=\"".$data['player_width']."\" height=\"".$data['player_height']."\" data=\"".$config['BASE_URL']."/nuevo/player.swf\" type=\"application/x-shockwave-flash\"&gt;\n";
			$code.="&lt;param name=\"movie\" value=\"".$config['BASE_URL']."/nuevo/player.swf\"&gt;\n";
			$code.="&lt;param name=\"flashvars\" value=\"".$flashvars."\"&gt;\n";			
			$code.="&lt;param name=\"allowscriptaccess\" value=\"always\"&gt;\n";
			if($data2['fullscreen_button']='1') $code.="&lt;param name=\"allowfullscreen\" value=\"true\"&gt;\n";
			$code.="&lt;param name=\"bgcolor\" value=\"transparent\"&gt;\n";
			$code.="&lt;/object&gt;</pre></center>";			
			$messages[] = $code;
   }
   Stemplate::assign('div','single');
}

if(isset($_POST['submit_playlist']))
{

	$data2['playlist_type'] = $_POST['playlist_type'];
	$data2['playlist_items'] = intval($_POST['playlist_items']);
	$data2['playlist_user'] = $_POST['playlist_user'];

	$data2['skin'] = trim($_POST['skin']);
	if($data2['skin']=='default') $data2['skin']='';
	$data2['stretching'] = trim($_POST['stretching']);
	$data2['autostart'] = $_POST['autostart'];
	$data2['player_width'] = intval($_POST['player_width']);
	$data2['player_height'] = intval($_POST['player_height']);
	$data2['playbar'] = $_POST['playbar'];
	$data2['playbarhide'] = intval($_POST['playbarhide']);
	$data2['viral_show'] = $_POST['viral_show'];
	$data2['viral_offset'] = intval($_POST['viral_offset']);
	$data2['viral_align'] = $_POST['viral_align'];
	$data2['guide'] = $_POST['guide'];
	$data2['embed_show'] = $_POST['embed_show'];
	$data2['guide_show'] = $_POST['guide_show'];
	$data2['email_show'] = $_POST['email_show'];
	$data2['share_show'] = $_POST['share_show'];

	$data2['show_logo'] = $_POST['show_logo'];
    
	$data2['playlist_button'] = $_POST['playlist_button'];
	$data2['slomo_button'] = $_POST['slomo_button'];
	$data2['replay_button'] = $_POST['replay_button'];
	$data2['zoom_button'] = $_POST['zoom_button'];
	$data2['settings_button'] = $_POST['settings_button'];
	$data2['volume_button'] = $_POST['volume_button'];
	$data2['size_button'] = $_POST['size_button'];
	$data2['fullscreen_button'] = $_POST['fullscreen_button'];
	$data2['menu_button'] = $_POST['menu_button'];

	$data2['hovercolor'] = strtoupper(trim($_POST['hovercolor']));
	$data2['viral_backhover'] = strtoupper(trim($_POST['viral_backhover']));
	$data2['viral_texthover'] = strtoupper(trim($_POST['viral_texthover']));

	$data2['playlisttextcolor'] = strtoupper(trim($_POST['playlisttextcolor']));
	$data2['playlisthovercolor'] = strtoupper(trim($_POST['playlisthovercolor']));
	$data2['playlisttextshadow'] = strtoupper(trim($_POST['playlisttextshadow']));
	$data2['playlisthovershadow'] = strtoupper(trim($_POST['playlisthovershadow']));
	if($data2['playlisttextshadow']=='NONE') $data2['playlisttextshadow']='none';
	if($data2['playlisthovershadow']=='NONE') $data2['playlisthovershadow']='none';

	$data2['playlisttype'] = $_POST['playlisttype'];
	$data2['playlistsize'] = $_POST['playlistsize'];

   if($data2['playlist_items']<1)
      $errors[] = "Invalid value for playlist items";
   if($data2['playlist_type']=='user' && $data2['playlist_user']<2)
	   $errors[] = "You must provide user ID for this type of playlist";
   if(!is_numeric(trim($data2['player_width'])))
	  $errors[] = "Invalid value for player width";
   if(!is_numeric(trim($data2['player_height'])))
	  $errors[] = "Invalid value for player height";
   if(!is_numeric(trim($data2['viral_offset'])))
	  $errors[] = "Invalid value for viral icons offset";


   if(!@preg_match($hex_pattern, $data2['hovercolor']) || strlen($data2['hovercolor'])!=6)
		$errors[] = "Invalid value for Buttons mouseover color";
   if(!@preg_match($hex_pattern, $data2['viral_backhover']) || strlen($data2['viral_backhover'])!=6)
		$errors[] = "Invalid value for viral icons back hover color";
   if(!@preg_match($hex_pattern, $data2['viral_texthover']) || strlen($data2['viral_texthover'])!=6)
		$errors[] = "Invalid value for advertisement text color";


   if( !$errors ) 
   {
		$sql = mysql_update_array('nuevo__player',$def_data,'ID','4');
		$result = $conn->execute($sql);

		$sql = update_player($data2)." where ID = 4";
		$result = $conn->execute($sql);
   
		
			$messages[]="Player Code to Paste";
			$sql="UPDATE nuevo__player set 
				playlist_button='".mysql_real_escape_string($data2['playlist_button'])."',
				playlistsize='".mysql_real_escape_string($data2['playlistsize'])."',
				playlisttype='".mysql_real_escape_string($data2['playlisttype'])."',
				playlisttextcolor='".mysql_real_escape_string($data2['playlisttextcolor'])."',
				playlisthovercolor='".mysql_real_escape_string($data2['playlisthovercolor'])."',
				playlisttextshadow='".mysql_real_escape_string($data2['playlisttextshadow'])."',
				playlisthovershadow='".mysql_real_escape_string($data2['playlisthovershadow'])."' where ID = 4";
				$result = $conn->execute($sql);
				//echo $sql;
			$flashvars='config='.$config['BASE_URL'].'/nuevo/cpl.php?';
			$flashvars.='type='.$data2['playlist_type'];
			if($data2['playlist_type']=='user') $flashvars.='_'.$data2['playlist_user'];
			if($data2['playlist_items']<>'10') $flashvars.='_'.$data2['playlist_items'];

			$code="<br /><center><pre>";
			$code.="&lt;object width=\"".$data2['player_width']."\" height=\"".$data2['player_height']."\" data=\"".$config['BASE_URL']."/nuevo/player.swf\" type=\"application/x-shockwave-flash\"&gt;\n";
			$code.="&lt;param name=\"movie\" value=\"".$config['BASE_URL']."/nuevo/player.swf\"&gt;\n";
			$code.="&lt;param name=\"flashvars\" value=\"".$flashvars."\"&gt;\n";			
			$code.="&lt;param name=\"allowscriptaccess\" value=\"always\"&gt;\n";
			if($data2['fullscreen_button']='1') $code.="&lt;param name=\"allowfullscreen\" value=\"true\"&gt;\n";
			$code.="&lt;param name=\"bgcolor\" value=\"transparent\"&gt;\n";
			$code.="&lt;/object&gt;</pre></center>";
			$messages[] = $code;

   }
   Stemplate::assign('div','playlist');
}


function update_player($rdata)
{
	$sql="UPDATE nuevo__player set 
		   skin='".mysql_real_escape_string($rdata['skin'])."',
		   stretching='".mysql_real_escape_string($rdata['stretching'])."',	
		   player_width='".mysql_real_escape_string($rdata['player_width'])."',
		   player_height='".mysql_real_escape_string($rdata['player_height'])."',
		   autostart='".mysql_real_escape_string($rdata['autostart'])."',
		   playbar='".mysql_real_escape_string($rdata['playbar'])."',
           playbarhide='".mysql_real_escape_string($rdata['playbarhide'])."',
		   viral_show='".mysql_real_escape_string($rdata['viral_show'])."',
		   viral_offset='".mysql_real_escape_string($rdata['viral_offset'])."',
		   viral_align='".mysql_real_escape_string($rdata['viral_align'])."',
		   guide='".mysql_real_escape_string($rdata['guide'])."',
		   guide_show='".mysql_real_escape_string($rdata['guide_show'])."',
		   embed_show='".mysql_real_escape_string($rdata['embed_show'])."',
		   email_show='".mysql_real_escape_string($rdata['email_show'])."',
		   share_show='".mysql_real_escape_string($rdata['share_show'])."',
		   show_logo='".mysql_real_escape_string($rdata['show_logo'])."',
		   replay_button='".mysql_real_escape_string($rdata['replay_button'])."',
		   slomo_button='".mysql_real_escape_string($rdata['slomo_button'])."',
		   zoom_button='".mysql_real_escape_string($rdata['zoom_button'])."',
		   settings_button='".mysql_real_escape_string($rdata['settings_button'])."',
		   volume_button='".mysql_real_escape_string($rdata['volume_button'])."',
		   size_button='".mysql_real_escape_string($rdata['size_button'])."',
		   fullscreen_button='".mysql_real_escape_string($rdata['fullscreen_button'])."',
		   menu_button='".mysql_real_escape_string($rdata['menu_button'])."',
		   playlist_button='0', resize_button='0',
		   hovercolor='".mysql_real_escape_string($rdata['hovercolor'])."',
           viral_backhover='".mysql_real_escape_string($rdata['viral_backhover'])."',
		   viral_texthover='".mysql_real_escape_string($rdata['viral_texthover'])."'";
		return $sql;
}


$dir = $config['BASE_DIR']."/nuevo/skins";
$skins=array();
if ($dh = opendir($dir)) {
    while (($file = readdir($dh)) !== false) 
	{
		$filename=strtolower($file);
		if (substr($filename, -4)=='.swf')
		$skins[] = str_replace('.swf','',$filename);
    }
    closedir($dh);
}

$skin = $data['skin']; if ($skin=='') $skin='black';
$sql="select * from nuevo__pallete WHERE skin = '".mysql_real_escape_string($skin)."'";
$rs=$conn->execute($sql);
$palette = $rs->getrows();
$palette = $palette['0'];

$skin = $data2['skin']; if ($skin=='') $skin='black';
$sql="select * from nuevo__pallete WHERE skin = '".mysql_real_escape_string($skin)."'";
$rs=$conn->execute($sql);
$palette2 = $rs->getrows();
$palette2 = $palette2['0'];

Stemplate::assign('palette',$palette);
Stemplate::assign('palette2',$palette2);
Stemplate::assign('skins',$skins);
Stemplate::assign('player',$data);
Stemplate::assign('player2',$data2);
Stemplate::assign('errors',$errors);
Stemplate::assign('messages',$messages);

function mysql_update_array($table, $data, $id_field, $id_value) {
	foreach ($data as $field=>$value) {
		if(!is_numeric($field) && $field!='ID') $fields[] = sprintf("`%s` = '%s'", $field, mysql_real_escape_string($value));
	}
	$field_list = join(',', $fields);
	
	$query = sprintf("UPDATE `%s` SET %s WHERE `%s` = %s", $table, $field_list, $id_field, intval($id_value));
	
	return $query;
}
?>
