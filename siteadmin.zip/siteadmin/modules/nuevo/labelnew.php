<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();
$data = array('text'=>'','start'=>'5','runtime'=>'10','scrollspeed'=>'5','active'=>'1','opacity'=>'50','target'=>'_blank','url'=>'');

$hex_pattern = '~^[a-f0-9]{6,6}$~i';

if ( isset($_POST['submit']) ) 
{
		$data['text']          = trim($_POST['text']);
		$data['start']			= intval(trim($_POST['start']));
		$data['runtime']		= intval(trim($_POST['runtime']));
		$data['scrollspeed']	= intval(trim($_POST['scrollspeed']));
		$data['opacity']		= intval($_POST['opacity']);
		$data['position']		= trim($_POST['position']);
        $data['active'] =		$_POST['active'];
		$data['url']		    = trim($_POST['url']);
		$data['target']		= trim($_POST['target']);

		if ( strlen($data['text'])<1 )
			$errors[] = "Message text cannot be blank";
		if ($data['start']<1)
			$errors[] = "Start time cannot be 0 or blank";
		if ($data['runtime']<3)
			$errors[] = "Runtime cannot be less than 3 secoonds";
		if ($data['scrollspeed']<2 || $data['scrollspeed']>10)
			$errors[] = "Scroll spedd must be value between 1-10";
		if ($data['opacity']<25 || $data['opacity']>100)
			$errors[] = "Opacity value must be value between 25-100";

        if ( !$errors ) {

			$sql = "INSERT INTO nuevo__ticker SET text = '".mysql_real_escape_string($data['text'])."', start ='".mysql_real_escape_string($data['start'])."', runtime ='".mysql_real_escape_string($data['runtime'])."', position ='".mysql_real_escape_string($data['position'])."', scrollspeed ='".mysql_real_escape_string($data['scrollspeed'])."', opacity ='".mysql_real_escape_string($data['opacity'])."', url ='".mysql_real_escape_string($data['url'])."', target ='".mysql_real_escape_string($data['target'])."', addtime ='".mysql_real_escape_string(time())."', active ='".mysql_real_escape_string($data['active'])."'";
			
			$conn->execute($sql);
			if (mysql_affected_rows() == 1) 
			  header ("Location: nuevo.php?m=labels");
            else
			  $errors[] = "Player message could not be created";
        }

}

STemplate::assign('ad', $data);
?>
