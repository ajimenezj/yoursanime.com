<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require $config['BASE_DIR']. '/classes/pagination.class.php';

$remove = NULL;
if(isset($_POST['new_ad'])) {
  header("Location: player.php?m=labelnew");
}

if ( isset($_GET['a']) && $_GET['a'] != '' ) {
    $action = trim($_GET['a']);
    $ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
    if ( $ID ) {
        switch ( $action ) {
            case 'delete':
                $sql="delete from nuevo__ticker where ID = '$ID' limit 1";
			    $conn->execute($sql);
                $messages[] = 'Label  message deleted successfuly!';
                break;
            case 'suspend':
                $sql = "UPDATE nuevo__ticker SET active = '0' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Label  message suspended successfuly!';
                break;
            case 'activate':
                $sql = "UPDATE nuevo__ticker SET active = '1' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Player message ad activated successfuly!';
                break;
        }
    } else {
        $errors[] = 'Invalid Label  message id. Message does not exist!?';
    }
}

$query          = constructQuery();
$sql            = $query['count'];
$rs             = $conn->execute($sql);
$total_ads	    = $rs->fields['total_ads'];
$pagination     = new Pagination($query['page_items']);
$limit          = $pagination->getLimit($total_ads);
$paging         = $pagination->getAdminPagination($remove);
$sql            = $query['select']. " LIMIT " .$limit;
$rs             = $conn->execute($sql);
$ads			= $rs->getrows();

function constructQuery()
{
    global $smarty;
	$query_module = "";

    $query              = array();
    $query_select       = "SELECT * FROM nuevo__ticker".$query_module;
    $query_count        = "SELECT count(*) AS total_ads FROM nuevo__ticker" .$query_module;
    $query_add          = ( $query_module != '' ) ? " AND" : " WHERE";
    $query_option       = array();
    $option             = array('sort' => 'ID', 'order' => 'DESC', 'display' => 10);
    if ( isset($_POST['search_ads']) ) {
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
    }
	else {
		$option['sort'] = 'ID';
		$option['order'] = "DESC";
		$option['display'] = 10;
	}

    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    
    STemplate::assign('option', $option);
    
    return $query;
}


STemplate::assign('labels', $ads);
STemplate::assign('total', $total_ads);
STemplate::assign('paging', $paging);
?>
