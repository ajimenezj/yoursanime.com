<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$months = array (1 => 'January',2 => 'February',3 => 'March', 4 => 'April',5 => 'May', 6 => 'June',7 => 'July', 8 => 'August',9 => 'September',10 => 'October',11 => 'November', 12 => 'December');

$days=array();
for($i=1;$i<=31;$i++) { $days[$i] = $i; }

$year_beg=2010;
$years=array();
for($i=1;$i<=20;$i++) {
  $years[$i] = $year_beg; $year_beg++;
}

$data=array('ID'=>'','ad_name'=>'','ad_type'=>'pause','ad_resume'=>1,'ad_method'=>'click','ad_timer'=>8,'back_color'=>'FFFFFF','progress_color'=>'990000','ad_width'=>300,'day'=>1, 'month'=>1, 'year'=>2010, 'ad_height'=>250,'bar_offset'=>40, 'midroll_start'=>5, 'ad_position'=>'center','ad_content'=>'','active'=>0);

if(isset($_REQUEST['submit']))
{
    $data['ad_name'] = trim($_POST['ad_name']);
	$data['ad_type'] = trim($_POST['ad_type']);
	$data['ad_resume'] = trim($_POST['ad_resume']); 
	$data['ad_method'] = $_POST['ad_method'];
	$data['ad_timer'] = intval($_POST['ad_timer']);
	$data['midroll_start'] = intval($_POST['midroll_start']);
	$data['back_color'] = trim($_POST['back_color']);
	$data['ad_width'] = intval($_POST['ad_width']);
	$data['ad_height'] = intval($_POST['ad_height']);
	$data['bar_offset'] = intval($_POST['bar_offset']);
	$data['ad_position'] = trim($_POST['ad_position']);
	$data['ad_playicon'] = trim($_POST['ad_playicon']);
	$data['ad_content'] = trim($_POST['ad_content']);
	$data['progress_color'] = trim($_POST['progress_color']);
	$data['channel'] = $_POST['channel'];
    $data['month']	= intval($_POST['month']);
    $data['year']	= intval($_POST['year']);
    $data['day']	= intval($_POST['day']);

	$data['active'] = $_POST['active'];

	if($data['ad_name']=='') $errors[] = "Give your ad some name.";
	if($data['ad_type'] == 'before' || $data['ad_type'] == 'before_pause') {
		if($data['ad_method'] == 'time') {
			if($data['ad_timer']<3 || $data['ad_timer']>10) $errors[]='Invalid value for ad timeout. Must be within 3-10 range.';
		}
	}
	if($data['ad_width']==0) $errors[]="Invalid value for ad width";
	if($data['ad_height']==0) $errors[]="Invalid value for ad height";
	if($data['ad_content']=='') $errors[]="No ad content defined";

    if($data['month']<1 || $data['day']<1 || $data['year']<1) {
		$errors[] = 'Expire date not valid';
	} else {
		$data['expire'] = mktime(0,0,0,$data['month'],$data['day'],$data['year']);
		if($data['expire']<time()) $errors[]="Invalid expiry date. Set some date in the future.";
	}


    if(! $errors) 
    {
		
		$sql = "INSERT INTO nuevo__htmlad SET ad_type = '".mysql_real_escape_string($data['ad_type'])."', ad_name = '".mysql_real_escape_string($data['ad_name'])."', ad_method = '".mysql_real_escape_string($data['ad_method'])."', ad_timer = '".mysql_real_escape_string($data['ad_timer'])."', midroll_start = '".mysql_real_escape_string($data['midroll_start'])."', back_color = '".mysql_real_escape_string($data['back_color'])."', progress_color = '".mysql_real_escape_string($data['progress_color'])."', ad_width = '".mysql_real_escape_string($data['ad_width'])."', ad_height  = '".mysql_real_escape_string($data['ad_height'] )."', bar_offset  = '".mysql_real_escape_string($data['bar_offset'] )."', ad_position = '".mysql_real_escape_string($data['ad_position'])."', ad_closepic = '".mysql_real_escape_string($data['ad_closepic'])."', ad_closeoffset = '".mysql_real_escape_string($data['ad_closeoffset'])."', channel = '".mysql_real_escape_string($data['channel'])."', expire = '".mysql_real_escape_string($data['expire'])."', ad_content = '".mysql_real_escape_string($data['ad_content'])."', addtime = '".mysql_real_escape_string(time())."', active = '".mysql_real_escape_string($data['active'])."'";
		
		echo $sql;
		$conn->execute($sql);
        if ( mysql_affected_rows() ==1 )
             header ("Location: nuevo.php?m=anyad");
        else
             $errors[] = 'Failed to insert Any HTML AD.';
   }
}


$sql="SELECT * from channel ORDER BY CHID ASC";
$rs=$conn->execute($sql);
$channels=$rs->getrows();

STemplate::assign('channels', $channels);
STemplate::assign('months', $months);
STemplate::assign('years', $years);
STemplate::assign('days', $days);
STemplate::assign('data',$data);
?>
