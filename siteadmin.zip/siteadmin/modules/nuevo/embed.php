<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$hex_pattern = '~^[a-f0-9]{6,6}$~i';
$player_data = array();

$sql="SELECT * from nuevo__player where ID = '2' limit 1";
	$rs = $conn->execute($sql);
    $player_data = $rs->getrows();
	$data = $player_data[0];


if(isset($_POST['submit']))
{
	$data['skin'] = trim($_POST['skin']);
	if($data['skin']=='default') $data['skin']='';
	$data['stretching'] = trim($_POST['stretching']);
	$data['player_width'] = intval($_POST['player_width']);
	$data['player_height'] = intval($_POST['player_height']);
	$data['autostart'] = $_POST['autostart'] ;
	
	$data['playbar'] = trim($_POST['playbar']);
	$data['playbarhide'] = intval($_POST['playbarhide']);
	//$data['playbaralpha'] = intval($_POST['playbaralpha']);
	//$data['playbaroffsety'] = intval($_POST['playbaroffsety']);
	//$data['playbaroffsetx'] = intval($_POST['playbaroffsetx']);
	//$data['fullheight'] = $_POST['fullheight'];
	
	$data['show_logo'] = $_POST['show_logo'];

	$data['viral_show'] = $_POST['viral_show'];
	$data['viral_offset'] = intval($_POST['viral_offset']);
	$data['viral_align'] = $_POST['viral_align'];

	$data['guide'] = $_POST['guide'];
	$data['guide_show'] = $_POST['guide_show'];
	$data['embed_show'] = $_POST['embed_show'];
	$data['email_show'] = $_POST['email_show'];
	$data['share_show'] = $_POST['share_show'];
	
	$data['replay_button'] = $_POST['replay_button'];
	$data['slomo_button'] = $_POST['slomo_button'];
	$data['zoom_button'] = $_POST['zoom_button'];
	$data['settings_button'] = $_POST['settings_button'];
	$data['volume_button'] = $_POST['volume_button'];
	$data['size_button'] = $_POST['size_button'];
	$data['fullscreen_button'] = $_POST['fullscreen_button'];
	$data['menu_button'] = $_POST['menu_button'] ;
	$data['onclick'] = $_POST['onclick'] ;

	$data['plugin_midroll'] = trim($_POST['plugin_midroll']);
	$data['plugin_overlay'] = trim($_POST['plugin_overlay']);
	$data['plugin_ticker'] = trim($_POST['plugin_ticker']);

	$data['hovercolor'] = strtoupper(trim($_POST['hovercolor']));
	$data['viral_backhover'] = strtoupper(trim($_POST['viral_backhover']));
	$data['viral_texthover'] = strtoupper(trim($_POST['viral_texthover']));

   if(!is_numeric(trim($data['player_width'])))
	  $errors[] = "Invalid value for player width";
   if(!is_numeric(trim($data['player_height'])))
	  $errors[] = "Invalid value for player height";

   if(!is_numeric(trim($data['viral_offset'])))
	  $errors[] = "Invalid viral icons offset value";
   if(!@preg_match($hex_pattern, $data['hovercolor']) || strlen($data['hovercolor'])!=6)
		$errors[] = "Invalid value for Buttons mouseover color";
   if(!@preg_match($hex_pattern, $data['viral_backhover']) || strlen($data['viral_backhover'])!=6)
		$errors[] = "Invalid value for Viral icons back color";
   if(!@preg_match($hex_pattern, $data['viral_texthover']) || strlen($data['viral_texthover'])!=6)
		$errors[] = "Invalid value for Viral icons text color";

   if( !$errors ) 
   {
		$sql = update_player($data)." where ID = 2";
		$result = $conn->execute($sql);
   
		if (mysql_affected_rows() == 1) {
			$messages[]="Player settings updated succesfully";
		}
		else
			$errors[]="Settings were not updated";
   }
}

function update_player($data)
{

	$sql="UPDATE nuevo__player set 
		   skin='".mysql_real_escape_string($data['skin'])."',
		   stretching='".mysql_real_escape_string($data['stretching'])."',
		   player_width='".mysql_real_escape_string($data['player_width'])."',
		   player_height='".mysql_real_escape_string($data['player_height'])."',
		   autostart='".mysql_real_escape_string($data['autostart'])."',
		   playbar='".mysql_real_escape_string($data['playbar'])."',
		   playbarhide='".mysql_real_escape_string($data['playbarhide'])."',
		   show_logo='".mysql_real_escape_string($data['show_logo'])."',
		   viral_show='".mysql_real_escape_string($data['viral_show'])."',
		   viral_offset='".mysql_real_escape_string($data['viral_offset'])."',
		   viral_align='".mysql_real_escape_string($data['viral_align'])."',
		   embed_show='".mysql_real_escape_string($data['embed_show'])."',
		   guide='".mysql_real_escape_string($data['guide'])."',
		   guide_show='".mysql_real_escape_string($data['guide_show'])."',
		   email_show='".mysql_real_escape_string($data['email_show'])."',
		   share_show='".mysql_real_escape_string($data['share_show'])."',
		   replay_button='".mysql_real_escape_string($data['replay_button'])."',
		   slomo_button='".mysql_real_escape_string($data['slomo_button'])."',
		   zoom_button='".mysql_real_escape_string($data['zoom_button'])."',
		   settings_button='".mysql_real_escape_string($data['settings_button'])."',
		   volume_button='".mysql_real_escape_string($data['volume_button'])."',
		   size_button='".mysql_real_escape_string($data['size_button'])."',
		   fullscreen_button='".mysql_real_escape_string($data['fullscreen_button'])."',
		   menu_button='".mysql_real_escape_string($data['menu_button'])."',
		   onclick='".mysql_real_escape_string($data['onclick'])."',
		   plugin_midroll='".mysql_real_escape_string($data['plugin_midroll'])."',
		   plugin_overlay='".mysql_real_escape_string($data['plugin_overlay'])."',
		   plugin_ticker='".mysql_real_escape_string($data['plugin_ticker'])."',
		   hovercolor='".mysql_real_escape_string($data['hovercolor'])."',
		   viral_backhover='".mysql_real_escape_string($data['viral_backhover'])."',
		   viral_texthover='".mysql_real_escape_string($data['viral_texthover'])."'";

		return $sql;
}

Stemplate::assign('player',$data);

$dir = $config['BASE_DIR']."/nuevo/skins";
$skins=array();
if ($dh = opendir($dir)) {
    while (($file = readdir($dh)) !== false) 
	{
		$filename=strtolower($file);
		if (substr($filename, -4)=='.swf')
		$skins[] = str_replace('.swf','',$filename);
    }
    closedir($dh);
}

$skin = $data['skin']; if ($skin=='') $skin='black';
$sql="select * from nuevo__pallete WHERE skin = '".mysql_real_escape_string($skin)."'";
$rs=$conn->execute($sql);
$palette = $rs->getrows();
$palette = $palette['0'];

Stemplate::assign('palette',$palette);
Stemplate::assign('skins',$skins);

STemplate::assign('errors',$errors);
STemplate::assign('messages',$messages);
?>
