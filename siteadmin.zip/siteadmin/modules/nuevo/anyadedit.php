<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
settype($ID, 'integer');

$months = array (1 => 'January',2 => 'February',3 => 'March', 4 => 'April',5 => 'May', 6 => 'June',7 => 'July', 8 => 'August',9 => 'September',10 => 'October',11 => 'November', 12 => 'December');

$days=array();
for($i=1;$i<=31;$i++) { $days[$i] = $i; }

$year_beg=2010;
$years=array();
for($i=1;$i<=20;$i++) {
  $years[$i] = $year_beg; $year_beg++;
}


if ( !$ID ) 
    $errors[] = 'Invalid ad ID. Ad does not exist!';

else {
 
  $sql="select * from nuevo__htmlad where ID = '".mysql_real_escape_string($ID)."' LIMIT 1";
  $rs = $conn->execute($sql);
  $ad = $rs->getrows();
  $data = $ad[0];

  if(strlen($data['expire'])>0) {
	$data['day'] = intval(date("j",$data['expire']));
	$data['month'] = intval(date("n",$data['expire']));
	$data['year'] = intval(date("Y",$data['expire']));  
  }

if(isset($_REQUEST['submit']))
{
    $data['ad_name'] = trim($_POST['ad_name']);
	$data['ad_type'] = trim($_POST['ad_type']);
	$data['ad_method'] = $_POST['ad_method'];
	$data['ad_timer'] = intval($_POST['ad_timer']);
	$data['back_color'] = trim($_POST['back_color']);
	$data['ad_width'] = intval($_POST['ad_width']);
	$data['progress_color'] = trim($_POST['progress_color']);
	$data['ad_height'] = intval($_POST['ad_height']);
	$data['ad_position'] = trim($_POST['ad_position']);
	$data['ad_closepic'] = trim($_POST['ad_closepic']);
	$data['ad_closeoffset'] = intval($_POST['ad_closeoffset']);
	$data['ad_content'] = trim($_POST['ad_content']);
	$data['active'] = $_POST['active'];
	$data['channel'] = $_POST['channel'];
    $data['month']	= intval($_POST['month']);
    $data['year']	= intval($_POST['year']);
    $data['day']	= intval($_POST['day']);

	if($data['ad_name']=='') $errors[] = "Give your ad some name.";
	if($data['ad_type'] == 'before' || $data['ad_type'] == 'before_pause') {
		if($data['ad_method'] == 'time') {
			if($data['ad_timer']<3 || $data['ad_timer']>10) $errors[]='Invalid value for ad timeout. Must be within 3-10 range.';
		}
	}
	if($data['ad_width']==0) $errors[]="Invalid value for ad width";
	if($data['ad_height']==0) $errors[]="Invalid value for ad height";
	if($data['ad_content']=='') $errors[]="No ad content defined";
    if($data['month']<1 || $data['day']<1 || $data['year']<1) {
		$errors[] = 'Expire date not valid';
	} else {
		$data['expire'] = mktime(0,0,0,$data['month'],$data['day'],$data['year']);
		if($data['expire']<time()) $errors[]="Invalid expiry date. Set some date in the future.";
	}
	
	
		

    if(! $errors) 
    {
		$sql = "UPDATE nuevo__htmlad SET ad_type = '".mysql_real_escape_string($data['ad_type'])."', ad_name = '".mysql_real_escape_string($data['ad_name'])."', ad_method = '".mysql_real_escape_string($data['ad_method'])."', ad_timer = '".mysql_real_escape_string($data['ad_timer'])."', back_color = '".mysql_real_escape_string($data['back_color'])."', progress_color = '".mysql_real_escape_string($data['progress_color'])."', ad_width = '".mysql_real_escape_string($data['ad_width'])."', ad_height  = '".mysql_real_escape_string($data['ad_height'] )."', ad_position = '".mysql_real_escape_string($data['ad_position'])."', ad_closepic = '".mysql_real_escape_string($data['ad_closepic'])."', channel = '".mysql_real_escape_string($data['channel'])."', expire = '".mysql_real_escape_string($data['expire'])."', ad_closeoffset = '".mysql_real_escape_string($data['ad_closeoffset'])."', ad_content = '".mysql_real_escape_string($data['ad_content'])."', active = '".mysql_real_escape_string($data['active'])."' WHERE ID = '".mysql_real_escape_string($ID)."' LIMIT 1";
		
		$conn->execute($sql);
        if ( mysql_affected_rows() ==1 )
             $messages[] = 'Any HTML AD updated sucessfully.';
        else
             $errors[] = 'Failed to update Any HTML AD or nothing changed!';
   }
}

}
$sql="SELECT * from channel ORDER BY CHID ASC";
$rs=$conn->execute($sql);
$channels=$rs->getrows();

STemplate::assign('messages',$messages);
STemplate::assign('errors',$errors);

STemplate::assign('channels', $channels);
STemplate::assign('months', $months);
STemplate::assign('years', $years);
STemplate::assign('days', $days);
STemplate::assign('data',$data);
?>
