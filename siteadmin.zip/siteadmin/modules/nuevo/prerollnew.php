<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$data = array();
$months = array (
   1 => 'January',
   2 => 'February',
   3 => 'March',
   4 => 'April',
   5 => 'May',
   6 => 'June',
   7 => 'July',
   8 => 'August',
   9 => 'September',
   10 => 'October',
   11 => 'November',
   12 => 'December'
);

$days=array();
for($i=1;$i<=31;$i++) 
  $days[$i] = $i;

$year_beg=2001;
$years=array();
for($i=1;$i<=50;$i++) {
  $years[$i] = $year_beg;
  $year_beg++;
}

$extensions = array('.png', '.jpg', '.jpeg', '.gif', '.swf', '.flv', '.mp4');

if ( isset($_POST['submit']) ) 
{
       
		$data['type']			= trim($_POST['type']);
		$data['channel']		= trim($_POST['channel']);
		$data['owner']			= trim($_POST['owner']);
		$data['email']			= trim($_POST['email']);
        $data['url']			= trim($_POST['url']);
		$data['html5']			= trim($_POST['html5']);
        $data['link']	        = trim($_POST['link']);
		$data['runtime']	    = intval($_POST['runtime']);
        $data['month']			= intval($_POST['month']);
        $data['year']			= intval($_POST['year']);
        $data['day']			= intval($_POST['day']);
		$data['active']			= $_POST['active']  == '1' ? '1' : '0';

		$extension = strrchr($data['url'], '.');
	    
		if (!in_array($extension, $extensions))
            $errors[] = 'Invalid ad source file.';
        elseif ( strlen($data['link']) < 3 )
            $errors[] = 'Link URL cannot be empty!';
        elseif ($data['month']<1 || $data['day']<1 || $data['year']<1)
			$errors[] = 'Expire date not valid';
       
	   if ($data['month']>0 || $data['day']>0 || $data['year']>0)
			$data['expire'] = mktime(0,0,0,$data['month'],$data['day'],$data['year']);

       

        if ( !$errors ) {

            
            $expire = mktime(0,0,0,$data['month'],$data['day'],$data['year']);
            $data['expire'] = $expire;
			$added = time();
			
			if(strlen($data['owner'])>0) $owner =  mysql_real_escape_string($data['owner']); else $owner='';
			if(strlen($data['email'])>0) $email =  mysql_real_escape_string($data['email']); else $email='';
			$type = $data['type'];
			$url = mysql_real_escape_string($data['url']);
			$html5 = mysql_real_escape_string($data['html5']);
			$link = mysql_real_escape_string($data['link']);
			$runtime = mysql_real_escape_string($data['runtime']);
			$channel = mysql_real_escape_string($data['channel']);
			$active = $data['active'];

			$sql = "INSERT into nuevo__preroll SET ID = NULL, type = '$type', channel = '$channel', owner = '$owner', email = '$email', url = '$url', html5 = '$html5', link = '$link', runtime = '$runtime', expire = '$expire',added = '$added', active = '$active'";
			
			$conn->execute($sql);
			if (mysql_affected_rows() == 1) 
			  header ("Location: nuevo.php?m=preroll");
            else
			  $errors[] = "Ad could not be created";
		}

}
$rs=$conn->execute("select * from channel ORDER BY name ASC");
$channels = $rs->getrows();
STemplate::assign('channels', $channels);
STemplate::assign('months', $months);
STemplate::assign('years', $years);
STemplate::assign('days', $days);
STemplate::assign('ad', $data);

?>
