<?php
defined('_VALID') or die('Restricted Access!');
chk_admin_login();


$sql="SELECT * from nuevo__player where ID = 1 limit 1";
$rs = $conn->Execute($sql);
$limit = $rs->getrows();
$data = $limit[0];

if(isset($_POST['submit']))
{
    $data['plugin_limit'] = $_POST['plugin_limit'];
	$data['limit_start'] = intval($_POST['limit_start']);
	$data['limit_media'] = trim($_POST['limit_media']);
	$data['limit_url'] = trim($_POST['limit_url']);


	$sql = "UPDATE nuevo__player SET limit_start = '".mysql_real_escape_string($data['limit_start'])."', plugin_limit = '".mysql_real_escape_string($data['plugin_limit'])."', limit_url = '".mysql_real_escape_string($data['limit_url'])."', limit_media = '".mysql_real_escape_string($data['limit_media'])."' WHERE ID = '1'";

	$conn->execute($sql);
    if ( mysql_affected_rows() >0 )
        $messages[] = 'Watch Limit details updated successfuly!';
    else
        $errors[] = 'Failed to update or nothing changed!';
}

STemplate::assign('data',$data);
?>
