<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();


$data = array();
$months = array (1 => 'January',2 => 'February',3 => 'March', 4 => 'April',5 => 'May', 6 => 'June',7 => 'July', 8 => 'August',9 => 'September',10 => 'October',11 => 'November', 12 => 'December');

$days=array();
for($i=1;$i<=31;$i++) 
  $days[$i] = $i;

$year_beg=2001;
$years=array();
for($i=1;$i<=50;$i++) {
  $years[$i] = $year_beg;
  $year_beg++;
}


if ( isset($_POST['submit']) ) 
{
		$data['owner']          = trim($_POST['owner']);
		$data['email']          = trim($_POST['email']);
		$data['duration']		= intval($_POST['duration']);
		$data['channel']        = trim($_POST['channel']);
		$data['title']          = trim($_POST['title']);
        $data['description']	= trim($_POST['description']);
        $data['url']			= trim($_POST['url']);
        $data['link']	        = trim($_POST['link']);
        $data['image']	        = trim($_POST['image']);
        $data['month']			= intval($_POST['month']);
        $data['year']			= intval($_POST['year']);
        $data['day']			= intval($_POST['day']);
        

		if ( $data['duration'] < 3 )
            $errors[] = 'Invalid value for midroll duration!';
		elseif ( strlen($data['title']) < 3 )
            $errors[] = 'Midroll title field cannot be blank!';
        elseif ( strlen($data['description']) < 3 )
            $errors[] = 'Midroll description field cannot be blank!';
        elseif ( strlen($data['url']) < 3 )
            $errors[] = 'Midroll URL cannot be empty!';
        elseif ($data['month']<1 || $data['day']<1 || $data['year']<1)
			$errors[] = 'Expire date not valid';
       
	   if ($data['month']>0 || $data['day']>0 || $data['year']>0)
			$data['expire'] = mktime(0,0,0,$data['month'],$data['day'],$data['year']);

		$data['active'] = $_POST['active']  == '1' ? '1' : '0';

        if ( !$errors ) {

            $expire = mktime(0,0,0,$data['month'],$data['day'],$data['year']);
            $data['expire'] = $expire;
			$added = time();
			$duration = $data['duration'];
			if(strlen($data['owner'])>0) $owner =  mysql_real_escape_string($data['owner']); else $owner='';
			if(strlen($data['email'])>0) $email =  mysql_real_escape_string($data['email']); else $email='';
			$title = mysql_real_escape_string($data['title']);
			$description = mysql_real_escape_string($data['description']);
			$url = mysql_real_escape_string($data['url']);
			$link = mysql_real_escape_string($data['link']);
			$image = mysql_real_escape_string($data['image']);
			$channel = mysql_real_escape_string($data['channel']);
			$active = $data['active'];

			$sql = "INSERT into nuevo__midroll SET ID = NULL, owner = '$owner', channel='$channel', email = '$email', duration = '$duration', title = '$title', description = '$description',url = '$url', link = '$link', image = '$image', expire = '$expire',added = '$added', active = '$active'";
			echo $sql;
			$conn->execute($sql);
			if (mysql_affected_rows() == 1) 
			  header ("Location: nuevo.php?m=midroll");
            else
			  $errors[] = "Midroll ad could not be created";
		}

}

$rs=$conn->execute("select * from channel ORDER BY name ASC");
$channels = $rs->getrows();

STemplate::assign('channels', $channels);
STemplate::assign('months', $months);
STemplate::assign('years', $years);
STemplate::assign('days', $days);
STemplate::assign('midroll', $data);
?>
