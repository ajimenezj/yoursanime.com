<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();


$sql="SELECT * FROM nuevo__midroll_settings WHERE ID = '1'";
$rs=$conn->execute($sql);
$data=$rs->getrows();
$data=$data['0'];

if(isset($_POST['update'])) {
	
    $data['background'] = trim($_POST['background']);
    $data['opacity'] = intval($_POST['opacity']);
    $data['outline'] = trim($_POST['outline']);
    $data['titlecolor'] = trim($_POST['titlecolor']);
    $data['desccolor'] = trim($_POST['desccolor']); 
	$data['linkcolor'] = trim($_POST['linkcolor']);
	$data['hovercolor'] = trim($_POST['hovercolor']);
	$data['aboutcolor'] = trim($_POST['aboutcolor']);
	$data['abouttext'] = trim($_POST['abouttext']);
	$data['abouturl'] = trim($_POST['abouturl']);
	if (strlen (trim ($data['abouturl'])) > 0 && !preg_match ('#^http[s]?:\/\/#i', $data['abouturl']))
      $data['abouturl'] = "http://".$data['abouturl'];
	$data['canclose'] = trim($_POST['canclose']);
	$data['defstart'] = intval($_POST['defstart']);
	$data['defruntime'] = intval($_POST['defruntime']);

	$hex_pattern = '~^[a-f0-9]{6,6}$~i';

	if(!@preg_match($hex_pattern, $data['background']) || strlen($data['background'])!=6)
		$errors[] = "Invalid value for background color"; 
	if($data['opacity']>100) 
		$errors[] = "Invalid value for background opacity"; 
	if(!@preg_match($hex_pattern, $data['titlecolor']) || strlen($data['titlecolor'])!=6)
		$errors[] = "Invalid value for title color"; 
	if(!@preg_match($hex_pattern, $data['desccolor']) || strlen($data['desccolor'])!=6)
		$errors[] = "Invalid value for description color"; 
	if(!@preg_match($hex_pattern, $data['linkcolor']) || strlen($data['linkcolor'])!=6)
		$errors[] = "Invalid value for link color"; 
	if(!@preg_match($hex_pattern, $data['hovercolor']) || strlen($data['hovercolor'])!=6)
		$errors[] = "Invalid value for hover color";
	if(!@preg_match($hex_pattern, $data['aboutcolor']) || strlen($data['aboutcolor'])!=6)
		$errors[] = "Invalid value for about color"; 
	if($data['defruntime']<3)
		$errors[] = "Runtime value too small. Must be greater than 3.";

	if(!$errors) {
		$sql = "UPDATE nuevo__midroll_settings SET 
			background = '".mysql_real_escape_string($data['background'])."',
			opacity = '".mysql_real_escape_string($data['opacity'])."',
			outline = '".mysql_real_escape_string($data['outline'])."',
			titlecolor = '".mysql_real_escape_string($data['titlecolor'])."',
			desccolor = '".mysql_real_escape_string($data['desccolor'])."',
			linkcolor = '".mysql_real_escape_string($data['linkcolor'])."',
			aboutcolor = '".mysql_real_escape_string($data['aboutcolor'])."',
			hovercolor = '".mysql_real_escape_string($data['hovercolor'])."',
			abouttext = '".mysql_real_escape_string($data['abouttext'])."',
			abouturl = '".mysql_real_escape_string($data['abouturl'])."',
			canclose = '".mysql_real_escape_string($data['canclose'])."',
			canclose = '".mysql_real_escape_string($data['canclose'])."',
			defstart = '".mysql_real_escape_string($data['defstart'])."',
			defruntime = '".mysql_real_escape_string($data['defruntime'])."' WHERE ID = '1'";
		
		$conn->execute($sql);
		if (mysql_affected_rows() == 1) 
			$messages[] = 'Midroll ad settings updated succesfully!';
        else
			$errors[] = "Midroll ad settings were not updated";
	}

}




STemplate::assign('data', $data);
?>
