<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$ads = array();
$ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
settype($ID, 'integer');
if ( !$ID ) 
    $err = 'Invalid overlay ID. This overlay does not exist!';

else {
 
  $sql="select * from nuevo__overlay where ID = '".mysql_real_escape_string($ID)."' LIMIT 1";
  $rs=$conn->execute($sql);
  $ad = $rs->getrows();
  $data = $ad[0];
  
  if($data['views']>0) 
	$data['CTR'] = number_format(round(($data['hits']/$data['views']),2), 2, '.', '');
  else
	$data['CTR'] = "0,00";
  

if ( isset($_POST['submit']) ) 
{

		$data['title']          = trim($_POST['title']);
		$data['media']			= trim($_POST['media']);
		$data['url']		    = trim($_POST['url']);
		$data['target']			= trim($_POST['target']);
		$data['channel']		= trim($_POST['channel']);
		$data['start']			= intval($_POST['start']);
        $data['active'] =		$_POST['active']  == '1' ? '1' : '0';


		if ( strlen($data['title'])<3 )
			$errors[] = "Overlay title cannot be blank";
		elseif ( strlen($data['media'])<5 )
			$errors[] = "Overlay source URL cannot be blank";
		elseif ($data['start']<1)
			$errors[] = "Start time cannot be 0 or blank";
		elseif ($data['runtime']<3)
			$errors[] = "Runtime cannot be less than 3 secoonds";

        if ( !$errors ) {


			$sql = "UPDATE nuevo__overlay SET title = '".mysql_real_escape_string($data['title'])."', media ='".mysql_real_escape_string($data['media'])."', url ='".mysql_real_escape_string($data['url'])."', target ='".mysql_real_escape_string($data['target'])."', channel ='".mysql_real_escape_string($data['channel'])."', start ='".mysql_real_escape_string($data['start'])."', active ='".mysql_real_escape_string($data['active'])."' WHERE ID ='".$ID."'";
			
			$conn->execute($sql);
			if (mysql_affected_rows() == 1) 
			  $messages[] = 'Overlay ad updated succesfully!';
            else
			  $errors[] = "Overlay ad was not updated";
        }

}

}

$rs=$conn->execute("select * from channel ORDER BY name ASC");
$channels = $rs->getrows();
STemplate::assign('channels', $channels);
STemplate::assign('ad', $data);
?>
