<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require $config['BASE_DIR']. '/classes/pagination.class.php';

$ads=array();
$remove = NULL;
if(isset($_POST['new_ad'])) {
  header("Location: nuevo.php?m=midrollnew");
}

if ( isset($_GET['a']) && $_GET['a'] != '' ) {
    $action = trim($_GET['a']);
    $ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
    if ( $ID ) {
        switch ( $action ) {
            case 'delete':
                $sql="delete from nuevo__midroll where ID = '" .mysql_real_escape_string($ID). "' limit 1";
			    $conn->execute($sql);
                $messages[] = 'Midroll ad deleted successfuly!';
                $remove = '&a=delete&ID=' .$ID;
                break;
            case 'suspend':
                $sql = "UPDATE nuevo__midroll SET active = '0' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Midroll ad suspended successfuly!';
                $remove = '&a=suspend&ID=' .$ID;
                break;
            case 'activate':
                $sql = "UPDATE nuevo__midroll SET active = '1' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Midroll ad activated successfuly!';
                $remove = '&a=activate&ID=' .$ID;
                break;
        }
    } else {
        $error[] = 'Invalid midroll ad id. Midroll ad does not exist!?';
    }
}

$query          = constructQuery();
$sql            = $query['count'];
$rs             = $conn->execute($sql);
$total_ads	    = $rs->fields['total_ads'];
$pagination     = new Pagination($query['page_items']);
$limit          = $pagination->getLimit($total_ads);
$paging         = $pagination->getAdminPagination($remove);
$sql            = $query['select']. " LIMIT " .$limit;
$rs             = $conn->execute($sql);
$ads         = $rs->getrows();

function constructQuery()
{
    global $smarty;
	$query_module = "";

    $query              = array();
    $query_select       = "SELECT * FROM nuevo__midroll";
    $query_count        = "SELECT count(*) AS total_ads FROM nuevo__midroll";
    $query_add          = ( $query_module != '' ) ? " AND" : " WHERE";
    $query_option       = array();
    $option             = array('sort' => 'ID', 'order' => 'DESC', 'display' => 20);
    if ( isset($_POST['search_ads']) ) {
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
    }

    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    
	STemplate::assign('option', $option);
    
    return $query;
}
$sql="SELECT * from channel ORDER BY CHID ASC";
$rs=$conn->execute($sql);
$ch=$rs->getrows();
$channels=array(); $channels['0'] = 'All';
foreach($ch as $chan) { $channels[$chan['CHID']] = $chan['name']; }

STemplate::assign('channels', $channels);
STemplate::assign('ads', $ads);
STemplate::assign('total_ads', $total_ads);
STemplate::assign('paging', $paging);
?>
