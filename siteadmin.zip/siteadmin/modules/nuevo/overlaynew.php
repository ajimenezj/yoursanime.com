<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();


$data = array();
$data['start'] = '10';

if ( isset($_POST['submit']) ) 
{
		
		$data['title']          = trim($_POST['title']);
		$data['media']			= trim($_POST['media']);
		$data['url']		    = trim($_POST['url']);
		$data['target']			= trim($_POST['target']);
		$data['start']			= intval($_POST['start']);
		$data['channel']        = trim($_POST['channel']);
        

		if ( strlen($data['title'])<3 )
			$errors[] = "Overlay title cannot be blank";
		elseif ( strlen($data['media'])<5 )
			$errors[] = "Overlay source URL cannot be blank";
		elseif ($data['start']<1)
			$errors[] = "Start time cannot be 0 or blank";

		$data['active'] = $_POST['active']  == '1' ? '1' : '0';

        if ( !$errors ) {

			$sql = "INSERT into nuevo__overlay SET title = '".mysql_real_escape_string($data['title'])."', media ='".mysql_real_escape_string($data['media'])."', url ='".mysql_real_escape_string($data['url'])."', target ='".mysql_real_escape_string($data['target'])."', channel ='".mysql_real_escape_string($data['channel'])."', start ='".mysql_real_escape_string($data['start'])."', addtime ='".mysql_real_escape_string(time())."', active ='".mysql_real_escape_string($data['active'])."'";
			
			$conn->execute($sql);
			if (mysql_affected_rows() == 1) 
			  header ("Location: nuevo.php?m=overlay");
            else
			  $errors[] = "Overlay ad could not be created";
		}

}

$rs=$conn->execute("select * from channel ORDER BY name ASC");
$channels = $rs->getrows();
STemplate::assign('channels', $channels);
STemplate::assign('ad', $data);
?>
