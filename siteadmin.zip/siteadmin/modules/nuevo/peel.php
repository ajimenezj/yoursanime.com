<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

require '../classes/pagination.class.php';

$remove = NULL;
if ( isset($_GET['a']) && $_GET['a'] != '' ) {
    $action = trim($_GET['a']);
    $ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
    if ( $ID ) {
        switch ( $action ) {
            case 'delete':
                $sql="delete from nuevo__peel where ID = '$ID' limit 1";
			    $conn->execute($sql);
                $messages[] = 'Peel effect deleted successfuly!';
                $remove = '&a=delete&ID=' .$ID;
                break;
            case 'suspend':
                $sql = "UPDATE nuevo__peel SET active = '0' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Peel effect suspended successfuly!';
                $remove = '&a=suspend&ID=' .$ID;
                break;
            case 'activate':
                $sql = "UPDATE nuevo__peel SET active = '1' WHERE ID = '" .mysql_real_escape_string($ID). "' LIMIT 1";
                $conn->execute($sql);
                $messages[] = 'Peel effect activated successfuly!';
                $remove = '&a=activate&ID=' .$ID;
                break;
        }
    } else {
        $err = 'Invalid Peel Effect id. Peel Effect does not exist!?';
    }
}

$query          = constructQuery();
$sql            = $query['count'];
$rs             = $conn->execute($sql);
$total_ads	    = $rs->fields['total_ads'];
$pagination     = new Pagination($query['page_items']);
$limit          = $pagination->getLimit($total_ads);
$paging         = $pagination->getAdminPagination($remove);
$sql            = $query['select']. " LIMIT " .$limit;
$rs             = $conn->execute($sql);
$ads			= $rs->getrows();

function constructQuery()
{
    global $smarty;
	$query_module = '';

    $query              = array();
    $query_select       = "SELECT * FROM nuevo__peel";
    $query_count        = "SELECT count(*) AS total_ads FROM nuevo__peel" .$query_module;
    $query_add          = ( $query_module != '' ) ? " AND" : " WHERE";
    $query_option       = array();
    $option             = array('sort' => 'ID', 'order' => 'DESC', 'display' => 10);

    if ( isset($_POST['search_peel']) ) {
        $option['sort']         = trim($_POST['sort']);
        $option['order']        = trim($_POST['order']);
        $option['display']      = trim($_POST['display']);
    }
	else {
		$option['sort'] = 'ID';
		$option['order'] = "DESC";
		$option['display'] = 10;
	}

    $query_option[]         = " ORDER BY " .$option['sort']. " " .$option['order'];    
    $query['select']        = $query_select .implode(' ', $query_option);
    $query['count']         = $query_count .implode(' ', $query_option);
    $query['page_items']    = $option['display'];
    STemplate::assign('option', $option);

    return $query;
}


STemplate::assign('ads', $ads);
STemplate::assign('total_ads', $total_ads);
STemplate::assign('paging', $paging);
?>
