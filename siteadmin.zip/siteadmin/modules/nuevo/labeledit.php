<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$hex_pattern = '~^[a-f0-9]{6,6}$~i';
$ads = array();
$ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
settype($ID, 'integer');
if ( !$ID ) 
    $errors[] = 'Invalid message ID. Player message does not exist!';

else {
 
  $sql="select * from nuevo__ticker where ID = '".mysql_real_escape_string($ID)."' LIMIT 1";
  $rs=$conn->execute($sql);
  $ad = $rs->getrows();
  $data = $ad[0];
  

if ( isset($_POST['submit']) ) 
{
		$data['text']          = trim($_POST['text']);
		$data['start']			= intval(trim($_POST['start']));
		$data['runtime']		    = intval(trim($_POST['runtime']));
		$data['scrollspeed']	= intval(trim($_POST['scrollspeed']));
		$data['opacity']		= intval($_POST['opacity']);
		$data['position']		= trim($_POST['position']);
        $data['active'] =		$_POST['active'];
		$data['url']		    = trim($_POST['url']);
		$data['target']		= trim($_POST['target']);


		if ( strlen($data['text'])<1 )
			$errors[] = "Message text cannot be blank";
		if ($data['start']<1)
			$errors[] = "Start time cannot be 0 or blank";
		if ($data['runtime']<3)
			$errors[] = "Runtime cannot be less than 3 secoonds";
		if ($data['opacity']<25 || $data['opacity']>100)
			$errors[] = "Opacity value must be betwee 25-100";

        if ( !$errors ) {

			$sql = "UPDATE nuevo__ticker SET text = '".mysql_real_escape_string($data['text'])."', start ='".mysql_real_escape_string($data['start'])."', runtime ='".mysql_real_escape_string($data['runtime'])."', scrollspeed ='".mysql_real_escape_string($data['scrollspeed'])."', opacity ='".mysql_real_escape_string($data['opacity'])."', position ='".mysql_real_escape_string($data['position'])."', url ='".mysql_real_escape_string($data['url'])."', target ='".mysql_real_escape_string($data['target'])."', addtime ='".mysql_real_escape_string(time())."', active ='".mysql_real_escape_string($data['active'])."' WHERE ID = '".mysql_real_escape_string($ID)."'";
			
			$result=$conn->execute($sql);
			if ($result) 
			  $messages[] = 'Player label updated succesfully!';
            else
			  $errors[] = "Player label was not updated";
        }

}

}


STemplate::assign('ad', $data);
?>
