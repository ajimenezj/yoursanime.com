<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$ads = array();
$ID    = ( isset($_GET['ID']) && is_numeric($_GET['ID']) ) ? trim($_GET['ID']) : NULL;
settype($ID, 'integer');
if ( !$ID ) 
    $errors[] = 'Invalid Peel ID. This Peel does not exist!';

else {
  $sql="select * from nuevo__peel where ID = '".mysql_real_escape_string($ID)."' LIMIT 1";
  $rs=$conn->execute($sql);
  $ad = $rs->getrows();
  $data = $ad[0];
}

if(isset($_POST['submit']))
{

	$data['active'] = $_POST['active'];
	$data['image'] = trim($_POST['image']);
    if (strlen (trim ($data['image'])) > 0 && !preg_match ('#^http[s]?:\/\/#i', $data['image']))
      $data['image'] = "http://".$data['image'];
	$data['url'] = trim($_POST['url']);
	$data['target'] = trim($_POST['target']);
	$data['title'] = trim($_POST['title']);
	$data['subtitle'] = trim($_POST['subtitle']);

	$sql = "UPDATE nuevo__peel SET active = '".mysql_real_escape_string($data['active'])."', image = '".mysql_real_escape_string($data['image'])."', url = '".mysql_real_escape_string($data['url'])."', target = '".mysql_real_escape_string($data['target'])."', title = '".mysql_real_escape_string($data['title'])."', subtitle = '".mysql_real_escape_string($data['subtitle'])."'  WHERE ID ='".$ID."'";


	$conn->execute($sql);
    if ( mysql_affected_rows() >0 )
        $messages[] = 'Pell effct updated successfuly!';
    else
        $errors[] = 'Failed to update or nothing changed!';
}

STemplate::assign('data', $data);
?>
