<?php
defined('_VALID') or die('Restricted Access!');

chk_admin_login();

$hex_pattern = '~^[a-f0-9]{6,6}$~i';
$player_data = array();

$sql="SELECT * from nuevo__player where ID = 1 limit 1";
	$rs = $conn->Execute($sql);
    $player_data = $rs->getrows();
	$data = $player_data[0];


if(isset($_POST['submit']))
{
    $data['regkey'] = trim($_POST['regkey']);
	$data['skin'] = trim($_POST['skin']);
	if($data['skin']=='default') $data['skin']='';
	$data['html5skin'] = trim($_POST['html5skin']);
	$data['stretching'] = trim($_POST['stretching']);
	$data['player_width'] = intval($_POST['player_width']);
	$data['player_height'] = intval($_POST['player_height']);


	$data['autostart'] = $_POST['autostart'] ;
	$data['volume'] = intval($_POST['volume']);
	$data['usetooltips'] = $_POST['usetooltips'];
	$data['skip_preroll'] = intval($_POST['skip_preroll']);

	$data['backcolor'] = strtoupper(trim($_POST['backcolor']));
	$data['wmode'] = trim($_POST['wmode']);
	$data['html5folder'] = trim($_POST['html5folder']);
	$data['hdfolder'] = trim($_POST['hdfolder']);

	$data['playbar'] = trim($_POST['playbar']);
	$data['playbarhide'] = intval($_POST['playbarhide']);
	
	//$data['playbaralpha'] = intval($_POST['playbaralpha']);
	//$data['playbaroffsety'] = intval($_POST['playbaroffsety']);
	//$data['playbaroffsetx'] = intval($_POST['playbaroffsetx']);
	//$data['fullheight'] = $_POST['fullheight'];

	$data['viral_show'] = $_POST['viral_show'];
	$data['viral_offset'] = intval($_POST['viral_offset']);
	$data['viral_align'] = $_POST['viral_align'];

	$data['videoquality'] = $_POST['videoquality'];
	$data['bufferlength'] = intval($_POST['bufferlength']);


	$data['logo'] = trim($_POST['logo']);
	$data['logourl'] = trim($_POST['logourl']);
	$data['logoalign'] = trim($_POST['logoalign']);
	$data['logooffsetx'] = intval($_POST['logooffsetx']);
	$data['logooffsety'] = intval($_POST['logooffsety']);

	$data['menuitem'] = $_POST['menuitem'];
	$data['menutext'] = trim($_POST['menutext']);
	$data['menulink'] = trim($_POST['menulink']);
    $data['slomointerval'] = intval($_POST['slomointerval']);

	$data['statscript'] = trim($_POST['statscript']);
	$data['rss_url'] = trim($_POST['rss_url']);
	$data['mailsubject'] = trim($_POST['mailsubject']);
	$data['mailbody'] = trim($_POST['mailbody']);
	
	$data['guide'] = $_POST['guide']; if($data['guide']=='0') $data['guide']='';
	$data['guide_show'] = $_POST['guide_show'];
	$data['embed_show'] = $_POST['embed_show'];
	$data['email_show'] = $_POST['email_show'];
	$data['share_show'] = $_POST['share_show'];
	

	$data['replay_button'] = $_POST['replay_button'];
	$data['slomo_button'] = $_POST['slomo_button'];
	$data['zoom_button'] = $_POST['zoom_button'];
	$data['settings_button'] = $_POST['settings_button'];
	$data['volume_button'] = $_POST['volume_button'];
	$data['size_button'] = $_POST['size_button'];
	$data['fullscreen_button'] = $_POST['fullscreen_button'];
	$data['menu_button'] = $_POST['menu_button'] ;
	$data['resize_button'] = $_POST['resize_button'];

    $data['provider'] = $_POST['provider'];
	$data['streamer'] = $_POST['streamer'];
	$data['httpparam'] = $_POST['httpparam'];

	$data['hdicon'] = $_POST['hdicon'];
	$data['hdalign'] = $_POST['hdalign'];
	$data['hdfirst'] = $_POST['hdfirst'];

	$data['hovercolor'] = strtoupper(trim($_POST['hovercolor']));
	$data['viral_backhover'] = strtoupper(trim($_POST['viral_backhover']));
	$data['viral_texthover'] = strtoupper(trim($_POST['viral_texthover']));

	$data['plugin_midroll'] = trim($_POST['plugin_midroll']);
	$data['plugin_overlay'] = trim($_POST['plugin_overlay']);
	$data['plugin_ticker'] = trim($_POST['plugin_ticker']);

   if(!is_numeric(trim($data['player_width'])))
	  $errors[] = "Invalid value for player width";
   if(!is_numeric(trim($data['player_height'])))
	  $errors[] = "Invalid value for player height";
   if(!is_numeric(trim($data['volume'])) || trim($data['volume'])>100)	
	  $errors[] = "Invalid volume value";
   if(!is_numeric(trim($data['bufferlength'])) || trim($data['bufferlength'])>15 || trim($data['bufferlength'])<1)
	  $errors[] = "Invalid value for buffer length (max 15)";
   if(!is_numeric(trim($data['playbaralpha'])) || intval($data['playbaralpha'])<0 || intval($data['playbaralpha'])>100)
	  $errors[] = "Invalid playbar opacity value";
   if(!is_numeric(trim($data['playbaroffsetx'])))
	  $errors[] = "Invalid playbar offset X value";
   if(!is_numeric(trim($data['playbaroffsety'])))
	  $errors[] = "Invalid playbar offset Y value";
   if(!is_numeric(trim($data['viral_offset'])))
	  $errors[] = "Invalid viral icons offset value";
   if(!is_numeric(trim($data['bufferlength'])))
	  $errors[] = "Invalid value for buffer length";
   if(!is_numeric(trim($data['logooffsetx'])))
	  $errors[] = "Invalid logo offset X value";
   if(!is_numeric(trim($data['logooffsety'])))
	  $errors[] = "Invalid logo offset Y value";
   if(!@preg_match($hex_pattern, $data['hovercolor']) || strlen($data['hovercolor'])!=6)
		$errors[] = "Invalid value for Buttons mouseover color";
   if(!@preg_match($hex_pattern, $data['viral_backhover']) || strlen($data['viral_backhover'])!=6)
		$errors[] = "Invalid value for Viral icons back color";
   if(!@preg_match($hex_pattern, $data['viral_texthover']) || strlen($data['viral_texthover'])!=6)
		$errors[] = "Invalid value for Viral icons text color";

   if( !$errors ) 
   {
		$sql = update_player($data)." where ID = 1";
		
		
		$result = $conn->execute($sql);
   
		if (mysql_affected_rows() == 1) {
			$messages[]="Player settings updated succesfully";
        
		$sql="UPDATE nuevo__player set 
		   regkey='".mysql_real_escape_string($data['regkey'])."',
		   wmode='".mysql_real_escape_string($data['wmode'])."',
		   html5folder='".mysql_real_escape_string($data['html5folder'])."',
		   hdfolder='".mysql_real_escape_string($data['hdfolder'])."',
		   volume='".mysql_real_escape_string($data['volume'])."',
		   skip_preroll='".mysql_real_escape_string($data['skip_preroll'])."',
		   volume='".mysql_real_escape_string($data['volume'])."',
		   usetooltips='".mysql_real_escape_string($data['usetooltips'])."',
		   videoquality='".mysql_real_escape_string($data['videoquality'])."',
		   bufferlength='".mysql_real_escape_string($data['bufferlength'])."',		   
		   logo='".mysql_real_escape_string($data['logo'])."',
		   logourl='".mysql_real_escape_string($data['logourl'])."',
		   logoalign='".mysql_real_escape_string($data['logoalign'])."',
		   logooffsetx='".mysql_real_escape_string($data['logooffsetx'])."',
		   logooffsety='".mysql_real_escape_string($data['logooffsety'])."',
		   slomointerval='".mysql_real_escape_string($data['slomointerval'])."',
		   menuitem='".mysql_real_escape_string($data['menuitem'])."',
		   menutext='".mysql_real_escape_string($data['menutext'])."',
		   menulink='".mysql_real_escape_string($data['menulink'])."',
		   mailsubject='".mysql_real_escape_string($data['mailsubject'])."',
		   mailbody='".mysql_real_escape_string($data['mailbody'])."',
		   rss_url='".mysql_real_escape_string($data['rss_url'])."',
		   statscript='".mysql_real_escape_string($data['statscript'])."',
		   provider='".mysql_real_escape_string($data['provider'])."',
		   streamer='".mysql_real_escape_string($data['streamer'])."',
		   httpparam='".mysql_real_escape_string($data['httpparam'])."' WHERE ID>0";
		   
		   $conn->execute($sql);
		
		}
		else
			$errors[]="Settings were not updated";
   }
}

function update_player($data)
{

	$sql="UPDATE nuevo__player set 
		   regkey='".mysql_real_escape_string($data['regkey'])."',
		   skin='".mysql_real_escape_string($data['skin'])."',
		   html5skin='".mysql_real_escape_string($data['html5skin'])."',
		   stretching='".mysql_real_escape_string($data['stretching'])."',
		   player_width='".mysql_real_escape_string($data['player_width'])."',
		   player_height='".mysql_real_escape_string($data['player_height'])."',
		   backcolor='".mysql_real_escape_string($data['backcolor'])."',
		   wmode='".mysql_real_escape_string($data['wmode'])."',
		   html5folder='".mysql_real_escape_string($data['html5folder'])."',
		   hdfolder='".mysql_real_escape_string($data['hdfolder'])."',
		   autostart='".mysql_real_escape_string($data['autostart'])."',
		   volume='".mysql_real_escape_string($data['volume'])."',
		   skip_preroll='".mysql_real_escape_string($data['skip_preroll'])."',
		   usetooltips='".mysql_real_escape_string($data['usetooltips'])."',
		   playbar='".mysql_real_escape_string($data['playbar'])."',
		   playbarhide='".mysql_real_escape_string($data['playbarhide'])."',
		   viral_show='".mysql_real_escape_string($data['viral_show'])."',
		   viral_offset='".mysql_real_escape_string($data['viral_offset'])."',
		   viral_align='".mysql_real_escape_string($data['viral_align'])."',
		   videoquality='".mysql_real_escape_string($data['videoquality'])."',
		   bufferlength='".mysql_real_escape_string($data['bufferlength'])."',	
		   logo='".mysql_real_escape_string($data['logo'])."',
		   logourl='".mysql_real_escape_string($data['logourl'])."',
		   logoalign='".mysql_real_escape_string($data['logoalign'])."',
		   logooffsetx='".mysql_real_escape_string($data['logooffsetx'])."',
		   logooffsety='".mysql_real_escape_string($data['logooffsety'])."',
		   menuitem='".mysql_real_escape_string($data['menuitem'])."',
		   menutext='".mysql_real_escape_string($data['menutext'])."',
		   menulink='".mysql_real_escape_string($data['menulink'])."',
		   statscript='".mysql_real_escape_string($data['statscript'])."',
		   rss_url='".mysql_real_escape_string($data['rss_url'])."',
		   mailsubject='".mysql_real_escape_string($data['mailsubject'])."',
		   mailbody='".mysql_real_escape_string($data['mailbody'])."',
		   embed_show='".mysql_real_escape_string($data['embed_show'])."',
		   guide='".mysql_real_escape_string($data['guide'])."',
		   guide_show='".mysql_real_escape_string($data['guide_show'])."',
		   email_show='".mysql_real_escape_string($data['email_show'])."',
		   share_show='".mysql_real_escape_string($data['share_show'])."',
		   slomointerval='".mysql_real_escape_string($data['slomointerval'])."',
		   replay_button='".mysql_real_escape_string($data['replay_button'])."',
		   slomo_button='".mysql_real_escape_string($data['slomo_button'])."',
		   zoom_button='".mysql_real_escape_string($data['zoom_button'])."',
		   settings_button='".mysql_real_escape_string($data['settings_button'])."',
		   volume_button='".mysql_real_escape_string($data['volume_button'])."',
		   size_button='".mysql_real_escape_string($data['size_button'])."',
		   fullscreen_button='".mysql_real_escape_string($data['fullscreen_button'])."',
		   menu_button='".mysql_real_escape_string($data['menu_button'])."',
		   resize_button='".mysql_real_escape_string($data['resize_button'])."',
		   provider='".mysql_real_escape_string($data['provider'])."',
		   streamer='".mysql_real_escape_string($data['streamer'])."',
		   httpparam='".mysql_real_escape_string($data['httpparam'])."',
		   hdicon='".mysql_real_escape_string($data['hdicon'])."',
		   hdalign='".mysql_real_escape_string($data['hdalign'])."',
		   hdfirst='".mysql_real_escape_string($data['hdfirst'])."',
		   plugin_midroll='".mysql_real_escape_string($data['plugin_midroll'])."',
		   plugin_overlay='".mysql_real_escape_string($data['plugin_overlay'])."',
		   plugin_ticker='".mysql_real_escape_string($data['plugin_ticker'])."',
		   hovercolor='".mysql_real_escape_string($data['hovercolor'])."',
		   viral_backhover='".mysql_real_escape_string($data['viral_backhover'])."',
		   viral_texthover='".mysql_real_escape_string($data['viral_texthover'])."'";

		return $sql;
}


$dir = $config['BASE_DIR']."/nuevo/skins";
$skins=array();$html5skins=array();
if ($dh = opendir($dir)) {
    while (($file = readdir($dh)) !== false) 
	{
		//if(is_dir($file)) { echo $file};
		$filename=strtolower($file);
		if (substr($filename, -4)=='.swf') {
			$skins[] = str_replace('.swf','',$filename);
		} 

	}
    closedir($dh);
}
$direct=$dir.'/';
foreach(glob($direct.'*', GLOB_ONLYDIR) as $dir) {
    $dir = str_replace($direct, '', $dir);
    $html5skins[] = $dir;
}

$skin = $data['skin']; if ($skin=='') $skin='black';

$sql="select * from nuevo__pallete WHERE skin = '".mysql_real_escape_string($skin)."'";
$rs=$conn->execute($sql);
$palette = $rs->getrows();
$palette = $palette['0'];

Stemplate::assign('palette',$palette);
Stemplate::assign('skins',$skins);
Stemplate::assign('html5skins',$html5skins);
Stemplate::assign('player',$data);
STemplate::assign('errors',$errors);
STemplate::assign('messages',$messages);
?>
