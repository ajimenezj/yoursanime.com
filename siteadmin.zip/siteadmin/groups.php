<?php
define('_VALID', true);
require('../include/config.php');
require('../include/function.php');
require('../include/function_admin.php');

chk_admin_login();

$module             = ( isset($_GET['m']) && $_GET['m'] != '' ) ? trim($_GET['m']) : 'all';
$module_keep        = NULL;
$module_template    = 'groups.tpl';
$modules_allowed    = array('all', 'public', 'private', 'protected', 'view', 'edit', 'mail',
                            'videos', 'members', 'posts', 'topics', 'topicedit', 'postedit');
if ( !in_array($module, $modules_allowed) ) {
    $module = 'all';
    $err    = 'Invalid Groups Module!';
}

switch ( $module ) {
    case 'view':
    case 'edit':
    case 'members':
    case 'videos':
    case 'posts':
    case 'topics':
    case 'mail':
    case 'topicedit':
    case 'postedit':
        $module_template = 'groups_' .$module. '.tpl';
        break;
    case 'all':
    case 'public':
    case 'private':
    case 'protected':
    default:
        $module_keep        = $module;
        $module             = 'all';
        $module_template    = 'groups.tpl';
        break;
}
require 'modules/groups/' .$module. '.php';

STemplate::assign('err', $err);
STemplate::assign('msg', $msg);
STemplate::assign('active_menu', 'groups');
STemplate::assign('module', $module_keep);
STemplate::display('siteadmin/header.tpl');
STemplate::display('siteadmin/leftmenu/groups.tpl');
STemplate::display('siteadmin/' .$module_template);
STemplate::display('siteadmin/footer.tpl');
?>
