var anylinkmenu1={divclass:'anylinkmenu', inlinestyle:'', linktarget:''} //First menu variable. Make sure "anylinkmenu1" is a unique name!
anylinkmenu1.items=[
	["My Profile", "/my_profile"],
	["My Videos", "/my_videos"],
	["My Favorites", "/my_favorites"],
	["My Playlist", "/my_playlists"],
	["My Inbox", "/inbox.php"] //no comma following last entry!
]







