Template By Christopher Boyce (chris) & Primoz Cigoj (blacky) from Freshsubject.com
Released: 17th June 2009
Clipshare: Version 4.1.5
Support: http://helpdesk.freshsubject.com
ClientArea: http://clientarea.freshsubject.com

Please keep a note of your order number when opening tickets in support.  You may be asked to provide it.

Please see license.txt for license agreement.