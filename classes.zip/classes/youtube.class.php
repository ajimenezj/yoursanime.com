<?php
class YoutubeRipper
{
    var $youtube_url;
    var $youtube_page;
    function __construct( $url )
    {
        $this->check();
        $this->youtube_url = $url;
    }

    function YoutubeRipper( $url )
    {
        $this->__construct($url);
    }
    
    function getVideoID()
    {
        $position       = strpos($this->youtube_url, 'watch?v=')+8;
        $remove_length  = strlen($this->youtube_url)-$position;
        $video_id       = substr($this->youtube_url, -$remove_length, 11);
        
        return $video_id;
    }
    
    function getVideoDetails( $video_id )
    {
        $video_details      = array('title' => '', 'desc' => '', 'keywords' => '', 'category' => '', 'duration' => '');
        $video_details_xml  = $this->curlSaveToString('http://gdata.youtube.com/feeds/api/videos/' .$video_id);
        if ( !$video_details_xml ) {
            return false;
        }
        
        if ( preg_match("/<media:title type='plain'>(.*)<\/media:title>/", $video_details_xml, $matches) ) {
            if ( isset($matches['1']) ) {
                $video_details['title'] = $matches['1'];
            }
        }

        if ( preg_match("/<media:description type='plain'>(.*?)<\/media:description>/si", $video_details_xml, $matches) ) {
            if ( isset($matches['1']) ) {
                $video_details['desc'] = $matches['1'];
            }
        }
        
        if ( preg_match("/<media:keywords/>(.*)<\/media:keywords>/", $video_details_xml, $matches) ) {
            if ( isset($matches['1']) ) {
                $video_details['keywords'] = $matches['1'];
            }
        }
        
        if ( preg_match("/<yt:duration seconds='(\d+)'\/>/", $video_details_xml, $matches) ) {
            if ( isset($matches['1']) ) {
                $video_details['duration'] = $matches['1'];
            }
        }

        if ( preg_match("/<media:category label='(.*)' scheme='http:\/\/gdata.youtube.com\/schemas\/2007\/categories.cat'>(.*)<\/media:category>/", $video_details_xml, $matches) ) {
            if ( isset($matches['1']) ) {
                $video_details['category'] = $matches['1'];
            }
        }
        
        return $video_details;
    }
    
    function getVideoThumbs( $youtube_id, $VID )
    {
        global $config;
                
        $thumb1     = $config['TMB_DIR']. '/' .$VID. '.jpg';
        $thumb2     = $config['TMB_DIR']. '/1_' .$VID. '.jpg';
        $thumb3     = $config['TMB_DIR']. '/2_' .$VID. '.jpg';
        $thumb4     = $config['TMB_DIR']. '/3_' .$VID. '.jpg';
        
        $this->curlSaveToFile('http://img.youtube.com/vi/' .$youtube_id. '/default.jpg', $thumb1);
        $this->curlSaveToFile('http://img.youtube.com/vi/' .$youtube_id. '/1.jpg', $thumb2);
        $this->curlSaveToFile('http://img.youtube.com/vi/' .$youtube_id. '/2.jpg', $thumb3);
        $this->curlSaveToFile('http://img.youtube.com/vi/' .$youtube_id. '/3.jpg', $thumb4);
        
        if ( file_exists($thumb1) && file_exists($thumb2) && file_exists($thumb3) && file_exists($thumb4) ) {
            return true;
        }
        
        return false;
    }
    
    function getVideoEmbed( $youtube_id )
    {
        return '<object width="450" height="370"><param name="movie" value="http://www.youtube.com/v/' .$youtube_id. '"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/' .$youtube_id. '" type="application/x-shockwave-flash" wmode="transparent" width="425" height="355"></embed></object>';
    }
    
    function getVideoURL()
    {
        include('curl.class.php');
        $link = youtube::get($this->youtube_url);
        
        $page = $this->curlSaveToString($this->youtube_url);
        if ( !$page ) {
            return false;
        }
        
        
        
        
        $link = youtube::get($this->youtube_url);
        if($link == ''){
          $link = youtube::get($this->youtube_url);
          if($link == ''){
            $link = youtube::get($this->youtube_url);
            if($link == ''){
              $link = youtube::get($this->youtube_url);
              if($link == ''){
                $link = youtube::get($this->youtube_url);
                if($link == ''){
                  $link = youtube::get($this->youtube_url);
                }
              }
            }
          }
        }
        
        $lp = explode('=',$link);
        if($lp[0] == '&signature'){
          $link = youtube::get($this->youtube_url);
          if($link == ''){
            $link = youtube::get($this->youtube_url);
            if($link == ''){
              $link = youtube::get($this->youtube_url);
              if($link == ''){
                $link = youtube::get($this->youtube_url);
                if($link == ''){
                  $link = youtube::get($this->youtube_url);
                  if($link == ''){
                    $link = youtube::get($this->youtube_url);
                  }
                }
              }
            }
          }        
        }
        
        $lp = explode('=',$link);
        if($lp[0] == '&signature'){
          $link = youtube::get($this->youtube_url);
          if($link == ''){
            $link = youtube::get($this->youtube_url);
            if($link == ''){
              $link = youtube::get($this->youtube_url);
              if($link == ''){
                $link = youtube::get($this->youtube_url);
                if($link == ''){
                  $link = youtube::get($this->youtube_url);
                  if($link == ''){
                    $link = youtube::get($this->youtube_url);
                  }
                }
              }
            }
          }        
        }        
                
        
        
        
        
        
        if ($link != '') { return $link; }
        return false;
    }
    
    function getVideoFLV( $url, $VID )
    {
        global $config;
        
        $flv = $config['FLVDO_DIR']. '/' .$VID. '.flv';
        if ( !$this->curlSaveToFile($url, $flv) ) {
            return false;
        }
        
        return true;
    }
    
    function curlSaveToString( $url )
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_NOPROGRESS, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        if ( curl_errno($ch) ) {
            return false;
        }
        
        $string = curl_exec($ch);
        return $string;
    }
    
    function curlSaveToFile( $url, $local )
    {
      
        $ch  = curl_init();
        $fh  = fopen($local, 'w');
        curl_setopt($ch, CURLOPT_URL, urldecode($url));
        curl_setopt($ch, CURLOPT_FILE, $fh);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_VERBOSE, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_NOPROGRESS, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1');
        curl_exec($ch);
        if( curl_errno($ch) ) {
            return false;
        }
        
        curl_close($ch);
        fclose($fh);
        
        if( filesize($local) > 10 ) {
            return true;
        }
        
        return false;
    }
    
    function getXMLTagContents( $xmlcode, $tag ) {
        $i          = 0;
        $offset     = 0;
        $xmlcode    = trim($xmlcode);
        
        do {
            $start_tag          = strpos ($xmlcode, '<' .$tag. '>', $offset);
            $offset             = $start_tag;
            $end_tag            = strpos ($xmlcode, '</' .$tag. '>', $offset);
            $offset             = $end_tag;
            $our_tag            = substr ($xmlcode,$start_tag,($end_tag-$start_tag));
            $start_tag_length   = strlen('<' .$tag. '>');
            if ( substr($our_tag,0 , $start_tag_length) == '<' .$tag. '>' ) {
                $our_tag = substr ($our_tag,$start_tag_length);
            }
            $array_of_tags[$i] = $our_tag;
            ++$i;
        } while( !(strpos($xmlcode, '<' .$tag. '>', $offset) === false) );
        
        return $array_of_tags;
    }
    
    function check()
    {
        if ( !function_exists('curl_init') ) {
            die('You need CURL support in PHP to use this script!');
        }
    }
}

class youtube {
    
    var $conn = false;
    var $username = "";
    var $password = "";
    var $error = false;
          
    function get($url)
    {
        $this->conn = new Curl('youtube');
        
        $html = $this->conn->get($url);

        if(strstr($html,'verify-age-thumb'))
        {
            $this->error = "Adult Video Detected";
            return false;
        }

        if(strstr($html,'das_captcha'))
        {
            $this->error = "Captcah Found please run on diffrent server";
            return false;
        }

	      if(!preg_match('/encoded_fmt_stream_map.*/',$html,$match))
        {
            $this->error = "Error Locating Download URL's";
            return false;
        }


	      // If Valid Link Data Found
	      $html = urldecode($html);
	      // ----- Preferred Format ----- //
	      $pref = 'flv'; // flv,mp4
	      $qual = 'medium'; // high,medium,low
	      // ----- Preferred Format ----- //
	              
        // If Valid Link Data Found
	      if(preg_match('/(fmt_stream_map"\: ")(.*?)(")/i',$html,$matches)){ 
          // Core Data
          $link = $matches[2];
		      
          // Split Link Entires
          $split = explode(',',$link);                               

          // Define Arrays
          $mp4_links = array();
          $flv_links = array();
          $ukn_links = array();
          
          // Define Debug
          $cdebug = '';
          
          
          //echo "COUNT(".count($split).")";
          // Loop Split Array
          foreach($split as $vlink){
          
            // Clear Values
            $_url = '';
            $_sig = '';
            $_type = '';
            $_quality = '';
            $_itag = '';
            
            // Loop Parts
            foreach($part as $vpart){
           
              // Key => Value Pair    
              $arr = explode('=',$vpart);
            
              // Get all the parts
              if($arr[0] == 'url'){
                $_url = trim($arr[1]);
              }
              if($arr[0] == 'sig'){
                $_sig = trim($arr[1]);
              }
              if($arr[0] == 'type'){
                $_type = trim($arr[1]);
              }
              if($arr[0] == 'quality'){
                $_quality = trim($arr[1]);
              }
              if($arr[0] == 'itag'){
                $_itag = trim($arr[1]);
              } 
               
            }    
                  
            $entry = $_url.'&signature='.$_sig;
            $link = urldecode($entry);
			      
            // Group videos by extension
            if($_itag == '85' || $_itag == '84' || $_itag == '83' || $_itag == '82' || $_itag == '38' || $_itag == '37' || $_itag == '22' || $_itag == '18'){
              $mp4_links[] = $link;
              $mp4_itags[] = $_itag;
            }elseif($_itag == '35' || $_itag == '34' || $_itag == '5'){
              $flv_links[] = $link;
              $flv_itags[] = $_itag;
            }elseif($_itag == '102' || $_itag == '101' || $_itag == '100' || $_itag == '46' || $_itag == '45' || $_itag == '44' || $_itag == '43'){
              $webm_links[] = $link;
              $webm_itags[] = $_itag;
            }elseif($_itag == '17'){
              $gp_links[] = $link;
              $gp_itags[] = $_itag;
            }else{
              $ukn_links[] = $link;
              $ukn_itags[] = $_itag;
            }  
                	
	        }
	        //print_r($flv_links);
	          	
          // Find a Preferred Video    
          if($pref == 'mp4' && $qual == 'high'){
            $data = $mp4_links[0];
          }elseif($pref == 'mp4' && $qual == 'medium'){
            $data = (isset($mp4_links[1])) ? $mp4_links[1] : $mp4_links[0];
          }elseif($pref == 'mp4' && $qual == 'low'){
            $data = end($mp4_links);
          }elseif($pref == 'flv' && $qual == 'high' || ($data == '')){
            $data = $flv_links[0];
          }elseif($pref == 'flv' && $qual == 'medium'){
            $data = (isset($flv_links[1])) ? $flv_links[1] : $flv_links[0];
          }elseif($pref == 'flv' && $qual == 'low'){
            $data = end($flv_links);
          }

          if(strlen($data)<125){
            $data = $flv_links[0];
          }
                 
          $flv_url = $data;  
            
          // Output some data
          $arr['flvs'] = $flv_links;
          $arr['flvt'] = $flv_itags;
          $arr['mp4s'] = $mp4_links;
          $arr['mp4t'] = $mp4_itags;  
          $arr['webms'] = $webm_links;
          $arr['webmt'] = $webm_itags;
          $arr['gps'] = $gp_links;
          $arr['gpt'] = $gp_itags;
          $arr['ukns'] = $ukn_links;
          $arr['uknt'] = $ukn_itags;
          $arr['cdebug'] = $cdebug;
          $arr['link'] = $flv_url;
          $arr['ext'] = $pref;
          //print_r($arr);  
                
        }          
        return $flv_url;
        
        
        
    }
}
?>
