<?php
require_once 'include/Request.php';

class YTrip {
    var $request;

    function YTdownload($video_id) {
	$yt_url         = 'http://www.youtube.com/watch?v='.$video_id;
	$yt_page        = file_get_contents($yt_url);
	$yt_tempid      = substr(strstr($yt_page, "&t="),3);
	$yt_id          = substr($yt_tempid, 0, strpos($yt_tempid, "%3D"));
	$yt_url         = 'http://www.youtube.com/get_video?video_id='.$video_id.'&t='.$yt_id.'%3D';

	if ($yt_id == '' ) return false;
	    else return $yt_url.'=&asv=2';
    }
}
?>