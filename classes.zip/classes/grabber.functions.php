<?php
function getYTflv($yt_url) {
    require_once 'grabber.class.php';

    $yt_rip     = new YTrip();
    $yt_flv     = $yt_rip->YTdownload($yt_url);

    return $yt_flv;
}

function getYTurl($yt_url) {
    $yt_url     = $yt_url.'&';
    $yt_path    = '/v=(.+?)&+/';
    preg_match($yt_path, $yt_url, $result);

    return ($result[1]);
}
?>